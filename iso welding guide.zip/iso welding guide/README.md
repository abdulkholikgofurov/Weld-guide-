# ISO 2553-2022 va ISO 6947-2017 Android Ilovasi

## GitHub'da tayyor APK olish (3 qadam):
1. GitHub'da yangi **Public** yoki **Private** repozitoriya oching.
2. Ushbu ZIP arxiv ichidagi **barcha fayl va papkalarni** (`.github` papkasi bilan birga!) repozitoriyaga yuklang.
3. GitHub'da **Actions** bo'limiga o'ting → **Build Android APK** ishga tushadi → 3-4 daqiqadan so'ng pastda **Artifacts** bo'limidan `ISO-2553-6947-Welding-APK` faylini yuklab oling!
