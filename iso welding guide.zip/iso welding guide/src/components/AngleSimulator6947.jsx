import React, { useState } from 'react';

export default function AngleSimulator6947({ lang }) {
  const [slope, setSlope] = useState(0);
  const [rotation, setRotation] = useState(0);
  const [jointType, setJointType] = useState('butt'); // 'butt' | 'fillet'

  const detectPosition = () => {
    if (slope >= 75) {
      return {
        code: 'PF / PG',
        aws: jointType === 'butt' ? '3G' : '3F',
        nameUz: 'Vertikal holat (PF ↑ / PG ↓)',
        nameRu: 'Вертикальное положение (PF ↑ / PG ↓)'
      };
    }
    if (jointType === 'butt') {
      if (rotation <= 30) return { code: 'PA', aws: '1G', nameUz: 'Pastki holat (0°)', nameRu: 'Нижнее положение (0°)' };
      if (rotation > 30 && rotation <= 100) return { code: 'PC', aws: '2G', nameUz: 'Gorizontal holat (90°)', nameRu: 'Горизонтальное положение (90°)' };
      return { code: 'PE', aws: '4G', nameUz: 'Shift holati (180°)', nameRu: 'Потолочное положение (180°)' };
    } else {
      if (rotation <= 30) return { code: 'PA', aws: '1F', nameUz: 'Pastki "qayiqcha" holati', nameRu: 'Нижнее положение «в лодочку»' };
      if (rotation > 30 && rotation <= 80) return { code: 'PB', aws: '2F', nameUz: 'Tavr gorizontal (45°)', nameRu: 'Горизонтальное тавровое (45°)' };
      if (rotation > 80 && rotation <= 100) return { code: 'PC', aws: '2G/2F', nameUz: 'Gorizontal (90°)', nameRu: 'Горизонтальное (90°)' };
      if (rotation > 100 && rotation < 150) return { code: 'PD', aws: '4F', nameUz: 'Tavr shift holati (135°)', nameRu: 'Потолочное тавровое (135°)' };
      return { code: 'PE', aws: '4G/4F', nameUz: 'Shift holati (180°)', nameRu: 'Потолочное положение (180°)' };
    }
  };

  const pos = detectPosition();

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 my-3 shadow-lg">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sky-400 font-bold text-sm">
          {lang === 'uz' ? '🧭 ISO 6947 Fazoviy Burchak Simulyatori' : '🧭 Симулятор углов ИСО 6947'}
        </h3>
        <button
          onClick={() => setJointType(j => j === 'butt' ? 'fillet' : 'butt')}
          className="px-2.5 py-1 bg-slate-700 rounded-lg text-xs font-bold text-amber-400"
        >
          {jointType === 'butt' ? (lang === 'uz' ? 'Uchma-uch (G)' : 'Стыковой (G)') : (lang === 'uz' ? 'Burchakli (F)' : 'Угловой (F)')}
        </button>
      </div>

      <div className="flex items-center justify-between bg-slate-950 p-4 rounded-xl border border-slate-700 mb-4">
        <svg viewBox="0 0 140 140" className="w-32 h-32">
          <circle cx="70" cy="70" r="56" fill="none" stroke="#334155" strokeWidth="2" />
          <line x1="70" y1="10" x2="70" y2="130" stroke="#1e293b" strokeDasharray="3,3" />
          <line x1="10" y1="70" x2="130" y2="70" stroke="#1e293b" strokeDasharray="3,3" />
          <g transform={`rotate(${rotation}, 70, 70)`}>
            {jointType === 'butt' ? (
              <>
                <rect x="32" y="65" width="76" height="10" fill="#64748b" rx="2" />
                <circle cx="70" cy="63" r="6" fill="#f59e0b" />
              </>
            ) : (
              <>
                <rect x="35" y="70" width="70" height="8" fill="#64748b" />
                <rect x="66" y="36" width="8" height="34" fill="#64748b" />
                <polygon points="74,70 74,56 88,70" fill="#f59e0b" />
              </>
            )}
            <line x1="70" y1="24" x2="70" y2="50" stroke="#22c55e" strokeWidth="3" />
            <polygon points="70,53 65,44 75,44" fill="#22c55e" />
          </g>
        </svg>

        <div className="text-right">
          <div className="text-3xl font-black text-amber-400">{pos.code}</div>
          <div className="text-xs text-sky-400 font-bold">AWS / ASME: {pos.aws}</div>
          <div className="text-xs text-slate-200 mt-1 max-w-[160px]">{lang === 'uz' ? pos.nameUz : pos.nameRu}</div>
        </div>
      </div>

      <div className="space-y-3 text-xs">
        <div>
          <div className="flex justify-between mb-1">
            <span>{lang === 'uz' ? 'Burilish burchagi (R - Rotation):' : 'Угол поворота (R):'}</span>
            <span className="text-amber-400 font-bold">{rotation}°</span>
          </div>
          <input type="range" min="0" max="180" value={rotation} onChange={(e) => setRotation(Number(e.target.value))} className="w-full accent-amber-500" />
        </div>
        <div>
          <div className="flex justify-between mb-1">
            <span>{lang === 'uz' ? 'Chok oʻqi nishabligi (S - Slope):' : 'Угол наклона оси (S):'}</span>
            <span className="text-sky-400 font-bold">{slope}°</span>
          </div>
          <input type="range" min="0" max="90" value={slope} onChange={(e) => setSlope(Number(e.target.value))} className="w-full accent-sky-500" />
        </div>
      </div>
    </div>
  );
}
