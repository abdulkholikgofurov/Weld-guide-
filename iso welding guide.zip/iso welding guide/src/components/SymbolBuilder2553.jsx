import React, { useState } from 'react';

export default function SymbolBuilder2553({ lang }) {
  const [sys, setSys] = useState('A');
  const [side, setSide] = useState('arrow');
  const [weldType, setWeldType] = useState('fillet');
  const [finish, setFinish] = useState('none');
  const [dimLeft, setDimLeft] = useState('a5');
  const [dimRight, setDimRight] = useState('4×100(200)');
  const [allAround, setAllAround] = useState(false);
  const [fieldWeld, setFieldWeld] = useState(true);
  const [tailText, setTailText] = useState('ISO 4063-135');

  const isBottom = (sys === 'B' && side === 'arrow') || (sys === 'A' && side === 'other');
  const yBase = isBottom ? 78 : 70;

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 my-3 shadow-lg">
      <h3 className="text-amber-400 font-bold text-sm mb-3">
        {lang === 'uz' ? '🛠 Jonli ISO 2553 Chizma va Kesim Konstruktori' : '🛠 Живой конструктор чертежа и сечения ИСО 2553'}
      </h3>

      <div className="grid grid-cols-1 gap-2 mb-3">
        <div className="bg-slate-950 rounded-xl p-2 border border-slate-700">
          <div className="text-[10px] text-slate-400 text-center">
            {lang === 'uz' ? 'Texnik chizmadagi shartli belgi' : 'Условное обозначение на чертеже'}
          </div>
          <svg viewBox="0 0 380 135" className="w-full h-32">
            <line x1="22" y1="115" x2="82" y2="70" stroke="#38bdf8" strokeWidth="2.5" />
            <polygon points="22,115 36,109 30,102" fill="#38bdf8" />
            <line x1="82" y1="70" x2="262" y2="70" stroke="#38bdf8" strokeWidth="2.5" />
            {sys === 'A' && (
              <line x1="82" y1="78" x2="262" y2="78" stroke="#38bdf8" strokeWidth="2" strokeDasharray="7,4" />
            )}
            {allAround && <circle cx="82" cy="70" r="8" fill="none" stroke="#f59e0b" strokeWidth="2.5" />}
            {fieldWeld && (
              <g>
                <line x1="82" y1="70" x2="82" y2="36" stroke="#f59e0b" strokeWidth="2.5" />
                <polygon points="82,36 104,43 82,50" fill="#f59e0b" />
              </g>
            )}
            <text x="115" y={isBottom ? 98 : 60} fill="#22c55e" fontSize="14" fontWeight="bold" textAnchor="end">
              {dimLeft}
            </text>
            {weldType === 'fillet' && (
              <g>
                <polygon
                  points={isBottom ? `122,${yBase} 122,${yBase + 22} 144,${yBase}` : `122,${yBase} 122,${yBase - 22} 144,${yBase}`}
                  fill="none" stroke="#f59e0b" strokeWidth="2.5"
                />
                {finish === 'flat' && (
                  <line x1={isBottom ? 148 : 148} y1={isBottom ? yBase + 4 : yBase - 4} x2={isBottom ? 126 : 126} y2={isBottom ? yBase + 26 : yBase - 26} stroke="#22c55e" strokeWidth="2" />
                )}
                {finish === 'convex' && (
                  <path d={isBottom ? `M126,${yBase+24} Q142,${yBase+20} 146,${yBase+4}` : `M126,${yBase-24} Q142,${yBase-20} 146,${yBase-4}`} fill="none" stroke="#22c55e" strokeWidth="2" />
                )}
                {finish === 'concave' && (
                  <path d={isBottom ? `M126,${yBase+24} Q132,${yBase+10} 146,${yBase+4}` : `M126,${yBase-24} Q132,${yBase-10} 146,${yBase-4}`} fill="none" stroke="#22c55e" strokeWidth="2" />
                )}
              </g>
            )}
            {weldType === 'vgroove' && (
              <g>
                <path
                  d={isBottom ? `M120,${yBase + 20} L133,${yBase} L146,${yBase + 20}` : `M120,${yBase - 20} L133,${yBase} L146,${yBase - 20}`}
                  fill="none" stroke="#f59e0b" strokeWidth="2.5"
                />
                {finish === 'flat' && <line x1="120" y1={isBottom ? yBase + 25 : yBase - 25} x2="146" y2={isBottom ? yBase + 25 : yBase - 25} stroke="#22c55e" strokeWidth="2" />}
                {finish === 'convex' && <path d={isBottom ? `M120,${yBase+24} Q133,${yBase+32} 146,${yBase+24}` : `M120,${yBase-24} Q133,${yBase-32} 146,${yBase-24}`} fill="none" stroke="#22c55e" strokeWidth="2" />}
                {finish === 'concave' && <path d={isBottom ? `M120,${yBase+26} Q133,${yBase+18} 146,${yBase+26}` : `M120,${yBase-26} Q133,${yBase-18} 146,${yBase-26}`} fill="none" stroke="#22c55e" strokeWidth="2" />}
              </g>
            )}
            <text x="156" y={isBottom ? 98 : 60} fill="#38bdf8" fontSize="13" fontWeight="bold">
              {dimRight}
            </text>
            {tailText && (
              <g>
                <polyline points="279,54 262,70 279,86" fill="none" stroke="#38bdf8" strokeWidth="2.5" />
                <text x="282" y="74" fill="#e2e8f0" fontSize="11" fontWeight="bold">{tailText}</text>
              </g>
            )}
          </svg>
        </div>

        {/* Metalldagi ko'rinishi (kesim) */}
        <div className="bg-slate-950 rounded-xl p-2 border border-slate-700">
          <div className="text-[10px] text-slate-400 text-center">
            {lang === 'uz' ? 'Metalldagi haqiqiy koʻrinishi (kesim)' : 'Реальное сечение сварного соединения'}
          </div>
          {weldType === 'fillet' ? (
            <svg viewBox="0 0 300 75" className="w-full h-16">
              <rect x="40" y="55" width="220" height="14" fill="#475569" />
              <rect x="142" y="8" width="16" height="47" fill="#64748b" />
              {side === 'arrow' ? (
                <polygon points="118,55 142,55 142,31" fill="#f59e0b" />
              ) : (
                <polygon points="158,55 182,55 158,31" fill="#f59e0b" />
              )}
              <text x="65" y="45" fill="#38bdf8" fontSize="10">← Strelka / Стрелка</text>
            </svg>
          ) : (
            <svg viewBox="0 0 300 75" className="w-full h-16">
              <polygon points="40,22 132,22 147,55 40,55" fill="#475569" />
              <polygon points="260,22 168,22 153,55 260,55" fill="#475569" />
              {side === 'arrow' ? (
                <polygon points="132,22 168,22 153,55 147,55" fill="#f59e0b" />
              ) : (
                <polygon points="147,22 153,22 168,55 132,55" fill="#f59e0b" />
              )}
              <text x="55" y="15" fill="#38bdf8" fontSize="10">↓ Strelka (yuqori) / Стрелка</text>
            </svg>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 text-xs">
        <button onClick={() => setSys(sys === 'A' ? 'B' : 'A')} className="bg-slate-700 hover:bg-slate-600 p-2 rounded-lg text-white font-semibold">
          {lang === 'uz' ? `Tizim: ${sys} (${sys === 'A' ? 'Ikkitali' : 'Bittalik'})` : `Система: ${sys}`}
        </button>
        <button onClick={() => setSide(side === 'arrow' ? 'other' : 'arrow')} className="bg-slate-700 hover:bg-slate-600 p-2 rounded-lg text-white font-semibold">
          {side === 'arrow' ? (lang === 'uz' ? 'Strelka tomoni' : 'Сторона стрелки') : (lang === 'uz' ? 'Teskari tomon' : 'Обратная сторона')}
        </button>
        <button onClick={() => setWeldType(weldType === 'fillet' ? 'vgroove' : 'fillet')} className="bg-slate-700 hover:bg-slate-600 p-2 rounded-lg text-white font-semibold">
          {weldType === 'fillet' ? (lang === 'uz' ? 'Chok: Burchakli (Δ)' : 'Шов: Угловой (Δ)') : (lang === 'uz' ? 'Chok: V-simon' : 'Шов: V-образный')}
        </button>
        <button onClick={() => setFinish(f => f === 'none' ? 'flat' : f === 'flat' ? 'convex' : f === 'convex' ? 'concave' : 'none')} className="bg-slate-700 hover:bg-slate-600 p-2 rounded-lg text-white font-semibold">
          {lang === 'uz' ? `Yuza: ${finish === 'none' ? 'Oddiy' : finish === 'flat' ? 'Tekis (—)' : finish === 'convex' ? 'Qavariq (⌢)' : 'Botiq (⌣)'}` : `Форма: ${finish}`}
        </button>
        <button onClick={() => setFieldWeld(!fieldWeld)} className={`p-2 rounded-lg font-semibold ${fieldWeld ? 'bg-amber-600 text-white' : 'bg-slate-700 text-slate-300'}`}>
          {lang === 'uz' ? 'Montaj bayrogʻi ⚑' : 'Монтажный флажок ⚑'}
        </button>
        <button onClick={() => setAllAround(!allAround)} className={`p-2 rounded-lg font-semibold ${allAround ? 'bg-amber-600 text-white' : 'bg-slate-700 text-slate-300'}`}>
          {lang === 'uz' ? 'Yopiq kontur ○' : 'По контуру ○'}
        </button>
        <input value={dimLeft} onChange={(e) => setDimLeft(e.target.value)} className="bg-slate-900 border border-slate-600 rounded-lg px-2 py-1.5 text-green-400 font-bold" placeholder="a5 / z7 / s10" />
        <input value={dimRight} onChange={(e) => setDimRight(e.target.value)} className="bg-slate-900 border border-slate-600 rounded-lg px-2 py-1.5 text-sky-400" placeholder="4×100(200)" />
      </div>
    </div>
  );
}
