import React, { useState } from 'react';
import { iso2553Topics } from './data/iso2553Data';
import { iso6947Topics } from './data/iso6947Data';
import SymbolBuilder2553 from './components/SymbolBuilder2553';
import AngleSimulator6947 from './components/AngleSimulator6947';
import PdfViewerModal from './components/PdfViewerModal';

export default function App() {
  const [lang, setLang] = useState('uz');
  const [standard, setStandard] = useState(null);
  const [activeTopic, setActiveTopic] = useState(null);
  const [pdfModal, setPdfModal] = useState(null);
  const [quizAnswers, setQuizAnswers] = useState({});

  const topics = standard === '2553' ? iso2553Topics : iso6947Topics;
  const pdfFile = standard === '2553' ? './pdf/ISO-2553_RU.pdf' : './pdf/ISO-6947_RU.pdf';

  const correctCount = activeTopic
    ? activeTopic.quiz.reduce((acc, q, idx) => (quizAnswers[idx] === q.correct ? acc + 1 : acc), 0)
    : 0;

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-sans pb-12">
      <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {(standard || activeTopic) && (
            <button
              onClick={() => activeTopic ? setActiveTopic(null) : setStandard(null)}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-xl text-sky-400 font-bold text-xs"
            >
              ← {lang === 'uz' ? 'Orqaga' : 'Назад'}
            </button>
          )}
          <span className="font-extrabold text-sm tracking-tight text-white">
            {standard ? `ГОСТ Р ИСО ${standard}` : 'WELDING ISO PRO'}
          </span>
        </div>

        <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl border border-slate-700">
          <button
            onClick={() => setLang('uz')}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${lang === 'uz' ? 'bg-sky-600 text-white shadow' : 'opacity-60'}`}
          >
            🇺🇿 UZ
          </button>
          <button
            onClick={() => setLang('ru')}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${lang === 'ru' ? 'bg-sky-600 text-white shadow' : 'opacity-60'}`}
          >
            🇷🇺 RU
          </button>
        </div>
      </header>

      <main className="max-w-xl mx-auto p-4">
        {!standard && (
          <div className="space-y-4 mt-2">
            <div className="text-center mb-6">
              <div className="inline-block px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-amber-400 text-[11px] font-bold mb-2">
                ISO 9606-1 / ГОСТ Р ИСО
              </div>
              <h1 className="text-xl font-black text-white">
                {lang === 'uz' ? 'Payvandlash standartlari qoʻllanmasi' : 'Справочник стандартов сварки'}
              </h1>
            </div>

            <button
              onClick={() => setStandard('2553')}
              className="w-full text-left bg-slate-800/90 hover:bg-slate-800 border-2 border-sky-500/40 hover:border-sky-400 p-5 rounded-2xl shadow-xl transition"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-extrabold text-sky-400">ГОСТ Р ИСО 2553-2022</span>
                <span className="text-[11px] bg-sky-500/20 text-sky-300 px-2 py-0.5 rounded-full font-bold">25 ta test</span>
              </div>
              <div className="text-lg font-black text-white mb-2">
                {lang === 'uz' ? 'Chizmalardagi shartli belgilar' : 'Условные обозначения на чертежах'}
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {lang === 'uz'
                  ? 'A va B tizimlari, 22 xil chok belgilari, oʻlchamlar (a, z, s, n×l(e)), tagliklar (M/MR), montaj bayrogʻi + Jonli konstruktor'
                  : 'Системы А и В, начальные и вспомогательные обозначения, размеры (a, z, s), подкладки (M/MR) + Живой конструктор'}
              </p>
            </button>

            <button
              onClick={() => setStandard('6947')}
              className="w-full text-left bg-slate-800/90 hover:bg-slate-800 border-2 border-amber-500/40 hover:border-amber-400 p-5 rounded-2xl shadow-xl transition"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-extrabold text-amber-400">ГОСТ Р ИСО 6947-2017</span>
                <span className="text-[11px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-bold">15 ta test</span>
              </div>
              <div className="text-lg font-black text-white mb-2">
                {lang === 'uz' ? 'Payvandlash fazoviy holatlari' : 'Положения при сварке'}
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {lang === 'uz'
                  ? 'PA–PK asosiy holatlari, nishab (S) va burilish (R) burchaklari, H-L045, AWS/ASME (1G–6G) jadvali + Burchak simulyatori'
                  : 'Положения PA–PK, углы наклона S и поворота R, H-L045, сравнение с AWS/ASME (1G–6G) + Симулятор углов'}
              </p>
            </button>
          </div>
        )}

        {standard && !activeTopic && (
          <div className="space-y-3">
            {standard === '2553' ? <SymbolBuilder2553 lang={lang} /> : <AngleSimulator6947 lang={lang} />}

            <h2 className="text-xs font-extrabold text-slate-400 uppercase tracking-wider mt-5 mb-2">
              {lang === 'uz' ? 'Mavzulashtirilgan boʻlimlar va testlar' : 'Тематические разделы и тесты'}
            </h2>

            {topics.map((t) => (
              <button
                key={t.id}
                onClick={() => { setActiveTopic(t); setQuizAnswers({}); window.scrollTo(0, 0); }}
                className="w-full text-left bg-slate-800 hover:bg-slate-750 border border-slate-700 p-4 rounded-xl flex items-center justify-between transition"
              >
                <div className="pr-2">
                  <div className="font-bold text-white text-sm">{t.title[lang]}</div>
                  <div className="text-xs text-slate-400 mt-1">
                    {lang === 'uz' ? `📝 Test: ${t.quiz.length} savol  |  📖 Kitob: ${t.pdfPage}-bet` : `📝 Тест: ${t.quiz.length} вопр.  |  📖 Книга: стр. ${t.pdfPage}`}
                  </div>
                </div>
                <span className="text-sky-400 font-black text-lg">→</span>
              </button>
            ))}
          </div>
        )}

        {activeTopic && (
          <div className="space-y-4">
            <h2 className="text-base font-extrabold text-amber-400">{activeTopic.title[lang]}</h2>

            <div className="bg-slate-800/90 border border-slate-700 p-4 rounded-2xl text-xs sm:text-sm leading-relaxed whitespace-pre-line text-slate-200">
              {activeTopic.theory[lang]}
            </div>

            {activeTopic.items.map((item, idx) => (
              <div key={idx} className="bg-slate-800 border border-slate-700 rounded-2xl p-3.5">
                <div className="font-bold text-sky-400 text-xs sm:text-sm mb-0.5">{item.name[lang]}</div>
                <div className="text-[11px] text-slate-400 mb-3">{item.desc[lang]}</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div className="bg-slate-950 p-2 rounded-xl border border-slate-700">
                    <div className="text-[10px] text-center text-slate-400 mb-1">
                      {lang === 'uz' ? 'Chizmadagi shartli belgi' : 'Условное обозначение'}
                    </div>
                    <div dangerouslySetInnerHTML={{ __html: item.symbolSvg }} />
                  </div>
                  <div className="bg-slate-950 p-2 rounded-xl border border-slate-700">
                    <div className="text-[10px] text-center text-slate-400 mb-1">
                      {lang === 'uz' ? 'Metalldagi haqiqiy koʻrinishi' : 'Вид шва в металле'}
                    </div>
                    <div dangerouslySetInnerHTML={{ __html: item.crossSectionSvg }} />
                  </div>
                </div>
              </div>
            ))}

            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-green-400 text-sm">
                  {lang === 'uz' ? '📝 Mavzu boʻyicha test' : '📝 Тест по разделу'}
                </h3>
                <span className="text-xs font-bold bg-slate-900 px-2.5 py-1 rounded-lg text-amber-400">
                  {correctCount} / {activeTopic.quiz.length}
                </span>
              </div>

              {activeTopic.quiz.map((q, qIdx) => {
                const chosen = quizAnswers[qIdx];
                return (
                  <div key={qIdx} className="border-t border-slate-700 pt-3">
                    <div className="font-semibold text-xs sm:text-sm text-white mb-2">
                      {qIdx + 1}. {q.question[lang]}
                    </div>
                    {q.svg && (
                      <div className="bg-slate-950 p-2 rounded-xl mb-3 max-w-xs mx-auto" dangerouslySetInnerHTML={{ __html: q.svg }} />
                    )}
                    <div className="space-y-2">
                      {q.options.map((opt, oIdx) => {
                        let btnStyle = 'bg-slate-900 border-slate-700 text-slate-200';
                        if (chosen !== undefined) {
                          if (oIdx === q.correct) btnStyle = 'bg-green-900/60 border-green-500 text-green-200 font-bold';
                          else if (oIdx === chosen) btnStyle = 'bg-red-900/60 border-red-500 text-red-200';
                        }
                        return (
                          <button
                            key={oIdx}
                            onClick={() => setQuizAnswers({ ...quizAnswers, [qIdx]: oIdx })}
                            className={`w-full text-left p-3 rounded-xl border text-xs transition ${btnStyle}`}
                          >
                            {opt[lang]}
                          </button>
                        );
                      })}
                    </div>
                    {chosen !== undefined && (
                      <div className="mt-2 p-2.5 bg-sky-950/70 border border-sky-700 rounded-xl text-xs text-sky-200">
                        💡 {q.explanation[lang]}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => setPdfModal(activeTopic.pdfPage)}
              className="w-full py-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-2xl shadow-lg text-xs sm:text-sm flex items-center justify-center gap-2"
            >
              📖 {lang === 'uz'
                ? `Kitobdan tekshirish (standartning ${activeTopic.pdfPage}-sahifasi)`
                : `Проверить по книге (страница ${activeTopic.pdfPage} стандарта)`}
            </button>
          </div>
        )}
      </main>

      {pdfModal && (
        <PdfViewerModal
          pdfUrl={pdfFile}
          pageNumber={pdfModal}
          onClose={() => setPdfModal(null)}
          lang={lang}
        />
      )}
    </div>
  );
}
