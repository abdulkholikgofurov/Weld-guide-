import React, { useEffect, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';

pdfjsLib.GlobalWorkerOptions.workerSrc = './pdfjs/pdf.worker.min.mjs';

export default function PdfViewerModal({ pdfUrl, pageNumber, onClose, lang }) {
  const canvasRef = useRef(null);
  const [page, setPage] = useState(pageNumber || 1);
  const [totalPages, setTotalPages] = useState(1);
  const [scale, setScale] = useState(1.5);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setErr(null);
    async function render() {
      try {
        const pdf = await pdfjsLib.getDocument(pdfUrl).promise;
        if (cancelled) return;
        setTotalPages(pdf.numPages);
        const safePage = Math.min(Math.max(1, page), pdf.numPages);
        const pdfPage = await pdf.getPage(safePage);
        const viewport = pdfPage.getViewport({ scale });
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        await pdfPage.render({ canvasContext: ctx, viewport }).promise;
        if (!cancelled) setLoading(false);
      } catch (e) {
        if (!cancelled) {
          setErr(e.message || 'PDF load error');
          setLoading(false);
        }
      }
    }
    render();
    return () => { cancelled = true; };
  }, [pdfUrl, page, scale]);

  return (
    <div className="fixed inset-0 bg-black/95 z-50 flex flex-col">
      <div className="flex items-center justify-between p-3 bg-slate-900 border-b border-slate-700 gap-2">
        <span className="text-xs font-bold text-amber-400">
          {lang === 'uz' ? `📖 Sahifa: ${page} / ${totalPages}` : `📖 Страница: ${page} / ${totalPages}`}
        </span>
        <div className="flex items-center gap-1.5">
          <button onClick={() => setScale(s => Math.max(1.0, +(s - 0.25).toFixed(2)))} className="px-2.5 py-1 bg-slate-800 rounded text-xs font-bold">−</button>
          <button onClick={() => setScale(s => Math.min(2.75, +(s + 0.25).toFixed(2)))} className="px-2.5 py-1 bg-slate-800 rounded text-xs font-bold">+</button>
          <button onClick={() => setPage(p => Math.max(1, p - 1))} className="px-3 py-1 bg-slate-700 rounded text-white text-xs font-bold">◀</button>
          <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} className="px-3 py-1 bg-slate-700 rounded text-white text-xs font-bold">▶</button>
          <button onClick={onClose} className="px-3 py-1 bg-red-600 rounded text-white text-xs font-bold">✕</button>
        </div>
      </div>
      <div className="flex-1 overflow-auto p-3 flex justify-center items-start bg-slate-950">
        {loading && <div className="text-sky-400 text-sm mt-10 animate-pulse">{lang === 'uz' ? 'Sahifa yuklanmoqda...' : 'Загрузка страницы...'}</div>}
        {err && <div className="text-red-400 text-xs mt-10">{err}</div>}
        <canvas ref={canvasRef} className={`max-w-none rounded shadow-2xl bg-white ${loading ? 'hidden' : 'block'}`} />
      </div>
    </div>
  );
}
