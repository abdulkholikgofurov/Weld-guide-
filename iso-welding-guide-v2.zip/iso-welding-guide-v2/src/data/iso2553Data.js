export const iso2553Topics = [
  {
    id: "2553-base",
    pdfPage: 6,
    title: {
      uz: "1. Asosiy elementlar: Strelka, Tokcha va Dum (3–4-boʻlimlar)",
      ru: "1. Основные элементы: Стрелка, Полка и «Хвост» (Разделы 3–4)"
    },
    theory: {
      uz: "ГОСТ Р ИСО 2553-2022 boʻyicha payvandlash shartli belgisi uchta asosiy qismdan iborat:
1. Strelka chizigʻi (линия стрелки) — payvandlanadigan birikma joyiga tegib turadi (odatda 135° burchak ostida).
2. Tokcha chizigʻi (линия полки) — chizma pastki chetiga parallel chiziladi va ustiga/ostiga chok belgilari qoʻyiladi.
3. Dum qismi («хвост») — V-simon element boʻlib, ichiga payvandlash jarayoni kodi (masalan, ISO 4063-141 TIG yoki 135 MAG), sifat darajasi (ISO 5817-B) yoki fazoviy holat (ISO 6947-PA) yoziladi. Agar dum yopiq boʻlsa (uchburchak shaklida), bu aniq texnologik karta (WPS/WPQR) raqamiga havolani bildiradi.
4. Siniq strelka (ломаная линия стрелки) — ikkita detaldan aynan qaysi birining qirrasini kesish (razdelka qilish) kerakligini aniq koʻrsatish uchun sinib oʻsha detalga qaratiladi.",
      ru: "Согласно ГОСТ Р ИСО 2553-2022 условное обозначение сварного соединения включает:
1. Линию стрелки — указывает на место сварного соединения.
2. Линию полки — располагается параллельно нижнему краю чертежа.
3. «Хвост» — V-образный элемент для дополнительной информации (процесс по ИСО 4063, уровень качества по ИСО 5817, положение по ИСО 6947), разделяемой знаком «/». Закрытый «хвост» применяется только для ссылки на конкретную инструкцию (WPS, WPQR).
4. Ломаная линия стрелки — указывает на конкретный элемент соединения, кромку которого необходимо подготовить (скосить)."
    },
    items: [
      {
        name: { uz: "Asosiy shartli belgi (1-rasm)", ru: "Основное условное обозначение (Рисунок 1)" },
        desc: { uz: "Chok turi aniqlanmagan (koʻpincha prixvatkalar uchun)", ru: "Тип соединения не определен (часто для прихваток)" },
        symbolSvg: `<svg viewBox="0 0 220 85"><line x1="20" y1="68" x2="65" y2="35" stroke="#38bdf8" stroke-width="2.5"/><polygon points="20,68 33,63 28,56" fill="#38bdf8"/><line x1="65" y1="35" x2="170" y2="35" stroke="#38bdf8" stroke-width="2.5"/><polyline points="188,20 170,35 188,50" fill="none" stroke="#f59e0b" stroke-width="2.5"/></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 220 85"><text x="20" y="30" fill="#38bdf8" font-size="11" font-weight="bold">1 — Strelka / Стрелка</text><text x="20" y="48" fill="#22c55e" font-size="11" font-weight="bold">2 — Tokcha / Полка</text><text x="20" y="66" fill="#f59e0b" font-size="11" font-weight="bold">3 — Dum / «Хвост»</text></svg>`
      },
      {
        name: { uz: "Yopiq dum (6b-rasm) va Siniq strelka", ru: "Закрытый «хвост» (Рис. 6b) и ломаная стрелка" },
        desc: { uz: "WPS hujjatiga havola va qirra kesish tomoni", ru: "Ссылка на WPS и указание скоса кромки" },
        symbolSvg: `<svg viewBox="0 0 220 85"><polyline points="25,68 45,45 65,35 155,35" fill="none" stroke="#38bdf8" stroke-width="2.5"/><polygon points="25,68 36,61 30,55" fill="#38bdf8"/><polygon points="155,35 175,20 175,50" fill="none" stroke="#f59e0b" stroke-width="2.5"/><text x="180" y="39" fill="#f59e0b" font-size="11" font-weight="bold">WPS</text></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 220 85"><rect x="25" y="25" width="75" height="35" fill="#475569"/><polygon points="195,25 125,25 103,60 195,60" fill="#64748b"/><text x="35" y="76" fill="#38bdf8" font-size="10">Siniq strelka oʻng detalga qaraydi</text></svg>`
      }
    ],
    quiz: [
      {
        question: {
          uz: "Chizmadagi shartli belgida 'dum' («хвост») qismi yopiq uchburchak shaklida chizilgan boʻlsa, ichiga nima yoziladi?",
          ru: "Для чего применяется закрытый «хвост» (треугольной формы) на конце линии полки?"
        },
        options: [
          { uz: "Faqat aniq texnologik hujjatga (WPS yoki WPQR) havola", ru: "Только для ссылки на конкретную инструкцию (WPS, WPQR)" },
          { uz: "Chok uzunligi va kateti", ru: "Длина и катет шва" },
          { uz: "Payvandchining familiyasi", ru: "Фамилия сварщика" }
        ],
        correct: 0,
        explanation: {
          uz: "4.8-band: Yopiq «хвост» faqat WPS, WPQR yoki boshqa aniq yoʻriqnomaga havola koʻrsatish uchun ishlatiladi.",
          ru: "Пункт 4.8: Закрытый «хвост» следует применять только для указания ссылки на конкретную инструкцию (WPS, WPQR)."
        }
      },
      {
        question: {
          uz: "Qachon strelka chizigʻi siniq (ломаная линия стрелки) koʻrinishda chiziladi?",
          ru: "В каком случае применяется ломаная линия стрелки?"
        },
        options: [
          { uz: "Ikkita detaldan aynan qaysi birining qirrasini kesish (razdelka) kerakligini koʻrsatish uchun", ru: "Когда требуется подготовить (скосить) кромку конкретного элемента соединения" },
          { uz: "Faqat alyuminiy payvandlanganda", ru: "Только при сварке алюминия" },
          { uz: "Chok ship holatida bajarilganda", ru: "Когда шов выполняется в потолочном положении" }
        ],
        correct: 0,
        explanation: {
          uz: "4.6.3-band: Bir qirrasi qiya kesiladigan yoki J-simon choklarda qaysi detalga ishlov berish kerakligini koʻrsatish uchun siniq strelka ishlatiladi.",
          ru: "Пункт 4.6.3: Ломаная линия стрелки указывает на конкретный элемент соединения, подлежащий подготовке кромки."
        }
      },
      {
        question: {
          uz: "Ochiq «хвост» ichida bir nechta ma'lumot (masalan, sifat darajasi, jarayon kodi, holat) qanday belgi bilan ajratiladi?",
          ru: "Каким знаком разделяется дополнительная информация в открытом «хвосте»?"
        },
        options: [
          { uz: "Qiya chiziq «/» bilan", ru: "Знаком «/» (косая черта)" },
          { uz: "Tenglik «=» belgisi bilan", ru: "Знаком «=»" },
          { uz: "Yulduzcha «*» bilan", ru: "Звездочкой «*»" }
        ],
        correct: 0,
        explanation: {
          uz: "4.8-band va 6a-rasm: Masalan, ISO 5817-C / ISO 4063-121 / ISO 6947-PA koʻrinishida «/» bilan ajratiladi.",
          ru: "Пункт 4.8 и рис. 6а): Информацию указывают и отделяют знаком «/»."
        }
      },
      {
        question: {
          uz: "Hech qanday chok belgisisiz, faqat strelka, tokcha va «хвост» dan iborat asosiy belgi (1-rasm) koʻpincha nima uchun qoʻllaniladi?",
          ru: "Для чего чаще всего применяют основное условное обозначение (без начального символа шва, рис. 1)?"
        },
        options: [
          { uz: "Vaqtinchalik ilashmalar (prixvatka) oʻrnini koʻrsatish uchun", ru: "Для указания расположения прихваток" },
          { uz: "Lazerli payvandlash uchun", ru: "Для лазерной сварки" },
          { uz: "Nuqtali kontakt payvandlash uchun", ru: "Для контактной точечной сварки" }
        ],
        correct: 0,
        explanation: {
          uz: "4.2-band izohi: Chok xususiyatlari aniq belgilanmagan asosiy belgi koʻpincha prixvatkalar joyini koʻrsatish uchun ishlatiladi.",
          ru: "Примечание к п. 4.2: Данное обозначение часто применяют для указания расположения прихваток."
        }
      },
      {
        question: {
          uz: "Bitta tokcha chizigʻiga ikkita yoki undan ortiq strelka chizigʻini ulash mumkinmi?",
          ru: "Допускается ли комбинировать две и более линий стрелки с одной линией полки?"
        },
        options: [
          { uz: "Ha, bir xil (identik) choklarning joylashuvini koʻrsatish uchun mumkin", ru: "Да, для указания расположения идентичных сварных швов" },
          { uz: "Yoʻq, qat'iyan taqiqlanadi", ru: "Нет, строго запрещено" },
          { uz: "Faqat B tizimida mumkin", ru: "Только в системе В" }
        ],
        correct: 0,
        explanation: {
          uz: "4.6.2-band va 4-rasm: Bir xil choklarni koʻrsatish uchun bitta tokchaga bir nechta strelka ulashga ruxsat etiladi.",
          ru: "Пункт 4.6.2 и рис. 4: Две и более линий стрелки допускается комбинировать с одной линией полки для идентичных швов."
        }
      }
    ]
  },
  {
    id: "2553-sys",
    pdfPage: 19,
    title: {
      uz: "2. A va B tizimlari: Strelka tomoni va teskari tomon (4.7-boʻlim)",
      ru: "2. Системы А и В: Сторона стрелки и обратная сторона (п. 4.7)"
    },
    theory: {
      uz: "Chizmada chok detalning strelka tegib turgan tomonidami yoki orqa (teskari) tomonidami ekanini aniqlash uchun ikki tizim qoʻllaniladi (ularni bitta chizmada aralashtirish mumkin emas):
• A tizimi (ikkitali tokcha): Bitta tutash (yaxlit) va bitta shtrix (uzuk-uzuk) parallel chiziq. Belgi tutash chiziqda tursa — strelka tomonida; shtrix chiziqda tursa — teskari tomonda payvandlanadi. Simmetrik ikki tomonlama choklarda shtrix chiziq olib tashlanadi.
• B tizimi (bittalik tokcha): Faqat bitta tutash chiziq chiziladi. Belgi chiziq OSTIDA tursa — strelka tomonida; chiziq USTIDA tursa — teskari tomonda payvandlanadi.
• Koʻp qatlamli/ketma-ket operatsiyalar (4.7.3): Strelkaga eng yaqin tokcha — 1-operatsiya (masalan, ildiz choki), keyingilari — 2- va 3-operatsiyalarni bildiradi.",
      ru: "Для указания стороны выполнения шва существуют две системы (совмещать их на одном чертеже нельзя):
• Система А (двойная линия полки): сплошная и штриховая линии. Символ на сплошной линии — сторона стрелки; на штриховой — обратная сторона. Для симметричных двусторонних швов штриховая линия удаляется.
• Система В (одинарная линия полки): символ ПОД линией полки — сторона стрелки; НАД линией полки — обратная сторона.
• Несколько линий полки (п. 4.7.3): ближайшая к стрелке полка — первая операция, последующие — вторая и третья."
    },
    items: [
      {
        name: { uz: "A tizimi (5-jadval): Strelka vs Teskari tomon", ru: "Система А (Табл. 5): Стрелка vs Обратная сторона" },
        desc: { uz: "Tutash chiziq = strelka tomoni | Shtrix = teskari tomon", ru: "Сплошная = сторона стрелки | Штриховая = обратная" },
        symbolSvg: `<svg viewBox="0 0 240 95"><line x1="15" y1="75" x2="50" y2="35" stroke="#38bdf8" stroke-width="2.5"/><line x1="50" y1="35" x2="115" y2="35" stroke="#38bdf8" stroke-width="2.5"/><line x1="50" y1="43" x2="115" y2="43" stroke="#38bdf8" stroke-width="2" stroke-dasharray="5,3"/><polygon points="75,35 75,18 92,35" fill="none" stroke="#22c55e" stroke-width="2.5"/><text x="52" y="88" fill="#22c55e" font-size="10">Strelka tomoni</text><line x1="130" y1="75" x2="165" y2="35" stroke="#38bdf8" stroke-width="2.5"/><line x1="165" y1="35" x2="230" y2="35" stroke="#38bdf8" stroke-width="2.5"/><line x1="165" y1="43" x2="230" y2="43" stroke="#38bdf8" stroke-width="2" stroke-dasharray="5,3"/><polygon points="188,43 188,60 205,43" fill="none" stroke="#f59e0b" stroke-width="2.5"/><text x="160" y="88" fill="#f59e0b" font-size="10">Teskari tomon</text></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 240 95"><rect x="20" y="65" width="90" height="12" fill="#475569"/><rect x="58" y="20" width="12" height="45" fill="#64748b"/><polygon points="43,65 58,65 58,50" fill="#22c55e"/><rect x="135" y="65" width="90" height="12" fill="#475569"/><rect x="173" y="20" width="12" height="45" fill="#64748b"/><polygon points="185,65 200,65 185,50" fill="#f59e0b"/></svg>`
      },
      {
        name: { uz: "B tizimi (5-jadval): Ostida vs Ustida", ru: "Система В (Табл. 5): Под полкой vs Над полкой" },
        desc: { uz: "Ostida = strelka tomoni | Ustida = teskari tomon", ru: "Под линией = сторона стрелки | Над = обратная" },
        symbolSvg: `<svg viewBox="0 0 240 95"><line x1="15" y1="75" x2="50" y2="42" stroke="#38bdf8" stroke-width="2.5"/><line x1="50" y1="42" x2="115" y2="42" stroke="#38bdf8" stroke-width="2.5"/><polygon points="75,42 75,60 92,42" fill="none" stroke="#22c55e" stroke-width="2.5"/><text x="52" y="88" fill="#22c55e" font-size="10">Strelka tomoni</text><line x1="130" y1="75" x2="165" y2="42" stroke="#38bdf8" stroke-width="2.5"/><line x1="165" y1="42" x2="230" y2="42" stroke="#38bdf8" stroke-width="2.5"/><polygon points="188,42 188,24 205,42" fill="none" stroke="#f59e0b" stroke-width="2.5"/><text x="160" y="88" fill="#f59e0b" font-size="10">Teskari tomon</text></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 240 95"><text x="18" y="38" fill="#22c55e" font-size="11" font-weight="bold">B tizimi (ostida) = A tizimi (tutash)</text><text x="18" y="62" fill="#f59e0b" font-size="11" font-weight="bold">B tizimi (ustida) = A tizimi (shtrix)</text></svg>`
      }
    ],
    quiz: [
      {
        question: {
          uz: "A tizimida belgi shtrix (uzuk-uzuk) chiziqqa chizilgan boʻlsa, chok qayerda bajariladi?",
          ru: "Где выполняется шов в системе А, если символ расположен на штриховой линии?"
        },
        svg: `<svg viewBox="0 0 200 75"><line x1="20" y1="60" x2="55" y2="25" stroke="#38bdf8" stroke-width="2.5"/><line x1="55" y1="25" x2="170" y2="25" stroke="#38bdf8" stroke-width="2.5"/><line x1="55" y1="33" x2="170" y2="33" stroke="#38bdf8" stroke-width="2" stroke-dasharray="6,3"/><polygon points="95,33 95,50 112,33" fill="none" stroke="#f59e0b" stroke-width="2.5"/></svg>`,
        options: [
          { uz: "Strelka koʻrsatgan tomonga teskari tomonda", ru: "На обратной стороне соединения" },
          { uz: "Strelka koʻrsatgan tomonda", ru: "На стороне, указанной стрелкой" },
          { uz: "Ikkala tomonda bir vaqtda", ru: "С обеих сторон одновременно" }
        ],
        correct: 0,
        explanation: {
          uz: "4.7.2.1A bandi: A tizimida shtrix chiziq teskari tomonni, tutash chiziq esa strelka tomonini bildiradi.",
          ru: "Пункт 4.7.2.1А: В системе А штриховая линия обозначает обратную сторону соединения."
        }
      },
      {
        question: {
          uz: "B tizimida (bitta tutash chiziq) chokni strelka koʻrsatgan tomonda bajarish uchun belgi qayerga qoʻyiladi?",
          ru: "Где располагается символ в системе В для шва на стороне, указанной стрелкой?"
        },
        options: [
          { uz: "Tokcha chizigʻining ostiga", ru: "Ниже (под) линии полки" },
          { uz: "Tokcha chizigʻining ustiga", ru: "Выше (над) линии полки" },
          { uz: "Tokcha chizigʻining oʻng uchiga", ru: "На правом конце полки" }
        ],
        correct: 0,
        explanation: {
          uz: "4.7.2.1B bandi: B tizimida tokcha ostidagi belgi — strelka tomoni, ustidagi belgi — teskari tomon.",
          ru: "Пункт 4.7.2.1В: В системе В обозначение под линией полки — сторона стрелки."
        }
      },
      {
        question: {
          uz: "Simmetrik ikki tomonlama choklarda A tizimining shtrix chizigʻi nima qilinadi?",
          ru: "Что происходит со штриховой линией в системе А при симметричных двусторонних швах?"
        },
        options: [
          { uz: "Shtrix chiziq olib tashlanadi (chizilmaydi)", ru: "Штриховую линию удаляют" },
          { uz: "Qizil rangga boʻyaladi", ru: "Окрашивается в красный цвет" },
          { uz: "Ikkita shtrix chiziq chiziladi", ru: "Рисуются две штриховые линии" }
        ],
        correct: 0,
        explanation: {
          uz: "4.4.3 va 4.7.1A bandlari: Bir xil oʻlchamli simmetrik ikki tomonlama choklarda shtrix chiziq olib tashlanadi.",
          ru: "Пункты 4.4.3 и 4.7.1А: Для симметричных двусторонних швов штриховую линию полки следует удалить."
        }
      },
      {
        question: {
          uz: "Bir nechta tokcha chizigʻi (5-rasm) ishlatilganda, eng birinchi bajariladigan payvandlash operatsiyasi qaysi tokchada koʻrsatiladi?",
          ru: "На какой линии полки указывается первая операция при использовании нескольких линий полки (рис. 5)?"
        },
        options: [
          { uz: "Strelkaga eng yaqin joylashgan tokchada", ru: "На линии полки, ближайшей к стрелке" },
          { uz: "Strelkadan eng uzoqdagi tokchada", ru: "На самой дальней от стрелки линии полки" },
          { uz: "Istalgan tokchada", ru: "На любой линии полки" }
        ],
        correct: 0,
        explanation: {
          uz: "4.7.3-band: Birinchi operatsiya strelkaga eng yaqin tokchada, keyingilari ketma-ket keyingi tokchalarda koʻrsatiladi.",
          ru: "Пункт 4.7.3: Первая операция должна быть указана на линии полки, ближайшей к стрелке."
        }
      },
      {
        question: {
          uz: "Bitta texnik chizmada A va B tizimlarini aralashtirib (birga) qoʻllash mumkinmi?",
          ru: "Допускается ли совмещать системы А и В на одном чертеже?"
        },
        options: [
          { uz: "Yoʻq, tizimlarni aralashtirish mumkin emas", ru: "Нет, системы А и В не следует совмещать" },
          { uz: "Ha, istalgan joyda aralashtirish mumkin", ru: "Да, можно совмещать в любом месте" },
          { uz: "Faqat quvurlar chizmasida mumkin", ru: "Только на чертежах труб" }
        ],
        correct: 0,
        explanation: {
          uz: "4.3-band: A va B tizimlarini qoʻshib ishlatmaslik kerak, chizmada qaysi tizim qoʻllanilgani aniq koʻrsatilishi shart.",
          ru: "Пункт 4.3: Системы А и В не следует совмещать, на чертежах должно быть указано, какая система применена."
        }
      }
    ]
  },
  {
    id: "2553-elem",
    pdfPage: 9,
    title: {
      uz: "3. Chok turlari va boshlangʻich belgilar (1 va 2-jadvallar)",
      ru: "3. Начальные обозначения типов швов (Таблицы 1 и 2)"
    },
    theory: {
      uz: "1-jadvalda choklarning barcha asosiy turlari keltirilgan:
• №1: Qirralari kesilmagan (toʻgʻri) uchma-uch chok (||)
• №2: Bir tomonlama V-simon chok (V)
• №3: Toʻmtoqlangan V-simon chok (Y)
• №4: Bir qirrasi qiya kesilgan chok (|/) — tik chiziq chapda!
• №6: U-simon chok | №7: J-simon chok (P shakliga oʻxshash)
• №10: Burchakli chok (toʻgʻri burchakli uchburchak, tik tomoni chapda)
• №11: Teshikli (probochniy) chok (toʻrtburchak)
• №12.1: Kontakt nuqtali chok (aylana) | №13: Eritib nuqtali chok
• №16: Shpilka payvandlash | №19: Qirra (tortsevoy) chok (Π)
• №21: Qoplama eritish (naplavka) | №22: Ustunsimon (stolbchatiy, lazer/elektron nurli) chok.",
      ru: "В таблице 1 стандарта приведены 22 типа начальных обозначений:
• №1: Стыковой без скоса кромок (||)
• №2: V-образный (V) | №3: V-образный с притуплением (Y)
• №4: Со скосом одной кромки (вертикальная линия всегда слева!)
• №6: U-образный | №7: J-образный (похож на букву Р)
• №10: Угловой шов (прямоугольный треугольник, катет слева)
• №11: Пробочный шов (прямоугольник)
• №12.1: Точечный контактный | №13: Точечный при сварке плавлением
• №16: Приварка шпильки | №19: Торцевой шов (Π)
• №21: Наплавка | №22: Столбчатый шов (лазерная/электронно-лучевая)."
    },
    items: [
      {
        name: { uz: "№1–№5: Uchma-uch (stikovoy) choklar", ru: "№1–№5: Стыковые швы" },
        desc: { uz: "|| (toʻgʻri), V (ikki qirra), Y (toʻmtoqlangan), 1/2 V (bir qirra)", ru: "|| (без скоса), V (двух кромок), Y (с притуплением), 1/2 V (одной кромки)" },
        symbolSvg: `<svg viewBox="0 0 260 70"><line x1="10" y1="48" x2="250" y2="48" stroke="#64748b" stroke-width="2"/><line x1="30" y1="22" x2="30" y2="48" stroke="#f59e0b" stroke-width="2.5"/><line x1="38" y1="22" x2="38" y2="48" stroke="#f59e0b" stroke-width="2.5"/><path d="M75,22 L88,48 L101,22" fill="none" stroke="#f59e0b" stroke-width="2.5"/><path d="M135,22 L148,36 L161,22 M148,36 L148,48" fill="none" stroke="#f59e0b" stroke-width="2.5"/><path d="M195,22 L195,48 L215,22" fill="none" stroke="#f59e0b" stroke-width="2.5"/></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 260 70"><polygon points="20,20 115,20 128,55 20,55" fill="#475569"/><polygon points="240,20 145,20 132,55 240,55" fill="#475569"/><polygon points="115,20 145,20 132,55 128,55" fill="#f59e0b"/></svg>`
      },
      {
        name: { uz: "№10 Burchakli, №11 Teshikli, №21 Naplavka", ru: "№10 Угловой, №11 Пробочный, №21 Наплавка" },
        desc: { uz: "Uchburchak, toʻrtburchak va ikkita yoy", ru: "Треугольник, прямоугольник и две дуги" },
        symbolSvg: `<svg viewBox="0 0 260 70"><line x1="10" y1="50" x2="250" y2="50" stroke="#64748b" stroke-width="2"/><polygon points="35,50 35,24 61,50" fill="none" stroke="#f59e0b" stroke-width="2.5"/><rect x="105" y="28" width="32" height="22" fill="none" stroke="#f59e0b" stroke-width="2.5"/><path d="M185,50 A12,12 0 0,1 209,50 A12,12 0 0,1 233,50" fill="none" stroke="#f59e0b" stroke-width="2.5"/></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 260 70"><rect x="20" y="45" width="220" height="14" fill="#475569"/><path d="M50,45 Q75,28 100,45 T150,45 T200,45" fill="#f59e0b"/><text x="70" y="22" fill="#f59e0b" font-size="10">Naplavka (qoplama)</text></svg>`
      }
    ],
    quiz: [
      {
        question: {
          uz: "Burchakli chok (№10) va bir qirrasi qiya kesilgan chok (№4) belgilarida tik (vertikal) chiziq qaysi tomonda chiziladi?",
          ru: "С какой стороны располагается вертикальная линия в символах углового шва (№10) и шва со скосом одной кромки (№4)?"
        },
        options: [
          { uz: "Har doim chap tomonda", ru: "Всегда с левой стороны" },
          { uz: "Har doim oʻng tomonda", ru: "Всегда с правой стороны" },
          { uz: "Strelka yoʻnalishiga qarab oʻzgaradi", ru: "Зависит от направления стрелки" }
        ],
        correct: 0,
        explanation: {
          uz: "1-jadval qoidasi: Vertikal chiziq strelka qaysi tomondan kelishidan qat'i nazar har doim chap tomonda chiziladi.",
          ru: "Правило Таблицы 1: Вертикальная составляющая символа всегда располагается слева."
        }
      },
      {
        question: {
          uz: "Ikki yonma-yon joylashgan yoy shaklidagi belgi (1-jadval, №21) nimani anglatadi?",
          ru: "Что обозначает символ в виде двух примыкающих полуокружностей/дуг (Таблица 1, №21)?"
        },
        options: [
          { uz: "Qoplama eritish (Naplavka)", ru: "Наплавка" },
          { uz: "Rolikli payvandlash", ru: "Роликовый шов" },
          { uz: "Shpilka payvandlash", ru: "Приварка шпильки" }
        ],
        correct: 0,
        explanation: {
          uz: "1-jadval №21: Ikkita yonma-yon yoy — sirtga metall qatlami eritib qoplash (наплавка) belgisidir.",
          ru: "Таблица 1, №21: Две дуги на линии полки обозначают наплавку."
        }
      },
      {
        question: {
          uz: "Tokcha chizigʻi ustida joylashgan boʻsh toʻrtburchak (1-jadval, №11) qanday chokni bildiradi?",
          ru: "Какой шов обозначает прямоугольник на линии полки (Таблица 1, №11)?"
        },
        options: [
          { uz: "Teshikli (probochniy) chok — yumaloq yoki choʻzinchoq teshikka", ru: "Пробочный шов (в круглые или продолговатые отверстия)" },
          { uz: "Uchma-uch tekis chok", ru: "Стыковой шов без скоса кромок" },
          { uz: "Qirra (tortsevoy) chok", ru: "Торцевой шов" }
        ],
        correct: 0,
        explanation: {
          uz: "1-jadval №11: Toʻrtburchak belgisi — teshik yoki tirqish ichini eritilgan metall bilan toʻldirish (пробочный шов).",
          ru: "Таблица 1, №11: Прямоугольник обозначает пробочный шов."
        }
      },
      {
        question: {
          uz: "1-jadval №22 dagi uchburchak (ustunsimon chok — столбчатый шов) qaysi payvandlash usullari uchun moʻljallangan?",
          ru: "Для каких процессов сварки применяется столбчатый шов (Таблица 1, №22)?"
        },
        options: [
          { uz: "Lazerli yoki elektron-nurli payvandlash uchun", ru: "Лазерная или электронно-лучевая сварка" },
          { uz: "Qoʻlda yoyli elektrod (MMA) bilan payvandlash uchun", ru: "Ручная дуговая сварка покрытым электродом" },
          { uz: "Gaz bilan payvandlash uchun", ru: "Газовая сварка" }
        ],
        correct: 0,
        explanation: {
          uz: "3.23-band: Ustunsimon chok (stake weld) gorizontal listdan vertikal listga lazer yoki elektron nur ta'sirida olinadi.",
          ru: "Пункт 3.23: Столбчатый шов (stake weld) получают воздействием лазерного или электронного луча."
        }
      },
      {
        question: {
          uz: "Agar uchma-uch chokda oʻlcham koʻrsatilmagan boʻlsa, standart boʻyicha u qanday eritilishi shart?",
          ru: "Каким должно быть проплавление стыкового шва, если размеры поперечного сечения не указаны?"
        },
        options: [
          { uz: "Toʻliq eritish (полное проплавление) bilan", ru: "С полным проплавлением" },
          { uz: "Qalinlikning yarmigacha", ru: "На половину толщины" },
          { uz: "Faqat sirtqi qismidan", ru: "Только поверхностно" }
        ],
        correct: 0,
        explanation: {
          uz: "1-jadval 'b' izohi va 5.4.1-band: Agar boshqa oʻlcham berilmagan boʻlsa, uchma-uch choklar toʻliq eritilishi (полное проплавление) shart.",
          ru: "Примечание b к табл. 1 и п. 5.4.1: Стыковые швы являются швами с полным проплавлением, если отсутствуют иные указания."
        }
      }
    ]
  },
  {
    id: "2553-supp",
    pdfPage: 13,
    title: {
      uz: "4. Qoʻshimcha belgilar: Yuza shakli, Taglik (M/MR), Montaj (3-jadval)",
      ru: "4. Вспомогательные обозначения: Форма, Подкладка M/MR, Монтаж (Табл. 3)"
    },
    theory: {
      uz: "3-jadvaldagi muhim qoʻshimcha belgilar:
• Chok yuzasi: Tekis (—), Qavariq (tashqariga yoy), Botiq (ichkariga yoy), Silliq oʻtish (плавный переход).
• Ildiz qavariqligi (№6): Bir tomonlama chokning ildiz (orqa) tomonida minimal qavariqlik talab qilinsa, asosiy belgining qarama-qarshi tomoniga yarim doira qoʻyiladi.
• Tagliklar (Podkladka, №7): [M] — chok ostida doimiy qoladigan taglik (остающаяся подкладка); [MR] — payvandlashdan keyin olib tashlanadigan vaqtinchalik taglik (съемная подкладка).
• Yopiq kontur (№10): Strelka va tokcha kesishmasida aylana (○).
• Ikki nuqta orasidagi chok (№11): A ↔ B yozuvi (masalan, A nuqtadan B nuqtagacha uzluksiz).
• Montaj choki (№12): Kesishish nuqtasida qora bayroqcha (⚑).
• Shaxmat tartibidagi uzuq-uzuq chok (№13): Tokcha chizigʻida Z-simon belgi.",
      ru: "Вспомогательные обозначения (Таблица 3):
• Форма поверхности: плоская (—), выпуклая, вогнутая, плавный переход.
• Выпуклость корня шва (№6): полукруг на противоположной стороне линии полки.
• Подкладки (№7): M — остающаяся подкладка; MR — съемная/временная подкладка (удаляется после сварки).
• По замкнутому контуру (№10): окружность в узле стрелки и полки.
• Шов между двумя точками (№11): A ↔ B.
• Монтажный шов (№12): флажок в месте соединения стрелки и полки.
• Шахматный прерывистый шов (№13): знак Z по линии полки."
    },
    items: [
      {
        name: { uz: "Tagliklar: [M] va [MR] (3-jadval, №7)", ru: "Подкладки: [M] и [MR] (Таблица 3, №7)" },
        desc: { uz: "M = qoladigan taglik | MR = olib tashlanadigan taglik", ru: "M = остающаяся | MR = съемная (удаляемая)" },
        symbolSvg: `<svg viewBox="0 0 240 85"><line x1="20" y1="35" x2="220" y2="35" stroke="#38bdf8" stroke-width="2"/><path d="M55,15 L68,35 L81,15" fill="none" stroke="#f59e0b" stroke-width="2.5"/><rect x="53" y="35" width="30" height="18" fill="none" stroke="#22c55e" stroke-width="2"/><text x="61" y="48" fill="#22c55e" font-size="11" font-weight="bold">M</text><path d="M145,15 L158,35 L171,15" fill="none" stroke="#f59e0b" stroke-width="2.5"/><rect x="140" y="35" width="36" height="18" fill="none" stroke="#ef4444" stroke-width="2"/><text x="147" y="48" fill="#ef4444" font-size="11" font-weight="bold">MR</text></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 240 85"><rect x="30" y="20" width="75" height="25" fill="#475569"/><rect x="135" y="20" width="75" height="25" fill="#475569"/><polygon points="105,20 135,20 123,45 117,45" fill="#f59e0b"/><rect x="95" y="45" width="50" height="10" fill="#22c55e"/><text x="72" y="70" fill="#22c55e" font-size="10">Taglik (Podkladka)</text></svg>`
      },
      {
        name: { uz: "Ildiz qavariqligi (3-rasm) va Z-shaxmat belgisi", ru: "Выпуклость корня (Рис. 3) и шахматный шов Z" },
        desc: { uz: "Ildiz tomonida yarim doira va shaxmat tartibi", ru: "Полукруг со стороны корня и символ Z" },
        symbolSvg: `<svg viewBox="0 0 240 85"><line x1="15" y1="42" x2="105" y2="42" stroke="#38bdf8" stroke-width="2.5"/><path d="M45,20 L58,42 L71,20" fill="none" stroke="#f59e0b" stroke-width="2.5"/><path d="M48,42 A10,10 0 0,0 68,42 Z" fill="#22c55e"/><line x1="130" y1="42" x2="225" y2="42" stroke="#38bdf8" stroke-width="2.5"/><polygon points="155,42 155,22 173,42" fill="none" stroke="#f59e0b" stroke-width="2"/><polygon points="185,42 185,62 203,42" fill="none" stroke="#f59e0b" stroke-width="2"/><text x="172" y="47" fill="#22c55e" font-size="14" font-weight="bold">Z</text></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 240 85"><rect x="30" y="25" width="180" height="25" fill="#475569"/><polygon points="100,25 140,25 125,50 115,50" fill="#f59e0b"/><path d="M113,50 Q120,62 127,50 Z" fill="#22c55e"/><text x="78" y="75" fill="#22c55e" font-size="10">Ildiz qavariqligi (3 mm)</text></svg>`
      }
    ],
    quiz: [
      {
        question: {
          uz: "Taglik (podkladka) belgisidagi [M] va [MR] harflari nimasi bilan farq qiladi?",
          ru: "В чем разница между обозначениями подкладки [M] и [MR] (Таблица 3, №7)?"
        },
        options: [
          { uz: "M — konstruksiyada doimiy qoladi, MR — payvandlashdan keyin olib tashlanadi", ru: "M — остающаяся подкладка, MR — съемная (удаляется после сварки)" },
          { uz: "M — mis taglik, MR — poʻlat taglik", ru: "M — медная, MR — стальная" },
          { uz: "M — montajda, MR — sexda qoʻyiladi", ru: "M — на монтаже, MR — в цеху" }
        ],
        correct: 0,
        explanation: {
          uz: "3-jadval 'f' izohi: M (Material) — yakuniy birikmada qoladigan material; MR (Material Removed) — payvandlashdan soʻng olib tashlanadigan material.",
          ru: "Примечание f к табл. 3: М — остающаяся подкладка; MR — материал, который будет удален после сварки."
        }
      },
      {
        question: {
          uz: "Yopiq kontur boʻylab payvandlash (aylana ○) belgisi QAYSI HOLATDA ishlatilmaydi?",
          ru: "В каком случае НЕ применяют обозначение сварки по замкнутому контуру (окружность)?"
        },
        options: [
          { uz: "Chok bir nuqtada boshlanib oʻsha nuqtada tugamasa yoki chok turi/oʻlchami oʻzgarsa", ru: "Если шов не непрерывный (не замкнут) или меняется тип/размер шва" },
          { uz: "Toʻrtburchak profilni plastinaga aylantirib payvandlaganda", ru: "При обварке прямоугольной трубы по периметру" },
          { uz: "Burchakli chok bajarilganda", ru: "При выполнении углового шва" }
        ],
        correct: 0,
        explanation: {
          uz: "4.5.2-band: Agar chok uzluksiz yopiq boʻlmasa yoki yoʻlda chok turi/qalinligi oʻzgarsa, aylana belgisi qoʻyilmaydi.",
          ru: "Пункт 4.5.2: Обозначение не применяют, если шов не является непрерывным или меняется тип/размер шва."
        }
      },
      {
        question: {
          uz: "Ikki tomonlama uzuq-uzuq choklarda shaxmat tartibini (bir tomondagi chok ikkinchi tomondagi boʻshliq qarshisida) qaysi belgi koʻrsatadi?",
          ru: "Какой символ на линии полки обозначает шахматный прерывистый сварной шов?"
        },
        options: [
          { uz: "Z belgisi", ru: "Символ Z" },
          { uz: "X belgisi", ru: "Символ X" },
          { uz: "S belgisi", ru: "Символ S" }
        ],
        correct: 0,
        explanation: {
          uz: "3-jadval №13 va 5.3.2.3-band: Shaxmat tartibidagi uzuq-uzuq choklar tokcha chizigʻida Z belgisi bilan koʻrsatiladi.",
          ru: "Таблица 3, №13 и п. 5.3.2.3: Шахматные прерывистые швы обозначают символом Z по линии полки."
        }
      },
      {
        question: {
          uz: "Aylana shaklidagi teshik yoki quvur aylanasi boʻylab payvandlashda yopiq kontur (○) belgisini qoʻyish shartmi?",
          ru: "Требуется ли ставить знак замкнутого контура (○) для сварных швов по окружности круглого отверстия?"
        },
        options: [
          { uz: "Yoʻq, shart emas", ru: "Нет, не требуется" },
          { uz: "Ha, har doim shart", ru: "Да, всегда обязательно" },
          { uz: "Faqat TIG payvandlashda shart", ru: "Только при сварке TIG" }
        ],
        correct: 0,
        explanation: {
          uz: "4.5.2-band oxirgi xatboshi: Doira/teshik aylanasi boʻylab bajariladigan choklar yopiq kontur belgisini talab qilmaydi.",
          ru: "Пункт 4.5.2: Сварные швы, выполняемые по окружности круглого сечения/отверстия, не требуют обозначения замкнутого контура."
        }
      },
      {
        question: {
          uz: "4-rasmdagi bir-biriga qarama-qarshi uchta strelka (A ↔ B) nimani bildiradi?",
          ru: "Что означает обозначение с двумя точками A ↔ B на линии полки (рис. 2)?"
        },
        options: [
          { uz: "Chok faqat A nuqtadan B nuqtagacha bajarilishini", ru: "Непрерывный шов, выполняемый только между точками А и В" },
          { uz: "Chokni ikki marta qoplab payvandlashni", ru: "Двухслойную сварку" },
          { uz: "A va B tizimlari birgalikda ekanini", ru: "Совмещение систем А и В" }
        ],
        correct: 0,
        explanation: {
          uz: "4.5.3-band: Yopiq boʻlmagan, faqat ikkita aniq chegara nuqtasi orasida bajariladigan choklar uchun A ↔ B belgisi qoʻllaniladi.",
          ru: "Пункт 4.5.3: Обозначение шва между двумя точками применяют для шва, выполняемого между А и В."
        }
      }
    ]
  },
  {
    id: "2553-dim",
    pdfPage: 21,
    title: {
      uz: "5. Oʻlchamlar (a, z, s, n×l(e)) va Qirra tayyorlash (b, α, h) (5–7-boʻlimlar)",
      ru: "5. Размеры швов (a, z, s, n×l(e)) и разделка кромок (b, α, h) (Разделы 5–7)"
    },
    theory: {
      uz: "Oʻlchamlar asosiy belgi bilan bir tomonda joylashadi:
• CHAPDA — koʻndalang kesim oʻlchamlari:
  - a: burchakli chok nominal qalinligi (ichki teng yonli uchburchak balandligi)
  - z: burchakli chok kateti (har xil katetli chokda: z1 4 z2 8)
  - s: chuqur eritish qalinligi (masalan, sa8) yoki uchma-uch chokda toʻliq boʻlmagan erish chuqurligi
  - h va s (9-jadval): h — qirra kesish chuqurligi, s — erish chuqurligi (masalan, h6 s8)
  - d: teshikli/nuqtali chok diametri | c: tirqish (prorez) yoki rolikli chok kengligi.
• OʻNGDA — uzunlik oʻlchamlari: n × l (e), bu yerda n — choklar soni, l — chok uzunligi, (e) — choklar orasidagi masofa.
• BELGI ICHIDA / TASHQARISIDA (6-boʻlim): b — tirqish (zazor, belgi ichida yoziladi); α — qirralar ochilish burchagi (masalan, 50°, belgi tashqarisida yoziladi).
• 7-boʻlim (11-jadval): Ichida X bor toʻrtburchak — qirra kesish turini zavodning oʻzi tanlaydi, muhimi koʻrsatilgan sifat darajasi (masalan, ISO 5817-B) ta'minlansin.",
      ru: "Размеры указывают на той же стороне линии полки, что и начальное обозначение:
• СЛЕВА — размеры поперечного сечения: 'a' (номинальная толщина углового шва), 'z' (катет), 's' (глубина проплавления или толщина с глубоким проплавлением sa), 'h' (глубина разделки кромок, напр. h6s8), 'd' (диаметр), 'c' (ширина прорези/роликового шва).
• СПРАВА — размеры длины: n × l (e), где n — количество участков, l — длина каждого участка, (e) — расстояние между участками.
• ПОДГОТОВКА КРОМОК (Раздел 6): зазор 'b' указывают внутри начального обозначения; угол разделки 'α' (например, 50°) — вне начального обозначения.
• РАЗДЕЛ 7 (Табл. 11): Прямоугольник с крестом (X) — альтернативное обозначение стыкового шва с требуемым качеством (разделку выбирает производство)."
    },
    items: [
      {
        name: { uz: "Burchakli chokda 'a' va 'z' farqi (6-jadval, №2.1)", ru: "Разница между 'a' и 'z' в угловом шве (Табл. 6, №2.1)" },
        desc: { uz: "a = uchburchak balandligi (≈ 0.7 × z) | z = katet uzunligi", ru: "a = высота вписанного треугольника | z = катет" },
        symbolSvg: `<svg viewBox="0 0 240 80"><line x1="15" y1="50" x2="225" y2="50" stroke="#38bdf8" stroke-width="2"/><text x="45" y="42" fill="#22c55e" font-size="15" font-weight="bold">a5</text><polygon points="52,50 52,26 76,50" fill="none" stroke="#f59e0b" stroke-width="2.5"/><text x="145" y="42" fill="#38bdf8" font-size="15" font-weight="bold">z7</text><polygon points="152,50 152,26 176,50" fill="none" stroke="#f59e0b" stroke-width="2.5"/></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 240 80"><rect x="40" y="62" width="160" height="12" fill="#475569"/><rect x="85" y="12" width="14" height="50" fill="#64748b"/><polygon points="99,62 99,26 135,62" fill="#f59e0b" opacity="0.8"/><line x1="99" y1="62" x2="117" y2="44" stroke="#22c55e" stroke-width="2.5"/><text x="122" y="40" fill="#22c55e" font-size="11" font-weight="bold">a</text><text x="110" y="73" fill="#38bdf8" font-size="11" font-weight="bold">z</text></svg>`
      },
      {
        name: { uz: "Zazor 'b', Burchak '50°' va Sifat belgisi [X]", ru: "Зазор 'b', Угол '50°' и Качество [X] (Табл. 7, 8, 11)" },
        desc: { uz: "b — belgi ichida | 50° — belgi ustida | [X] — erkin razdelka", ru: "b — внутри символа | 50° — снаружи | [X] — по качеству" },
        symbolSvg: `<svg viewBox="0 0 240 85"><line x1="15" y1="55" x2="225" y2="55" stroke="#38bdf8" stroke-width="2"/><path d="M50,25 L68,55 L86,25" fill="none" stroke="#f59e0b" stroke-width="2.5"/><text x="58" y="20" fill="#22c55e" font-size="11" font-weight="bold">50°</text><text x="64" y="42" fill="#38bdf8" font-size="11" font-weight="bold">b</text><rect x="145" y="31" width="24" height="24" fill="none" stroke="#f59e0b" stroke-width="2.5"/><line x1="145" y1="31" x2="169" y2="55" stroke="#f59e0b" stroke-width="2"/><line x1="169" y1="31" x2="145" y2="55" stroke="#f59e0b" stroke-width="2"/></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 240 85"><polygon points="30,22 72,22 90,58 30,58" fill="#475569"/><polygon points="160,22 118,22 100,58 160,58" fill="#475569"/><text x="87" y="18" fill="#22c55e" font-size="11">50°</text><text x="91" y="72" fill="#38bdf8" font-size="11">b (zazor)</text></svg>`
      }
    ],
    quiz: [
      {
        question: {
          uz: "Uzuq-uzuq chokdagi '4 × 100 (200)' yozuvida qavs ichidagi '(200)' nimani anglatadi?",
          ru: "Что означает число в скобках '(200)' в записи прерывистого шва '4 × 100 (200)'?"
        },
        options: [
          { uz: "Chok uchastkalari orasidagi payvandlanmagan boʻsh masofa (e = 200 mm)", ru: "Расстояние между участками шва (промежуток e = 200 мм)" },
          { uz: "Har bir chokning uzunligi", ru: "Длина каждого участка шва" },
          { uz: "Choklarning umumiy soni", ru: "Общее количество швов" }
        ],
        correct: 0,
        explanation: {
          uz: "5.3.2.1-band: n = 4 (choklar soni), l = 100 mm (har bir chok uzunligi), (e) = 200 mm (choklar orasidagi masofa).",
          ru: "Пункт 5.3.2.1: n — количество участков, l — длина каждого участка, (e) — расстояние между участками."
        }
      },
      {
        question: {
          uz: "Uchma-uch chokda qirralar orasidagi tirqish (zazor 'b') shartli belgining qayeriga yoziladi?",
          ru: "Где указывается размер зазора 'b' стыкового соединения (Таблица 7)?"
        },
        options: [
          { uz: "Boshlangʻich belgining ichiga (masalan, || yoki V ichiga)", ru: "Внутри начального обозначения" },
          { uz: "Boshlangʻich belgining chap tomoniga", ru: "Слева от начального обозначения" },
          { uz: "Tokcha chizigʻining ostiga", ru: "Под линией полки" }
        ],
        correct: 0,
        explanation: {
          uz: "6.2-band va 7-jadval: Zazor 'b' boshlangʻich belgining ichiga yoziladi.",
          ru: "Пункт 6.2 и Таблица 7: Зазор b стыкового соединения может быть указан внутри начального обозначения."
        }
      },
      {
        question: {
          uz: "Qirralarni ochish burchagi (masalan, 50° yoki 60°) shartli belgining qayeriga yoziladi?",
          ru: "Где располагается угол разделки кромок α (например, 50°) согласно п. 6.3 и Таблице 8?"
        },
        options: [
          { uz: "Boshlangʻich belgining tashqarisiga (ochiq tomoniga)", ru: "Вне начального обозначения" },
          { uz: "Belgining chap tomoniga", ru: "Слева от символа" },
          { uz: "Belgining oʻng tomoniga", ru: "Справа от символа" }
        ],
        correct: 0,
        explanation: {
          uz: "6.3-band: Qirralarni ochish burchagi α boshlangʻich belgining tashqarisida koʻrsatiladi.",
          ru: "Пункт 6.3: Угол разделки кромок α располагают вне начального обозначения."
        }
      },
      {
        question: {
          uz: "7-boʻlim (11-jadval) dagi ichida 'X' chizilgan toʻrtburchak belgisi nimani bildiradi?",
          ru: "Что означает альтернативное обозначение в виде прямоугольника с крестом (Таблица 11)?"
        },
        options: [
          { uz: "Qirra kesish turini zavodning oʻzi tanlaydi, asosiysi talab qilingan chok sifati (masalan, ISO 5817-B) bajarilsin", ru: "Стыковой шов, где разделка кромок не определена (выбирается производством под требуемое качество)" },
          { uz: "Bu chokni payvandlash taqiqlangan", ru: "Сварка данного шва запрещена" },
          { uz: "Nuqtali kontakt payvandlash", ru: "Контактная точечная сварка" }
        ],
        correct: 0,
        explanation: {
          uz: "7.1-band: Ushbu belgi faqat uchma-uch choklar uchun qoʻllaniladi — razdelka va jarayonni ishlab chiqarish boʻlimi oʻzi tanlaydi.",
          ru: "Пункт 7.1: Подготовку соединения и процесс сварки определяет производство для соблюдения требований качества."
        }
      },
      {
        question: {
          uz: "Uchma-uch chok chap tomonida 'h6 s8' yozilgan boʻlsa, 'h' va 's' nimani bildiradi?",
          ru: "Что означают буквы 'h' и 's' в записи 'h6 s8' слева от символа стыкового шва (Таблица 9)?"
        },
        options: [
          { uz: "h = qirra kesish chuqurligi (6 mm), s = talab qilingan erish chuqurligi (8 mm)", ru: "h = глубина разделки кромок (6 мм), s = требуемая глубина проплавления (8 мм)" },
          { uz: "h = chok balandligi, s = chok kengligi", ru: "h = высота шва, s = ширина шва" },
          { uz: "h = elektrod diametri, s = tok kuchi", ru: "h = диаметр электрода, s = сила тока" }
        ],
        correct: 0,
        explanation: {
          uz: "6.5-band va 9-jadval: 'h' harfi qirra kesish chuqurligini, 's' harfi esa talab qilingan erish chuqurligini bildiradi.",
          ru: "Пункт 6.5 и Таблица 9: h — глубина разделки кромок, s — требуемая глубина проплавления."
        }
      }
    ]
  }
];
