export const iso6947Topics = [
  {
    id: "6947-main",
    pdfPage: 6,
    title: {
      uz: "1. Asosiy payvandlash holatlari: PA, PB, PC, PD, PE, PF, PG, PH, PJ, PK",
      ru: "1. Основные положения при сварке: PA, PB, PC, PD, PE, PF, PG, PH, PJ, PK"
    },
    theory: {
      uz: "ГОСТ Р ИСО 6947-2017 standartida payvandlash holatlari birikma turiga (uchma-uch yoki burchakli) bogʻliq emas, balki chok oʻqi va sirtining fazodagi burchagiga bogʻliq:
• PA (0°) — Pastki holat (нижнее): listlar gorizontal, payvandlash yuqoridan pastga qarab bajariladi.
• PB (45° / 315°) — Tavr va vertikal oʻqli quvurlarda gorizontal holat.
• PC (90° / 270°) — Gorizontal holat (devordagi gorizontal chok yoki vertikal quvurdagi aylana chok).
• PD (135° / 225°) — Tavr va vertikal oʻqli quvurlarda shift (yuqori burchak) holati.
• PE (180°) — Shift holati (потолочное): payvandchi pastdan yuqoriga qarab shiftga payvandlaydi.
• PF — Vertikal holat, PASTDAN YUQORIGA (снизу вверх).
• PG — Vertikal holat, YUQORIDAN PASTGA (сверху вниз).
• PH — Qoʻzgʻalmas gorizontal quvurda PASTDAN YUQORIGA (неповоротная труба снизу вверх).
• PJ — Qoʻzgʻalmas gorizontal quvurda YUQORIDAN PASTGA (неповоротная труба сверху вниз).
• PK — Orbital payvandlash (avtomat kallak quvur atrofida aylanadi).",
      ru: "Согласно ГОСТ Р ИСО 6947-2017 основные положения при сварке:
• PA (0°) — Нижнее положение.
• PB (45° / 315°) — Горизонтальное тавровых соединений и горизонтальное при вертикальной оси трубы.
• PC (90° / 270°) — Горизонтальное положение.
• PD (135° / 225°) — Потолочное тавровых соединений и потолочное при вертикальной оси трубы.
• PE (180°) — Потолочное положение.
• PF — Вертикальное снизу вверх.
• PG — Вертикальное сверху вниз.
• PH — Вертикальное снизу вверх (труба неповоротная).
• PJ — Вертикальное сверху вниз (труба неповоротная).
• PK — Положение трубы при орбитальной сварке."
    },
    items: [
      {
        name: { uz: "Soat siferblati diagrammasi (1-rasm)", ru: "Круговая диаграмма положений (Рисунок 1)" },
        desc: { uz: "0° = PA | 45° = PB | 90° = PC | 135° = PD | 180° = PE", ru: "0° = PA | 45° = PB | 90° = PC | 135° = PD | 180° = PE" },
        symbolSvg: `<svg viewBox="0 0 220 155"><circle cx="110" cy="78" r="46" fill="none" stroke="#38bdf8" stroke-width="2"/><line x1="110" y1="22" x2="110" y2="134" stroke="#334155" stroke-dasharray="3,3"/><line x1="54" y1="78" x2="166" y2="78" stroke="#334155" stroke-dasharray="3,3"/><line x1="72" y1="40" x2="148" y2="116" stroke="#334155" stroke-dasharray="3,3"/><line x1="148" y1="40" x2="72" y2="116" stroke="#334155" stroke-dasharray="3,3"/><text x="95" y="17" fill="#22c55e" font-size="11" font-weight="bold">PA 0°</text><text x="155" y="40" fill="#f59e0b" font-size="10" font-weight="bold">PB 45°</text><text x="163" y="81" fill="#38bdf8" font-size="11" font-weight="bold">PC 90°</text><text x="152" y="122" fill="#f59e0b" font-size="10" font-weight="bold">PD 135°</text><text x="92" y="148" fill="#ef4444" font-size="11" font-weight="bold">PE 180°</text><text x="12" y="81" fill="#38bdf8" font-size="10">PC 270°</text></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 220 155"><rect x="20" y="55" width="75" height="10" fill="#475569"/><rect x="52" y="20" width="10" height="35" fill="#64748b"/><polygon points="62,55 62,42 75,55" fill="#f59e0b"/><text x="38" y="80" fill="#f59e0b" font-size="11" font-weight="bold">PB (45°)</text><rect x="125" y="100" width="75" height="10" fill="#475569"/><rect x="157" y="110" width="10" height="35" fill="#64748b"/><polygon points="167,110 167,123 180,110" fill="#ef4444"/><text x="142" y="93" fill="#ef4444" font-size="11" font-weight="bold">PD (135°)</text></svg>`
      },
      {
        name: { uz: "PF vs PG (Plastina) va PH vs PJ (Qoʻzgʻalmas quvur)", ru: "PF vs PG (Пластина) и PH vs PJ (Неповоротная труба)" },
        desc: { uz: "PF/PH: pastdan yuqoriga ↑ | PG/PJ: yuqoridan pastga ↓", ru: "PF/PH: снизу вверх ↑ | PG/PJ: сверху вниз ↓" },
        symbolSvg: `<svg viewBox="0 0 220 125"><rect x="20" y="15" width="45" height="80" fill="#334155"/><line x1="42" y1="85" x2="42" y2="25" stroke="#22c55e" stroke-width="3.5"/><polygon points="42,20 36,32 48,32" fill="#22c55e"/><text x="28" y="112" fill="#22c55e" font-size="12" font-weight="bold">PF ↑</text><rect x="85" y="15" width="45" height="80" fill="#334155"/><line x1="107" y1="25" x2="107" y2="85" stroke="#f59e0b" stroke-width="3.5"/><polygon points="107,90 101,78 113,78" fill="#f59e0b"/><text x="93" y="112" fill="#f59e0b" font-size="12" font-weight="bold">PG ↓</text><circle cx="175" cy="55" r="30" fill="none" stroke="#64748b" stroke-width="7"/><path d="M175,85 A30,30 0 0,1 175,25" fill="none" stroke="#38bdf8" stroke-width="3"/><text x="155" y="112" fill="#38bdf8" font-size="11" font-weight="bold">PH / PJ</text></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 220 125"><circle cx="110" cy="60" r="34" fill="none" stroke="#64748b" stroke-width="8"/><circle cx="110" cy="60" r="42" fill="none" stroke="#f59e0b" stroke-width="2" stroke-dasharray="6,4"/><polygon points="110,14 118,22 102,22" fill="#f59e0b"/><text x="62" y="114" fill="#f59e0b" font-size="11" font-weight="bold">PK — Orbital payvandlash</text></svg>`
      }
    ],
    quiz: [
      {
        question: {
          uz: "Tavr (T-simon) birikmada pastki gorizontal listga tik turgan devorni payvandlash (45°) qanday belgilanadi?",
          ru: "Как обозначается горизонтальное положение при сварке таврового соединения (наклон 45°)?"
        },
        options: [
          { uz: "PB", ru: "PB" },
          { uz: "PA", ru: "PA" },
          { uz: "PD", ru: "PD" }
        ],
        correct: 0,
        explanation: {
          uz: "1-rasm (2 va 8-pozitsiyalar): Tavr birikmalarda gorizontal chok va vertikal oʻqli quvurda gorizontal chok — PB.",
          ru: "Рисунок 1 (позиции 2 и 8): Горизонтальное тавровых соединений и горизонтальное при вертикальном положении осей труб — PB."
        }
      },
      {
        question: {
          uz: "Tavr (T-simon) birikmada shift ostida (135° / 225°) payvandlash qaysi harflar bilan belgilanadi?",
          ru: "Какое обозначение соответствует потолочному положению тавровых соединений (135° / 225°)?"
        },
        options: [
          { uz: "PD", ru: "PD" },
          { uz: "PE", ru: "PE" },
          { uz: "PB", ru: "PB" }
        ],
        correct: 0,
        explanation: {
          uz: "1-rasm (4 va 6-pozitsiyalar): Tavr birikmalar va vertikal quvurlarning shift holati — PD; tekis (uchma-uch) shift holati esa — PE.",
          ru: "Рисунок 1 (позиции 4 и 6): Потолочное тавровых соединений и при вертикальной оси труб — PD."
        }
      },
      {
        question: {
          uz: "Qoʻzgʻalmas gorizontal quvurni YUQORIDAN PASTGA qarab aylantirib payvandlash qanday belgilanadi?",
          ru: "Как обозначается сварка неповоротной горизонтальной трубы сверху вниз?"
        },
        options: [
          { uz: "PJ", ru: "PJ" },
          { uz: "PH", ru: "PH" },
          { uz: "PG", ru: "PG" }
        ],
        correct: 0,
        explanation: {
          uz: "2-rasm i): Qoʻzgʻalmas quvurda pastdan yuqoriga — PH, yuqoridan pastga — PJ.",
          ru: "Рисунок 2 i): Вертикальное сверху вниз (труба неповоротная) — PJ."
        }
      },
      {
        question: {
          uz: "Vertikal holatda payvandlash yoʻnalishi (pastdan yuqoriga yoki yuqoridan pastga) qaysi harflar bilan farqlanadi?",
          ru: "Какими обозначениями различают направление вертикальной сварки (снизу вверх и сверху вниз)?"
        },
        options: [
          { uz: "PF — pastdan yuqoriga, PG — yuqoridan pastga", ru: "PF — снизу вверх, PG — сверху вниз" },
          { uz: "PG — pastdan yuqoriga, PF — yuqoridan pastga", ru: "PG — снизу вверх, PF — сверху вниз" },
          { uz: "PA — pastdan yuqoriga, PE — yuqoridan pastga", ru: "PA — снизу вверх, PE — сверху вниз" }
        ],
        correct: 0,
        explanation: {
          uz: "2-rasm f) va g): PF — vertikal pastdan yuqoriga, PG — vertikal yuqoridan pastga.",
          ru: "Рисунок 2 f) и g): PF — вертикальное снизу вверх, PG — вертикальное сверху вниз."
        }
      },
      {
        question: {
          uz: "PK belgisi nimani anglatadi?",
          ru: "Что обозначает символ PK?"
        },
        options: [
          { uz: "Quvurni orbital payvandlash holati", ru: "Положение трубы при орбитальной сварке" },
          { uz: "Qiya quvurda 45° payvandlash", ru: "Сварка трубы под углом 45°" },
          { uz: "Nuqtali kontakt payvandlash", ru: "Контактная точечная сварка" }
        ],
        correct: 0,
        explanation: {
          uz: "2-rasm j): PK — maxsus maqsadlar (masalan, payvandchilar sinovi) uchun quvurni orbital payvandlash holati.",
          ru: "Рисунок 2 j): PK — положение трубы при орбитальной сварке."
        }
      }
    ]
  },
  {
    id: "6947-angles",
    pdfPage: 10,
    title: {
      uz: "2. Nishab (S), Burilish (R), Ruxsat etilgan ogʻishlar va Qiya quvurlar (H-L045)",
      ru: "2. Наклон (S), Поворот (R), Допуски и наклонные трубы (H-L045)"
    },
    theory: {
      uz: "Standartda uchta burchak tushunchasi mavjud (2-boʻlim):
• S (Slope — nishablik): Chok oʻqining gorizontal tekislikka nisbatan nishablik burchagi.
• R (Rotation — burilish): Chok yuzasining oʻz oʻqi atrofida burilish burchagi.
• L (Inclined angle): Quvur oʻqining gorizontga nisbatan qiyalik burchagi.

1. Malaka imtihonlarida (3.3-band): Sinov namunalarini payvandlashda nishab burchagi S = ±5° dan, burilish burchagi R = ±10° dan oshmasligi shart!
2. Ishlab chiqarishda (1 va 2-jadvallar):
  - PA (pastki): S = ±15°, R = ±30°
  - PC (uchma-uch gorizontal): S = ±15°, R = +60° / −10°
  - PE (shift): S = ±80°, R = ±80° (uchma-uch chokda)
  - PF, PG (vertikal): S = +75° / −10°, R = ±100° / ±180°.
3. Qiya quvurlar yozuvi (4-boʻlim): 'H-L045' — qoʻzgʻalmas quvur oʻqi 45° qiya (L045), payvandlash yoʻnalishi pastdan yuqoriga (H). Agar yuqoridan pastga boʻlsa — 'J-L060' (60° qiya, yuqoridan pastga).",
      ru: "В разделе 2 определены три угла:
• S (Наклон) — угол наклона оси сварного шва.
• R (Поворот) — угол поворота лицевой поверхности шва.
• L (Угол наклона трубы) — угол наклона оси трубы.

1. При испытаниях сварщиков (п. 3.3): допуск по наклону S = ±5°, по повороту R = ±10°.
2. В производстве (Таблицы 1 и 2):
  - PA: S = ±15°, R = ±30°
  - PC (стыковой): S = ±15°, R = +60° / −10°
  - PE (стыковой): S = ±80°, R = ±80°
  - PF, PG: S = +75° / −10°, R = ±100° / ±180°.
3. Обозначение наклонных труб (Раздел 4): H-L030 (снизу вверх H, наклон 30°); J-L060 (сверху вниз J, наклон 60°); PB 015-010 (основное PB, наклон 15°, поворот 10°)."
    },
    items: [
      {
        name: { uz: "H-L045 va J-L045 (Qiya oʻqli qoʻzgʻalmas quvurlar)", ru: "H-L045 и J-L045 (Трубы с наклонной осью)" },
        desc: { uz: "H = pastdan yuqoriga | J = yuqoridan pastga | L045 = 45° burchak", ru: "H = снизу вверх | J = сверху вниз | L045 = угол 45°" },
        symbolSvg: `<svg viewBox="0 0 240 110"><line x1="20" y1="95" x2="220" y2="95" stroke="#475569" stroke-width="2"/><line x1="65" y1="95" x2="155" y2="15" stroke="#38bdf8" stroke-width="14"/><line x1="98" y1="48" x2="118" y2="68" stroke="#f59e0b" stroke-width="5"/><path d="M105,95 A35,35 0 0,0 92,70" fill="none" stroke="#22c55e" stroke-width="2"/><text x="115" y="88" fill="#22c55e" font-size="12" font-weight="bold">L = 45°</text><text x="155" y="55" fill="#f59e0b" font-size="13" font-weight="bold">H-L045</text></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 240 110"><text x="15" y="28" fill="#22c55e" font-size="11" font-weight="bold">Sinov (Imtihon): S = ±5°, R = ±10°</text><text x="15" y="52" fill="#38bdf8" font-size="11" font-weight="bold">Ishlab chiqarish PA: S = ±15°, R = ±30°</text><text x="15" y="76" fill="#f59e0b" font-size="11" font-weight="bold">PB 015-010: PB + nishab 15° + burilish 10°</text></svg>`
      }
    ],
    quiz: [
      {
        question: {
          uz: "Payvandchilarni attestatsiyadan oʻtkazishda (sinov namunalarini payvandlashda) nishab S va burilish R ogʻishlari qancha boʻlishi mumkin?",
          ru: "Каковы предельные отклонения наклона (S) и поворота (R) при сварке испытательных образцов (п. 3.3)?"
        },
        options: [
          { uz: "Nishab S = ±5°, Burilish R = ±10°", ru: "Наклон S = ±5°, поворот R = ±10°" },
          { uz: "Nishab S = ±15°, Burilish R = ±30°", ru: "Наклон S = ±15°, поворот R = ±30°" },
          { uz: "Nishab S = ±45°, Burilish R = ±45°", ru: "Наклон S = ±45°, поворот R = ±45°" }
        ],
        correct: 0,
        explanation: {
          uz: "3.3-band: Sinov namunalari uchun burchak ogʻishlari nishab boʻyicha ±5° dan va burilish boʻyicha ±10° dan oshmasligi kerak.",
          ru: "Пункт 3.3: Положения при сварке испытательных образцов не должны выходить за пределы наклона ±5° и поворота ±10°."
        }
      },
      {
        question: {
          uz: "'J-L060' belgisi nimani anglatadi?",
          ru: "Что означает обозначение 'J-L060' (Раздел 4, Пример 4)?"
        },
        options: [
          { uz: "Oʻqi 60° qiya oʻrnatilgan quvurni yuqoridan pastga qarab payvandlash", ru: "Сварка трубы с углом наклона оси 60° в направлении сверху вниз (J)" },
          { uz: "Oʻqi 60° qiya quvurni pastdan yuqoriga payvandlash", ru: "Сварка трубы под углом 60° снизу вверх" },
          { uz: "60 mm diametrli quvurni gorizontal payvandlash", ru: "Горизонтальная сварка трубы диаметром 60 мм" }
        ],
        correct: 0,
        explanation: {
          uz: "4-boʻlim, 4-misol: J — yuqoridan pastga yoʻnalish, L060 — quvur oʻqining 60° nishablik burchagi.",
          ru: "Раздел 4, Пример 4: J — направление сверху вниз, L060 — угол наклона оси трубы 60°."
        }
      },
      {
        question: {
          uz: "'PB 015-010' yozuvidagi uch xonali sonlar ('015' va '010') nimani bildiradi?",
          ru: "Что означают трехзначные числа в обозначении 'PB 015-010' (Раздел 4, Пример 2)?"
        },
        options: [
          { uz: "Asosiy PB holatiga nisbatan 15° nishablik (S) va 10° burilish (R)", ru: "Наклон 15° (S) и поворот 10° (R) относительно основного положения PB" },
          { uz: "Elektrod uzunligi 150 mm va diametri 10 mm", ru: "Длина электрода 150 мм и диаметр 10 мм" },
          { uz: "Chok uzunligi 15 sm va qalinligi 10 mm", ru: "Длина шва 15 см и толщина 10 мм" }
        ],
        correct: 0,
        explanation: {
          uz: "4-boʻlim, 2-misol: Asosiy holat belgisidan keyin uchta raqam bilan nishab va burilish burchaklari koʻrsatiladi.",
          ru: "Раздел 4, Пример 2: Обозначение основного положения дополнено значениями углов наклона (15°) и поворота (10°)."
        }
      },
      {
        question: {
          uz: "Ishlab chiqarishda pastki holat (PA) uchun nishab S va burilish R ruxsat etilgan chegaralari (1 va 2-jadvallar) qancha?",
          ru: "Каковы предельные значения наклона (S) и поворота (R) для нижнего положения (PA) в производстве?"
        },
        options: [
          { uz: "S = ±15°, R = ±30°", ru: "S = ±15°, R = ±30°" },
          { uz: "S = ±5°, R = ±10°", ru: "S = ±5°, R = ±10°" },
          { uz: "S = ±80°, R = ±80°", ru: "S = ±80°, R = ±80°" }
        ],
        correct: 0,
        explanation: {
          uz: "1 va 2-jadvallar: Ishlab chiqarishda PA holati uchun nishab ±15° gacha va burilish ±30° gacha ruxsat etiladi.",
          ru: "Таблицы 1 и 2: Для нижнего положения PA в производстве пределы составляют S = ±15°, R = ±30°."
        }
      },
      {
        question: {
          uz: "Ishlab chiqarishda uchma-uch choklarni shift holatida (PE) payvandlashda S va R burchak chegaralari qancha?",
          ru: "Каковы предельные углы S и R для потолочного положения (PE) производственных стыковых швов (Таблица 1)?"
        },
        options: [
          { uz: "S = ±80°, R = ±80°", ru: "S = ±80°, R = ±80°" },
          { uz: "S = ±15°, R = ±30°", ru: "S = ±15°, R = ±30°" },
          { uz: "S = ±5°, R = ±10°", ru: "S = ±5°, R = ±10°" }
        ],
        correct: 0,
        explanation: {
          uz: "1-jadval: Uchma-uch shift choklarida (PE) nishab ham, burilish ham ±80° gacha ruxsat etiladi.",
          ru: "Таблица 1: Для потолочного положения (PE) стыковых швов S = ±80°, R = ±80°."
        }
      }
    ]
  },
  {
    id: "6947-aws",
    pdfPage: 17,
    title: {
      uz: "3. ISO 6947 va Amerika (AWS / ASME 1G–6G, 1F–5F) taqqoslash jadvali (Ilova B)",
      ru: "3. Сравнение обозначений ISO 6947 и AWS / ASME 1G–6G, 1F–5F (Приложение В)"
    },
    theory: {
      uz: "Xalqaro ish beruvchilar va loyihalarda koʻpincha Amerika standartidagi (AWS A3.0 / ASME IX) belgilar uchraydi (G = Groove / uchma-uch chok, F = Fillet / burchakli chok, R = Rotated / aylantiriladigan quvur):
• 1G / 1F / 1FR = PA (Pastki holat)
• 2F / 2FR = PB (Tavr gorizontal va gorizontal oʻqli aylanadigan quvur)
• 2G = PC (Gorizontal holat)
• 4F = PD (Tavr shift holati)
• 4G = PE (Shift holati)
• 3G uphill / 3F uphill = PF (Vertikal pastdan yuqoriga)
• 3G downhill / 3F downhill = PG (Vertikal yuqoridan pastga)
• 5G uphill / 5F uphill = PH (Qoʻzgʻalmas quvur pastdan yuqoriga)
• 5G downhill / 5F downhill = PJ (Qoʻzgʻalmas quvur yuqoridan pastga)
• 6G uphill = H-L045 | 6G downhill = J-L045 (45° qiya qoʻzgʻalmas quvur).",
      ru: "Таблица В.1 сопоставляет международные обозначения ISO 6947 с американскими стандартами AWS A3.0 и ASME IX (G — стыковой, F — угловой):
• 1G / 1F / 1FR = PA
• 2F / 2FR = PB
• 2G = PC
• 4F = PD
• 4G = PE
• 3G uphill / 3F uphill = PF
• 3G downhill / 3F downhill = PG
• 5G uphill / 5F uphill = PH
• 5G downhill / 5F downhill = PJ
• 6G uphill = H-L045 | 6G downhill = J-L045."
    },
    items: [
      {
        name: { uz: "1G–6G (Uchma-uch) va 1F–5F (Burchakli) muvofiqlik jadvali", ru: "Таблица соответствия 1G–6G и 1F–5F стандарту ISO" },
        desc: { uz: "ISO 9606-1 sertifikat imtihonlari uchun eng muhim jadval", ru: "Ключевая таблица для аттестации по ISO 9606-1" },
        symbolSvg: `<svg viewBox="0 0 240 125"><text x="12" y="22" fill="#38bdf8" font-size="11" font-weight="bold">1G / 1F = PA</text><text x="12" y="42" fill="#38bdf8" font-size="11" font-weight="bold">2G = PC | 2F = PB</text><text x="12" y="62" fill="#22c55e" font-size="11" font-weight="bold">3G/3F ↑ = PF | ↓ = PG</text><text x="12" y="82" fill="#f59e0b" font-size="11" font-weight="bold">4G = PE | 4F = PD</text><text x="12" y="102" fill="#f59e0b" font-size="11" font-weight="bold">5G/5F ↑ = PH | ↓ = PJ</text><text x="12" y="120" fill="#ef4444" font-size="11" font-weight="bold">6G ↑ = H-L045 | ↓ = J-L045</text></svg>`,
        crossSectionSvg: `<svg viewBox="0 0 240 125"><line x1="30" y1="105" x2="210" y2="105" stroke="#475569" stroke-width="2"/><line x1="75" y1="105" x2="165" y2="25" stroke="#38bdf8" stroke-width="14"/><line x1="110" y1="55" x2="130" y2="75" stroke="#f59e0b" stroke-width="5"/><text x="135" y="92" fill="#ef4444" font-size="12" font-weight="bold">6G = H-L045</text></svg>`
      }
    ],
    quiz: [
      {
        question: {
          uz: "Amerika standartidagi '6G uphill' (45° qiya qoʻzgʻalmas quvurni pastdan yuqoriga payvandlash) ISO 6947 da qanday yoziladi?",
          ru: "Какому обозначению по ИСО 6947 соответствует американское '6G uphill'?"
        },
        options: [
          { uz: "H-L045", ru: "H-L045" },
          { uz: "J-L045", ru: "J-L045" },
          { uz: "PH-045", ru: "PH-045" }
        ],
        correct: 0,
        explanation: {
          uz: "B.1-jadval: 6G uphill = H-L045; 6G downhill = J-L045.",
          ru: "Таблица В.1: 6G uphill (снизу вверх) соответствует H-L045."
        }
      },
      {
        question: {
          uz: "ASME/AWS standartidagi '2G' va '2F' holatlari ISO 6947 da qaysi belgilarga mos keladi?",
          ru: "Каким обозначениям ИСО 6947 соответствуют '2G' и '2F'?"
        },
        options: [
          { uz: "2G = PC, 2F = PB", ru: "2G = PC, 2F = PB" },
          { uz: "2G = PB, 2F = PC", ru: "2G = PB, 2F = PC" },
          { uz: "2G = PE, 2F = PD", ru: "2G = PE, 2F = PD" }
        ],
        correct: 0,
        explanation: {
          uz: "B.1-jadval: 2G (uchma-uch gorizontal) = PC; 2F (tavr/burchakli gorizontal) = PB.",
          ru: "Таблица В.1: 2G соответствует PC, а 2F — PB."
        }
      },
      {
        question: {
          uz: "ASME/AWS standartidagi '4F' holati ISO 6947 da qanday belgilanadi?",
          ru: "Какому положению по ИСО 6947 соответствует американское '4F'?"
        },
        options: [
          { uz: "PD (Tavr birikmalarda shift holati)", ru: "PD (Потолочное тавровых соединений)" },
          { uz: "PE (Uchma-uch shift holati)", ru: "PE (Потолочное положение)" },
          { uz: "PF (Vertikal pastdan yuqoriga)", ru: "PF (Вертикальное снизу вверх)" }
        ],
        correct: 0,
        explanation: {
          uz: "B.1-jadval: 4F (burchakli/tavr shift) = PD, 4G (uchma-uch shift) = PE.",
          ru: "Таблица В.1: 4F соответствует PD, а 4G — PE."
        }
      },
      {
        question: {
          uz: "ASME/AWS standartidagi '5G uphill' holati ISO 6947 boʻyicha qaysi belgiga teng?",
          ru: "Какому обозначению ИСО 6947 соответствует '5G uphill'?"
        },
        options: [
          { uz: "PH", ru: "PH" },
          { uz: "PJ", ru: "PJ" },
          { uz: "PF", ru: "PF" }
        ],
        correct: 0,
        explanation: {
          uz: "B.1-jadval: 5G uphill (qoʻzgʻalmas gorizontal quvur pastdan yuqoriga) = PH.",
          ru: "Таблица В.1: 5G uphill соответствует PH."
        }
      },
      {
        question: {
          uz: "Aylantirib payvandlanadigan gorizontal quvur (1GR / 1FR) ISO 6947 standartida qanday belgilanadi?",
          ru: "Как обозначается поворотная горизонтальная труба (1FR / 1G) по ИСО 6947?"
        },
        options: [
          { uz: "PA (Pastki holat)", ru: "PA (Нижнее положение)" },
          { uz: "PC (Gorizontal holat)", ru: "PC (Горизонтальное положение)" },
          { uz: "PH (Qoʻzgʻalmas quvur)", ru: "PH (Неповоротная труба)" }
        ],
        correct: 0,
        explanation: {
          uz: "B.1-jadval: Aylanadigan gorizontal quvurda payvandchi har doim yuqori nuqtada payvandlagani uchun u PA hisoblanadi.",
          ru: "Таблица В.1: Поворотная горизонтальная труба соответствует нижнему положению PA."
        }
      }
    ]
  }
];
