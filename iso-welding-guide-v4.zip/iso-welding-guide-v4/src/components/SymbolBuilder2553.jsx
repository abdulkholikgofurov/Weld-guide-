import React, { useState } from 'react';

export default function SymbolBuilder2553({ lang }) {
  const [sys, setSys] = useState('A');
  const [side, setSide] = useState('arrow');
  const [weldType, setWeldType] = useState('fillet');
  const [finish, setFinish] = useState('none');
  const [dimLeft, setDimLeft] = useState('a5');
  const [dimRight, setDimRight] = useState('4×100(200)');
  const [gap, setGap] = useState('2');
  const [angle, setAngle] = useState('60°');
  const [allAround, setAllAround] = useState(false);
  const [fieldWeld, setFieldWeld] = useState(true);
  const [tailText, setTailText] = useState('ISO 4063-135');

  const isBottom = (sys === 'B' && side === 'arrow') || (sys === 'A' && side === 'other');
  const yBase = isBottom ? 78 : 70;

  const t = {
    title: lang === 'uz' ? '🛠 Jonli ISO 2553 Chizma va Kesim Konstruktori' : lang === 'ru' ? '🛠 Живой конструктор ИСО 2553' : '🛠 Live ISO 2553 Symbol & Cross-Section Builder',
    symLbl: lang === 'uz' ? 'Texnik chizmadagi shartli belgi' : lang === 'ru' ? 'Условное обозначение на чертеже' : 'Symbolic representation on drawing',
    secLbl: lang === 'uz' ? 'Metalldagi haqiqiy koʻrinishi (kesim)' : lang === 'ru' ? 'Реальное сечение сварного соединения' : 'Actual weld cross-section in metal',
    arrowSide: lang === 'uz' ? 'Strelka tomoni' : lang === 'ru' ? 'Сторона стрелки' : 'Arrow side',
    otherSide: lang === 'uz' ? 'Teskari tomon' : lang === 'ru' ? 'Обратная сторона' : 'Other side',
    field: lang === 'uz' ? 'Montaj ⚑' : lang === 'ru' ? 'Монтаж ⚑' : 'Field weld ⚑',
    around: lang === 'uz' ? 'Kontur ○' : lang === 'ru' ? 'Контур ○' : 'All-around ○'
  };

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 my-3 shadow-lg">
      <h3 className="text-amber-400 font-bold text-sm mb-3">{t.title}</h3>

      <div className="grid grid-cols-1 gap-2 mb-3">
        <div className="bg-slate-950 rounded-xl p-2 border border-slate-700">
          <div className="text-[10px] text-slate-400 text-center">{t.symLbl}</div>
          <svg viewBox="0 0 380 140" className="w-full h-36">
            <line x1="20" y1="118" x2="80" y2="70" stroke="#38bdf8" strokeWidth="2.5" />
            <polygon points="20,118 35,112 29,104" fill="#38bdf8" />
            <line x1="80" y1="70" x2="262" y2="70" stroke="#38bdf8" strokeWidth="2.5" />
            {sys === 'A' && (
              <line x1="80" y1="78" x2="262" y2="78" stroke="#38bdf8" strokeWidth="2" strokeDasharray="7,4" />
            )}
            {allAround && <circle cx="80" cy="70" r="8" fill="none" stroke="#f59e0b" strokeWidth="2.5" />}
            {fieldWeld && (
              <g>
                <line x1="80" y1="70" x2="80" y2="35" stroke="#f59e0b" strokeWidth="2.5" />
                <polygon points="80,35 103,42 80,49" fill="#f59e0b" />
              </g>
            )}
            <text x="115" y={isBottom ? 98 : 60} fill="#22c55e" fontSize="14" fontWeight="bold" textAnchor="end">
              {dimLeft}
            </text>

            {/* Elementary symbols */}
            {weldType === 'fillet' && (
              <polygon
                points={isBottom ? `122,${yBase} 122,${yBase + 22} 144,${yBase}` : `122,${yBase} 122,${yBase - 22} 144,${yBase}`}
                fill="none" stroke="#f59e0b" strokeWidth="2.5"
              />
            )}
            {weldType === 'vgroove' && (
              <g>
                <path
                  d={isBottom ? `M120,${yBase + 20} L133,${yBase} L146,${yBase + 20}` : `M120,${yBase - 20} L133,${yBase} L146,${yBase - 20}`}
                  fill="none" stroke="#f59e0b" strokeWidth="2.5"
                />
                {angle && <text x="133" y={isBottom ? yBase + 34 : yBase - 24} fill="#a855f7" fontSize="10" textAnchor="middle" fontWeight="bold">{angle}</text>}
                {gap && <text x="133" y={isBottom ? yBase + 15 : yBase - 6} fill="#38bdf8" fontSize="9" textAnchor="middle">{gap}</text>}
              </g>
            )}
            {weldType === 'bevel' && (
              <g>
                <path
                  d={isBottom ? `M124,${yBase + 20} L124,${yBase} L144,${yBase + 20}` : `M124,${yBase - 20} L124,${yBase} L144,${yBase - 20}`}
                  fill="none" stroke="#f59e0b" strokeWidth="2.5"
                />
                {angle && <text x="134" y={isBottom ? yBase + 34 : yBase - 24} fill="#a855f7" fontSize="10" textAnchor="middle" fontWeight="bold">{angle}</text>}
              </g>
            )}
            {weldType === 'y_broad' && (
              <path
                d={isBottom ? `M120,${yBase + 22} L133,${yBase + 10} L146,${yBase + 22} M133,${yBase} L133,${yBase + 10}` : `M120,${yBase - 22} L133,${yBase - 10} L146,${yBase - 22} M133,${yBase} L133,${yBase - 10}`}
                fill="none" stroke="#f59e0b" strokeWidth="2.5"
              />
            )}

            {/* Supplementary finish */}
            {finish === 'flat' && <line x1="120" y1={isBottom ? yBase + 26 : yBase - 26} x2="146" y2={isBottom ? yBase + 26 : yBase - 26} stroke="#22c55e" strokeWidth="2" />}
            {finish === 'convex' && <path d={isBottom ? `M120,${yBase+25} Q133,${yBase+34} 146,${yBase+25}` : `M120,${yBase-25} Q133,${yBase-34} 146,${yBase-25}`} fill="none" stroke="#22c55e" strokeWidth="2" />}
            {finish === 'concave' && <path d={isBottom ? `M120,${yBase+28} Q133,${yBase+19} 146,${yBase+28}` : `M120,${yBase-28} Q133,${yBase-19} 146,${yBase-28}`} fill="none" stroke="#22c55e" strokeWidth="2" />}

            <text x="156" y={isBottom ? 98 : 60} fill="#38bdf8" fontSize="13" fontWeight="bold">
              {dimRight}
            </text>
            {tailText && (
              <g>
                <polyline points="279,54 262,70 279,86" fill="none" stroke="#38bdf8" strokeWidth="2.5" />
                <text x="282" y="74" fill="#e2e8f0" fontSize="11" fontWeight="bold">{tailText}</text>
              </g>
            )}
          </svg>
        </div>

        {/* Dynamic Cross Section */}
        <div className="bg-slate-950 rounded-xl p-2 border border-slate-700">
          <div className="text-[10px] text-slate-400 text-center">{t.secLbl}</div>
          {weldType === 'fillet' && (
            <svg viewBox="0 0 300 75" className="w-full h-16">
              <rect x="40" y="55" width="220" height="14" fill="#475569" />
              <rect x="142" y="8" width="16" height="47" fill="#64748b" />
              {side === 'arrow' ? <polygon points="116,55 142,55 142,29" fill="#f59e0b" /> : <polygon points="158,55 184,55 158,29" fill="#f59e0b" />}
              <text x="55" y="45" fill="#38bdf8" fontSize="10">← Arrow side</text>
            </svg>
          )}
          {weldType === 'vgroove' && (
            <svg viewBox="0 0 300 75" className="w-full h-16">
              <polygon points="40,22 130,22 146,55 40,55" fill="#475569" />
              <polygon points="260,22 170,22 154,55 260,55" fill="#475569" />
              {side === 'arrow' ? <polygon points="130,22 170,22 154,55 146,55" fill="#f59e0b" /> : <polygon points="146,22 154,22 170,55 130,55" fill="#f59e0b" />}
              <text x="50" y="15" fill="#38bdf8" fontSize="10">↓ Arrow side (top)</text>
            </svg>
          )}
          {weldType === 'bevel' && (
            <svg viewBox="0 0 300 75" className="w-full h-16">
              <rect x="40" y="22" width="106" height="33" fill="#475569" />
              <polygon points="260,22 174,22 152,55 260,55" fill="#64748b" />
              <polygon points="146,22 174,22 152,55 146,55" fill="#f59e0b" />
            </svg>
          )}
          {weldType === 'y_broad' && (
            <svg viewBox="0 0 300 75" className="w-full h-16">
              <polygon points="40,22 132,22 146,42 146,55 40,55" fill="#475569" />
              <polygon points="260,22 168,22 154,42 154,55 260,55" fill="#64748b" />
              <polygon points="132,22 168,22 154,42 154,55 146,55 146,42" fill="#f59e0b" />
            </svg>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 text-xs">
        <button onClick={() => setSys(sys === 'A' ? 'B' : 'A')} className="bg-slate-700 hover:bg-slate-600 p-2 rounded-lg text-white font-semibold">
          System: {sys} ({sys === 'A' ? 'Dual line' : 'Single line'})
        </button>
        <button onClick={() => setSide(side === 'arrow' ? 'other' : 'arrow')} className="bg-slate-700 hover:bg-slate-600 p-2 rounded-lg text-white font-semibold">
          {side === 'arrow' ? t.arrowSide : t.otherSide}
        </button>
        <button onClick={() => setWeldType(w => w === 'fillet' ? 'vgroove' : w === 'vgroove' ? 'bevel' : w === 'bevel' ? 'y_broad' : 'fillet')} className="bg-slate-700 hover:bg-slate-600 p-2 rounded-lg text-white font-semibold">
          Type: {weldType === 'fillet' ? 'Fillet (Δ)' : weldType === 'vgroove' ? 'Single-V (V)' : weldType === 'bevel' ? 'Bevel (|/)' : 'Broad root (Y)'}
        </button>
        <button onClick={() => setFinish(f => f === 'none' ? 'flat' : f === 'flat' ? 'convex' : f === 'convex' ? 'concave' : 'none')} className="bg-slate-700 hover:bg-slate-600 p-2 rounded-lg text-white font-semibold">
          Face: {finish}
        </button>
        <button onClick={() => setFieldWeld(!fieldWeld)} className={`p-2 rounded-lg font-semibold ${fieldWeld ? 'bg-amber-600 text-white' : 'bg-slate-700 text-slate-300'}`}>
          {t.field}
        </button>
        <button onClick={() => setAllAround(!allAround)} className={`p-2 rounded-lg font-semibold ${allAround ? 'bg-amber-600 text-white' : 'bg-slate-700 text-slate-300'}`}>
          {t.around}
        </button>
        <input value={dimLeft} onChange={(e) => setDimLeft(e.target.value)} className="bg-slate-900 border border-slate-600 rounded-lg px-2 py-1.5 text-green-400 font-bold" placeholder="a5 / z7 / s10" />
        <input value={dimRight} onChange={(e) => setDimRight(e.target.value)} className="bg-slate-900 border border-slate-600 rounded-lg px-2 py-1.5 text-sky-400" placeholder="4×100(200)" />
      </div>
    </div>
  );
}
