export const iso2553Topics = [
  {
    "id": "2553-terms",
    "pdfPage": 6,
    "title": {
      "uz": "1. Barcha atamalar va ta'riflar (3.1 – 3.23)",
      "ru": "1. Все термины и определения (3.1 – 3.23)",
      "en": "1. Terms and Definitions — Original ISO 2553:2019 (3.1 – 3.23)"
    },
    "theory": {
      "uz": "ISO 2553:2019 (ГОСТ Р ИСО 2553-2022) 3-boʻlimidagi 23 ta asosiy xalqaro atama:\n• 3.1 welding symbol — payvandlash birikmasining shartli belgisi (strelka + tokcha + qoʻshimchalar).\n• 3.2 basic welding symbol — asosiy shartli belgi (strelka + tokcha + dum, chok turi aniqlanmagan).\n• 3.3 arrow line — strelka chizigʻi (odatda tokchaga 135° burchak ostida).\n• 3.4 reference line — tokcha chizigʻi (chizma pastki chetiga parallel).\n• 3.5 tail — «хвост» (dum, V-simon qoʻshimcha ma'lumot qismi).\n• 3.6 arrow side / 3.7 other side — strelka koʻrsatgan tomon / qarama-qarshi (teskari) tomon.\n• 3.8 elementary symbol — boshlangʻich belgi (chok geometrik shakli).\n• 3.9 supplementary symbol — qoʻshimcha belgi (yuza shakli, bayroqcha, aylana).\n• 3.11.1 chain intermittent weld — zanjirsimon uzuq chok (ikki tomonda qarama-qarshi).\n• 3.11.2 staggered intermittent weld — shaxmat tartibidagi uzuq chok (Z).\n• 3.12 offset — siljish (shaxmat chokda bir tomon boshlanishi bilan ikkinchi tomon boshlanishi orasidagi masofa).\n• 3.13 back run — ildiz tomonidan oxirgi qoʻyiladigan payvand valigi (подварочный валик).\n• 3.14 backing weld — taglik sifatida qoʻyilgan payvand choki (подварочный шов).\n• 3.16 nominal throat thickness (a) — burchakli chok ichiga chizilgan eng katta teng yonli uchburchak balandligi.\n• 3.17 leg length (z) — burchakli chok kateti.\n• 3.18 penetration depth — erish chuqurligi (qavariqlikni hisobga olmaganda).\n• 3.19 deep penetration throat thickness (s) — chuqur eritish bilan burchakli chok qalinligi.\n• 3.20 flare-bevel weld / 3.21 flare-V weld — bir tomoni qavariq va tekis detal / ikkala tomoni qavariq detallar orasidagi chok.\n• 3.22 field weld — montaj choki (sex tashqarisida).\n• 3.23 stake weld — ustunsimon chok (lazer yoki elektron nurli).",
      "ru": "Основные 23 термина стандарта ГОСТ Р ИСО 2553-2022 (раздел 3):\n• 3.1 условное обозначение сварного соединения (welding symbol)\n• 3.2 основное условное обозначение (basic welding symbol — стрелка, полка, хвост)\n• 3.3 линия стрелки (arrow line, обычно под углом 135° к полке)\n• 3.4 линия полки (reference line)\n• 3.5 «хвост» (tail)\n• 3.6 сторона, указанная стрелкой (arrow side) / 3.7 обратная сторона (other side)\n• 3.8 начальное обозначение (elementary symbol)\n• 3.9 вспомогательное обозначение (supplementary symbol)\n• 3.11.1 цепной прерывистый шов (chain intermittent weld)\n• 3.11.2 шахматный прерывистый шов (staggered intermittent weld)\n• 3.12 смещение (offset)\n• 3.13 подварочный валик (back run — последний валик со стороны корня)\n• 3.14 подварочный шов (backing weld)\n• 3.16 номинальная толщина углового шва a (nominal throat thickness)\n• 3.17 катет углового шва z (leg length)\n• 3.19 толщина углового шва с глубоким проплавлением s (deep penetration throat thickness)\n• 3.20 шов между закругленной и плоской деталями (flare-bevel weld)\n• 3.21 шов между двумя закругленными деталями (flare-V weld)\n• 3.22 монтажный шов (field weld)\n• 3.23 столбчатый шов (stake weld — лазерный/электронно-лучевой).",
      "en": "Original ISO 2553:2019 Section 3 Terms & Definitions:\n• 3.1 welding symbol: symbol consisting of arrow line and reference line (with elementary/supplementary symbols, dimensions, tail).\n• 3.2 basic welding symbol: arrow line + reference line + tail used when joint details are not specified (e.g., tack welds).\n• 3.3 arrow line: leader line pointing to the joint, generally drawn at 135° to the reference line.\n• 3.4 reference line: horizontal line carrying elementary symbols.\n• 3.5 tail: V-shaped element added at the end of the reference line opposite the arrow line.\n• 3.6 arrow side / 3.7 other side: side to which arrow points vs opposite side.\n• 3.8 elementary symbol / 3.9 supplementary symbol.\n• 3.11.1 chain intermittent weld: double-sided intermittent weld with weld elements opposite each other.\n• 3.11.2 staggered intermittent weld: weld elements on one side opposite unwelded spaces on the other side.\n• 3.12 offset: distance between start of welding on arrow side and other side of a staggered intermittent weld.\n• 3.13 back run: final run deposited on the root side of a fusion weld.\n• 3.14 backing weld: backing in the form of a weld.\n• 3.16 nominal throat thickness (a): height of largest isosceles triangle inscribed in fillet weld section.\n• 3.17 leg length (z): distance from actual/projected intersection of fusion faces to toe of fillet weld.\n• 3.19 deep penetration throat thickness (s): nominal/effective throat thickness plus a certain amount of fusion penetration.\n• 3.20 flare-bevel weld / 3.21 flare-V weld: groove weld between round and flat / two round members.\n• 3.22 field weld: weld made outside a workshop, usually at site of installation.\n• 3.23 stake weld: tee joint weld made by laser/electron beam passing through horizontal flange into vertical web."
    },
    "items": [
      {
        "name": {
          "uz": "Nominal qalinlik 'a', Katet 'z' va Chuqur eritish 's'",
          "ru": "Толщина 'a', катет 'z' и глубокое проплавление 's'",
          "en": "Throat thickness 'a', Leg length 'z' & Deep penetration 's'"
        },
        "desc": {
          "uz": "3.16, 3.17 va 3.19-atamalar kesim sxemasi",
          "ru": "Схема сечения по п. 3.16, 3.17 и 3.19",
          "en": "Cross-section geometry per 3.16, 3.17, 3.19"
        },
        "symbolSvg": "<svg viewBox=\"0 0 240 80\"><line x1=\"15\" y1=\"52\" x2=\"225\" y2=\"52\" stroke=\"#38bdf8\" stroke-width=\"2\"/><text x=\"52\" y=\"42\" fill=\"#22c55e\" font-size=\"14\" font-weight=\"bold\">sa6</text><polygon points=\"58,52 58,26 84,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><text x=\"148\" y=\"42\" fill=\"#38bdf8\" font-size=\"14\" font-weight=\"bold\">z8</text><polygon points=\"154,52 154,26 180,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 240 80\"><rect x=\"30\" y=\"62\" width=\"180\" height=\"12\" fill=\"#475569\"/><rect x=\"85\" y=\"10\" width=\"14\" height=\"52\" fill=\"#64748b\"/><polygon points=\"99,62 99,24 137,62\" fill=\"#f59e0b\" opacity=\"0.8\"/><path d=\"M99,62 L89,68 L99,45 Z\" fill=\"#ef4444\"/><line x1=\"99\" y1=\"62\" x2=\"118\" y2=\"43\" stroke=\"#22c55e\" stroke-width=\"2.5\"/><text x=\"122\" y=\"38\" fill=\"#22c55e\" font-size=\"11\" font-weight=\"bold\">a</text><text x=\"72\" y=\"56\" fill=\"#ef4444\" font-size=\"11\" font-weight=\"bold\">s</text><text x=\"112\" y=\"73\" fill=\"#38bdf8\" font-size=\"11\" font-weight=\"bold\">z</text></svg>"
      },
      {
        "name": {
          "uz": "Zanjirsimon (3.11.1) va Shaxmat (3.11.2) uzuq choklar",
          "ru": "Цепной (3.11.1) и шахматный (3.11.2) прерывистые швы",
          "en": "Chain (3.11.1) vs Staggered (3.11.2) intermittent welds"
        },
        "desc": {
          "uz": "Zanjirsimon — bir-biriga qarama-qarshi | Shaxmat — siljish (offset) bilan",
          "ru": "Цепной — друг напротив друга | Шахматный — со смещением (offset)",
          "en": "Chain — opposite each other | Staggered — with offset"
        },
        "symbolSvg": "<svg viewBox=\"0 0 240 80\"><line x1=\"15\" y1=\"40\" x2=\"105\" y2=\"40\" stroke=\"#38bdf8\" stroke-width=\"2\"/><polygon points=\"45,40 45,22 63,40\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2\"/><polygon points=\"45,40 45,58 63,40\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2\"/><text x=\"32\" y=\"74\" fill=\"#22c55e\" font-size=\"10\">Chain (Zanjir)</text><line x1=\"130\" y1=\"40\" x2=\"225\" y2=\"40\" stroke=\"#38bdf8\" stroke-width=\"2\"/><polygon points=\"152,40 152,22 170,40\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2\"/><polygon points=\"185,40 185,58 203,40\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2\"/><text x=\"172\" y=\"45\" fill=\"#f59e0b\" font-size=\"13\" font-weight=\"bold\">Z</text><text x=\"142\" y=\"74\" fill=\"#f59e0b\" font-size=\"10\">Staggered (Shaxmat)</text></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 240 80\"><rect x=\"15\" y=\"36\" width=\"95\" height=\"8\" fill=\"#64748b\"/><rect x=\"22\" y=\"28\" width=\"22\" height=\"8\" fill=\"#22c55e\"/><rect x=\"65\" y=\"28\" width=\"22\" height=\"8\" fill=\"#22c55e\"/><rect x=\"22\" y=\"44\" width=\"22\" height=\"8\" fill=\"#22c55e\"/><rect x=\"65\" y=\"44\" width=\"22\" height=\"8\" fill=\"#22c55e\"/><rect x=\"130\" y=\"36\" width=\"95\" height=\"8\" fill=\"#64748b\"/><rect x=\"135\" y=\"28\" width=\"22\" height=\"8\" fill=\"#f59e0b\"/><rect x=\"180\" y=\"28\" width=\"22\" height=\"8\" fill=\"#f59e0b\"/><rect x=\"157\" y=\"44\" width=\"22\" height=\"8\" fill=\"#f59e0b\"/><text x=\"145\" y=\"68\" fill=\"#38bdf8\" font-size=\"10\">offset (siljish)</text></svg>"
      }
    ],
    "quiz": [
      {
        "question": {
          "uz": "3.13-atama 'back run' (подварочный валик) nimani anglatadi?",
          "ru": "Что означает термин 'подварочный валик' (back run, п. 3.13)?",
          "en": "What is the definition of 'back run' (Clause 3.13) in ISO 2553?"
        },
        "options": [
          {
            "uz": "Payvand chokining ildiz (orqa) tomonidan qoʻyiladigan oxirgi payvand valigi",
            "ru": "Последний валик, наплавляемый со стороны корня сварного шва",
            "en": "Final run deposited on the root side of a fusion weld"
          },
          {
            "uz": "Payvandlashdan oldin qoʻyiladigan mis taglik",
            "ru": "Медная подкладка перед сваркой",
            "en": "Copper backing strip placed before welding"
          },
          {
            "uz": "Vaqtinchalik ilashma (prixvatka)",
            "ru": "Временная прихватка",
            "en": "Temporary tack weld"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3.13-band: 'back run' — eritib payvandlash chokining ildiz (kornyevoy) tomonidan oxirgi boʻlib eritib qoʻyiladigan valik.",
          "ru": "Пункт 3.13: Подварочный валик (back run) — последний валик, наплавляемый со стороны корня сварного шва.",
          "en": "Clause 3.13: A back run is the final run deposited on the root side of a fusion weld."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.12-atama 'offset' (смещение) qaysi chok turiga tegishli?",
          "ru": "К какому типу швов относится термин 'смещение' (offset, п. 3.12)?",
          "en": "To which type of weld does the term 'offset' (Clause 3.12) apply?"
        },
        "options": [
          {
            "uz": "Shaxmat tartibidagi uzuq chok (staggered intermittent weld) — bir tomon boshlanishi va ikkinchi tomon boshlanishi orasidagi masofa",
            "ru": "Шахматный прерывистый шов — расстояние между началом сварки на лицевой и обратной сторонах",
            "en": "Staggered intermittent weld — distance between start of welding on arrow side and other side"
          },
          {
            "uz": "Uchma-uch chokda qirralarning balandlik boʻyicha siljishi",
            "ru": "Смещение кромок стыкового шва по высоте",
            "en": "Linear misalignment of butt weld edges"
          },
          {
            "uz": "Montaj chokining chizmadan ogʻishi",
            "ru": "Отклонение монтажного шва",
            "en": "Deviation of field weld location"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3.12-band: 'offset' — shaxmat uzuq chokning old va orqa tomonidagi payvandlash boshlanish nuqtalari orasidagi masofa.",
          "ru": "Пункт 3.12: Смещение (offset) — расстояние между началом сварки на лицевой стороне шахматного шва и началом на обратной стороне.",
          "en": "Clause 3.12: Offset is the distance between the start of welding on the arrow side and the start on the other side of a staggered intermittent weld."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.16-atama 'nominal throat thickness (a)' qanday aniqlanadi?",
          "ru": "Как определяется 'номинальная толщина углового шва a' (nominal throat thickness, п. 3.16)?",
          "en": "How is 'nominal throat thickness (a)' (Clause 3.16) defined?"
        },
        "options": [
          {
            "uz": "Burchakli chok koʻndalang kesimi ichiga chizish mumkin boʻlgan eng katta teng yonli uchburchakning balandligi",
            "ru": "Расчетное значение высоты наибольшего равнобедренного треугольника, вписанного в сечение углового шва",
            "en": "Design value of the height of the largest isosceles triangle that can be inscribed in the fillet weld cross-section"
          },
          {
            "uz": "Chokning tashqi yuzasi kengligi",
            "ru": "Ширина наружной поверхности шва",
            "en": "Width of the outer weld face"
          },
          {
            "uz": "Burchakli chokning eng uzun kateti",
            "ru": "Наибольший катет углового шва",
            "en": "Longest leg of a fillet weld"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3.16-band: 'a' — burchakli chok kesimiga ichki chizilgan eng katta teng yonli uchburchakning balandligi.",
          "ru": "Пункт 3.16: Номинальная толщина 'a' — высота наибольшего равнобедренного треугольника, вписанного в сечение.",
          "en": "Clause 3.16: Nominal throat thickness 'a' is the design height of the largest isosceles triangle inscribed in the fillet weld section."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.17-atama 'leg length (z)' nimani anglatadi?",
          "ru": "Что означает 'катет углового шва z' (leg length, п. 3.17)?",
          "en": "What does 'leg length (z)' (Clause 3.17) represent?"
        },
        "options": [
          {
            "uz": "Eritilayotgan yuzalarning kesishish nuqtasidan chok chegarasigacha boʻlgan masofa",
            "ru": "Расстояние от пересечения расплавляемых поверхностей до границы углового шва",
            "en": "Distance from the actual or projected intersection of fusion faces to the toe of the fillet weld"
          },
          {
            "uz": "Chokning umumiy uzunligi",
            "ru": "Общая длина сварного шва",
            "en": "Total length of the weld"
          },
          {
            "uz": "Qirralar orasidagi zazor",
            "ru": "Зазор между кромками",
            "en": "Root gap between plates"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3.17-band: 'z' (leg length) — detallar kesishgan burchakdan chok chekkasigacha (toe) boʻlgan masofa.",
          "ru": "Пункт 3.17: Катет z — расстояние от фактического/предполагаемого пересечения поверхностей до границы шва.",
          "en": "Clause 3.17: Leg length 'z' is the distance from the intersection of fusion faces to the toe of the fillet weld."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.20 'flare-bevel weld' va 3.21 'flare-V weld' oʻrtasidagi farq nima?",
          "ru": "В чем разница между 'flare-bevel weld' (п. 3.20) и 'flare-V weld' (п. 3.21)?",
          "en": "What is the difference between a 'flare-bevel weld' (3.20) and a 'flare-V weld' (3.21)?"
        },
        "options": [
          {
            "uz": "flare-bevel — bitta yumaloq (qavariq) va bitta tekis detal orasida; flare-V — ikkita yumaloq detal orasida",
            "ru": "flare-bevel — между закругленной и плоской деталями; flare-V — между двумя закругленными деталями",
            "en": "flare-bevel is between a round and a flat member; flare-V is between two round members"
          },
          {
            "uz": "Ikkalasi ham faqat lazerli payvandlashga tegishli",
            "ru": "Оба относятся только к лазерной сварке",
            "en": "Both apply only to laser welding"
          },
          {
            "uz": "flare-bevel — burchakli chok, flare-V — nuqtali chok",
            "ru": "flare-bevel — угловой, flare-V — точечный",
            "en": "flare-bevel is fillet, flare-V is spot"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3.20 va 3.21-bandlar: Masalan, dumaloq trubani tekis plastinaga payvandlash — flare-bevel; ikkita dumaloq trubani yonma-yon payvandlash — flare-V.",
          "ru": "Пункты 3.20 и 3.21: Закругленная + плоская = flare-bevel; две закругленные детали = flare-V.",
          "en": "Clauses 3.20 & 3.21: Flare-bevel joins a round surface to a flat surface; flare-V joins two round surfaces."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.23-atama 'stake weld' (столбчатый шов) qanday usulda olinadi?",
          "ru": "Каким способом выполняется 'столбчатый шов' (stake weld, п. 3.23)?",
          "en": "How is a 'stake weld' (Clause 3.23) produced?"
        },
        "options": [
          {
            "uz": "Gorizontal list orqali vertikal devorga lazer yoki elektron nur ta'sir ettirib",
            "ru": "Воздействием лазерного или электронного луча от горизонтального листа к вертикальному",
            "en": "By laser or electron beam passing through a horizontal flange into a vertical web"
          },
          {
            "uz": "Qoʻlda qoplamali elektrod (111 / SMAW) bilan",
            "ru": "Ручной дуговой сваркой покрытым электродом",
            "en": "By manual metal arc welding (SMAW)"
          },
          {
            "uz": "Kontakt nuqtali payvandlash mashinasida",
            "ru": "Контактной точечной сваркой",
            "en": "By resistance spot welding"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3.23-band: 'stake weld' — tavr birikmada ustki gorizontal listni teshib oʻtib, pastki vertikal devorga ulaydigan lazer yoki elektron-nurli chok.",
          "ru": "Пункт 3.23: Столбчатый шов (stake weld) получают воздействием лазерного или электронного луча.",
          "en": "Clause 3.23: A stake weld is a tee-joint weld made by a laser or electron beam passing from the horizontal flange into the vertical web."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.3-bandga koʻra strelka chizigʻi (arrow line) tokcha chizigʻiga odatda necha gradus burchak ostida chiziladi?",
          "ru": "Под каким углом к линии полки обычно вычерчивается линия стрелки (arrow line, п. 3.3)?",
          "en": "At what angle to the reference line is the arrow line generally drawn (Clause 3.3)?"
        },
        "options": [
          {
            "uz": "135°",
            "ru": "135°",
            "en": "135°"
          },
          {
            "uz": "90°",
            "ru": "90°",
            "en": "90°"
          },
          {
            "uz": "45°",
            "ru": "45°",
            "en": "45°"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3.3-band: Strelka chizigʻi (arrow line) odatda tokcha chizigʻiga nisbatan 135° burchak ostida chiziladi.",
          "ru": "Пункт 3.3: Линия стрелки обычно вычерчивается под углом 135° к линии полки.",
          "en": "Clause 3.3: The arrow line is generally drawn at an angle of 135° to the reference line."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.18-band 'penetration depth' (глубина проплавления) oʻlchanganda nimani hisobga OLMAYMIZ?",
          "ru": "Что исключается при измерении 'толщины проплавления' (penetration depth, п. 3.18)?",
          "en": "What is excluded when measuring 'penetration depth / deposit thickness' (Clause 3.18)?"
        },
        "options": [
          {
            "uz": "Chokning har qanday qavariqligi (выпуклость / reinforcement)",
            "ru": "Любая выпуклость металла шва",
            "en": "Any reinforcement / convexity of the weld metal"
          },
          {
            "uz": "Asosiy metall qalinligi",
            "ru": "Толщина основного металла",
            "en": "Base metal thickness"
          },
          {
            "uz": "Ildiz qismi",
            "ru": "Корневая часть шва",
            "en": "Root pass"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3.18-band: 'penetration depth' — chokning tashqi qavariqligini (выпуклость) istisno qilgan holdagi eritilgan metall qalinligi.",
          "ru": "Пункт 3.18: Толщина металла шва, исключая любую выпуклость.",
          "en": "Clause 3.18: Penetration depth is the thickness of the weld metal excluding any reinforcement."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.19-band 'deep penetration throat thickness (s)' qanday qiymatni bildiradi?",
          "ru": "Что представляет собой 'толщина углового шва с глубоким проплавлением s' (п. 3.19)?",
          "en": "What is 'deep penetration throat thickness (s)' (Clause 3.19)?"
        },
        "options": [
          {
            "uz": "Nominal yoki samarali chok qalinligi 'a' ga ma'lum bir erish chuqurligi qoʻshilgan qiymat",
            "ru": "Номинальная/эффективная толщина углового шва с добавлением величины глубины проплавления",
            "en": "Nominal or effective throat thickness plus a certain amount of fusion penetration"
          },
          {
            "uz": "Faqat qirra kesish chuqurligi",
            "ru": "Только глубина разделки кромок",
            "en": "Only the bevel preparation depth"
          },
          {
            "uz": "Chokning tashqi qavariqlik balandligi",
            "ru": "Высота наружной выпуклости",
            "en": "Height of external convexity"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3.19-band: Chuqur eritishli burchakli chokda 's' harfi 'a' dan oldin qoʻyiladi (masalan, s8 a6).",
          "ru": "Пункт 3.19: Толщина с глубоким проплавлением 's' ставится перед номинальной толщиной 'a' (например, s8 a6).",
          "en": "Clause 3.19: Deep penetration throat thickness 's' is placed in front of nominal throat thickness 'a' (e.g., s8 a6)."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.11.1-band 'chain intermittent weld' (цепной прерывистый шов) qanday joylashadi?",
          "ru": "Как располагаются участки 'цепного прерывистого шва' (chain intermittent weld, п. 3.11.1)?",
          "en": "How are weld elements arranged in a 'chain intermittent weld' (Clause 3.11.1)?"
        },
        "options": [
          {
            "uz": "Ikki tomonlama chokda payvandlangan uchastkalar birikmaning ikki tomonida bir-biriga qarama-qarshi joylashadi",
            "ru": "Заваренные участки с обеих сторон расположены друг против друга вдоль соединения",
            "en": "Double-sided intermittent weld where weld elements on both sides are opposite each other"
          },
          {
            "uz": "Bir tomondagi chok ikkinchi tomondagi boʻshliq qarshisida joylashadi",
            "ru": "Заваренные участки находятся напротив незаваренных с обратной стороны",
            "en": "Weld elements on one side are opposite unwelded spaces on the other side"
          },
          {
            "uz": "Faqat bir tomonda bajariladi",
            "ru": "Выполняется только с одной стороны",
            "en": "Made on one side only"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3.11.1-band: Zanjirsimon uzuq chokda (chain) ikkala tomondagi choklar simmetrik tarzda bir-birining qarshisida turadi.",
          "ru": "Пункт 3.11.1: В цепном прерывистом шве заваренные участки с обеих сторон расположены друг против друга.",
          "en": "Clause 3.11.1: In a chain intermittent weld, weld elements on both sides are located opposite each other."
        },
        "svg": null
      }
    ]
  },
  {
    "id": "2553-sys",
    "pdfPage": 19,
    "title": {
      "uz": "2. A va B tizimlari, Strelka, Tokcha va «Хвост» (4.1–4.3, 4.6–4.8)",
      "ru": "2. Системы А и В, Стрелка, Полка и «Хвост» (4.1–4.3, 4.6–4.8)",
      "en": "2. Systems A & B, Arrow Line, Reference Line & Tail (4.1–4.3, 4.6–4.8)"
    },
    "theory": {
      "uz": "• A tizimi (System A — ikkitali tokcha): Tutash (sposhnoy) va shtrix (uzuk-uzuk) parallel chiziqlar. Boshlangʻich belgi tutash chiziqda boʻlsa — strelka tomoni (arrow side); shtrix chiziqda boʻlsa — teskari tomon (other side). Simmetrik ikki tomonlama choklarda shtrix chiziq oʻchiriladi.\n• B tizimi (System B — bittalik tokcha): Bitta tutash chiziq. Belgi chiziq OSTIDA boʻlsa — strelka tomoni; chiziq USTIDA boʻlsa — teskari tomon.\n• 4.7.2.2 Relefli payvandlash (projection welding, №12.2): A tizimida strelka boʻrtiq (relyef) bor listga qaratiladi, belgi tokcha oʻrtasiga qoʻyiladi; B tizimida belgi tokcha ostiga yoki ustiga qoʻyilib qaysi listda relyef borligi koʻrsatiladi.\n• 4.7.3 Bir nechta tokcha chiziqlari: Strelkaga eng yaqin tokcha — 1-operatsiya, keyingilari — 2- va 3-operatsiyalar.\n• 4.8 «Хвост» (Tail): Ochiq dumda ma'lumotlar '/' bilan ajratiladi (ISO 5817-C / ISO 4063-121 / ISO 6947-PA). Yopiq dum — faqat aniq hujjatga (WPS/WPQR) havola.",
      "ru": "• Система А (двойная линия полки): сплошная линия — сторона стрелки (arrow side); штриховая линия — обратная сторона (other side). Для симметричных двусторонних швов штриховая линия удаляется.\n• Система В (одинарная линия полки): символ ПОД линией полки — сторона стрелки; НАД линией полки — обратная сторона.\n• Рельефная сварка (п. 4.7.2.2): в системе А стрелка указывает на лист с рельефом, символ по центру полки; в системе В символ выше/ниже полки указывает на лист с рельефом.\n• Несколько линий полки (п. 4.7.3): ближайшая к стрелке — 1-я операция.\n• «Хвост» (п. 4.8): открытый — данные через «/»; закрытый — ссылка на WPS/WPQR.",
      "en": "• System A (dual reference line): solid line = arrow side; dashed line = other side. Dashed line is omitted for symmetrical double-sided welds.\n• System B (single reference line): symbol BELOW reference line = arrow side; ABOVE reference line = other side.\n• Projection welds (4.7.2.2): in System A, arrow points to sheet with projection and symbol is centered on reference line; in System B, symbol above/below indicates which sheet has the projection.\n• Multiple reference lines (4.7.3): line closest to arrow = 1st operation, subsequent lines = 2nd, 3rd operations.\n• Tail (4.8): open tail separates info by '/' (quality level / process / consumable / position); closed tail is used ONLY for reference to a specific instruction (WPS/WPQR)."
    },
    "items": [
      {
        "name": {
          "uz": "A tizimi (tutash/shtrix) va B tizimi (ostida/ustida)",
          "ru": "Система А и Система В (Таблица 5)",
          "en": "System A vs System B (Table 5)"
        },
        "desc": {
          "uz": "Bir xil chokning ikki tizimda yozilishi",
          "ru": "Запись одного и того же шва в двух системах",
          "en": "Same weld represented in System A and System B"
        },
        "symbolSvg": "<svg viewBox=\"0 0 240 90\"><line x1=\"15\" y1=\"70\" x2=\"50\" y2=\"32\" stroke=\"#38bdf8\" stroke-width=\"2\"/><line x1=\"50\" y1=\"32\" x2=\"115\" y2=\"32\" stroke=\"#38bdf8\" stroke-width=\"2\"/><line x1=\"50\" y1=\"40\" x2=\"115\" y2=\"40\" stroke=\"#38bdf8\" stroke-width=\"1.8\" stroke-dasharray=\"5,3\"/><polygon points=\"75,32 75,16 91,32\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2\"/><text x=\"55\" y=\"84\" fill=\"#22c55e\" font-size=\"10\">System A (Arrow)</text><line x1=\"130\" y1=\"70\" x2=\"165\" y2=\"36\" stroke=\"#38bdf8\" stroke-width=\"2\"/><line x1=\"165\" y1=\"36\" x2=\"230\" y2=\"36\" stroke=\"#38bdf8\" stroke-width=\"2\"/><polygon points=\"188,36 188,52 204,36\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2\"/><text x=\"165\" y=\"84\" fill=\"#22c55e\" font-size=\"10\">System B (Arrow)</text></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 240 90\"><line x1=\"20\" y1=\"75\" x2=\"55\" y2=\"45\" stroke=\"#38bdf8\" stroke-width=\"2\"/><line x1=\"55\" y1=\"45\" x2=\"155\" y2=\"45\" stroke=\"#38bdf8\" stroke-width=\"2\"/><line x1=\"38\" y1=\"60\" x2=\"138\" y2=\"60\" stroke=\"#38bdf8\" stroke-width=\"2\"/><line x1=\"22\" y1=\"73\" x2=\"122\" y2=\"73\" stroke=\"#38bdf8\" stroke-width=\"2\"/><text x=\"162\" y=\"76\" fill=\"#22c55e\" font-size=\"10\">1-op</text><text x=\"162\" y=\"62\" fill=\"#f59e0b\" font-size=\"10\">2-op</text><text x=\"162\" y=\"48\" fill=\"#38bdf8\" font-size=\"10\">3-op</text></svg>"
      }
    ],
    "quiz": [
      {
        "question": {
          "uz": "A tizimida boshlangʻich belgi SHTRIX (uzuk-uzuk) chiziqda joylashgan boʻlsa, chok qayerda bajariladi?",
          "ru": "Где выполняется шов в системе А, если начальное обозначение расположено на штриховой линии?",
          "en": "In System A, where is the weld made if the elementary symbol is placed on the dashed reference line?"
        },
        "options": [
          {
            "uz": "Teskari tomonda (other side)",
            "ru": "На обратной стороне (other side)",
            "en": "On the other side of the joint"
          },
          {
            "uz": "Strelka koʻrsatgan tomonda (arrow side)",
            "ru": "На стороне стрелки (arrow side)",
            "en": "On the arrow side of the joint"
          },
          {
            "uz": "Ikkala tomonda",
            "ru": "С обеих сторон",
            "en": "On both sides"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "4.7.2.1A: A tizimida tutash chiziq — arrow side, shtrix chiziq — other side.",
          "ru": "Пункт 4.7.2.1А: На сплошной — сторона стрелки, на штриховой — обратная сторона.",
          "en": "Clause 4.7.2.1A: Elementary symbols on the dashed line indicate the other side."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"60\" x2=\"55\" y2=\"25\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"55\" y1=\"25\" x2=\"170\" y2=\"25\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"55\" y1=\"33\" x2=\"170\" y2=\"33\" stroke=\"#38bdf8\" stroke-width=\"2\" stroke-dasharray=\"6,3\"/><polygon points=\"95,33 95,50 112,33\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/></svg>"
      },
      {
        "question": {
          "uz": "B tizimida boshlangʻich belgi tokcha chizigʻining OSTIDA tursa, chok qaysi tomonda bajariladi?",
          "ru": "Где выполняется шов в системе В, если символ расположен ПОД линией полки?",
          "en": "In System B, where is the weld made if the elementary symbol is placed BELOW the reference line?"
        },
        "options": [
          {
            "uz": "Strelka koʻrsatgan tomonda (arrow side)",
            "ru": "На стороне, указанной стрелкой (arrow side)",
            "en": "On the arrow side"
          },
          {
            "uz": "Teskari tomonda (other side)",
            "ru": "На обратной стороне (other side)",
            "en": "On the other side"
          },
          {
            "uz": "Faqat quvur ichida",
            "ru": "Только внутри трубы",
            "en": "Inside the pipe only"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "4.7.2.1B: B tizimida tokcha ostidagi belgi — arrow side, ustidagi belgi — other side.",
          "ru": "Пункт 4.7.2.1В: Под линией полки — сторона стрелки, выше — обратная сторона.",
          "en": "Clause 4.7.2.1B: Elementary symbols below the reference line indicate the arrow side."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Uchma-uch tutashgan (plug/slot/spot/seam) choklarda boshlangʻich belgi tokcha chizigʻining qayeriga qoʻyiladi (4.7.2.2)?",
          "ru": "Где располагается начальное обозначение для швов, выполненных на стыке двух элементов (п. 4.7.2.2)?",
          "en": "Where is the elementary symbol placed for welds made at the interface between two members (4.7.2.2)?"
        },
        "options": [
          {
            "uz": "Tokcha chizigʻining markaziga (oʻrtasiga) — strelka/teskari tomonidan qat'i nazar",
            "ru": "По центру линии полки независимо от стороны стрелки/обратной стороны",
            "en": "Centered on the reference line regardless of arrow side / other side"
          },
          {
            "uz": "Faqat tokcha ostiga",
            "ru": "Только под линией полки",
            "en": "Only below the reference line"
          },
          {
            "uz": "Dum qismiga",
            "ru": "Внутри хвоста",
            "en": "Inside the tail"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "4.7.2.2-band: Ikki detal tutashgan yuzada bajariladigan kontakt nuqtali va rolikli choklarda belgi tokcha oʻrtasiga qoʻyiladi va A tizimida shtrix chiziq tushirib qoldiriladi.",
          "ru": "Пункт 4.7.2.2: Начальное обозначение располагают по центру линии полки, штриховую линию можно опустить.",
          "en": "Clause 4.7.2.2: The elementary symbol is centered on the reference line and the dashed line in System A may be omitted."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Relefli payvandlashda (projection welding) A va B tizimlari qanday farqlanadi (4.7.2.2A vs 4.7.2.2B)?",
          "ru": "В чем разница обозначения рельефной сварки в системах А и В (п. 4.7.2.2А и 4.7.2.2В)?",
          "en": "How do Systems A and B differ for projection welds (4.7.2.2A vs 4.7.2.2B)?"
        },
        "options": [
          {
            "uz": "A tizimida strelka relyefli listga qaraydi (belgi markazda); B tizimida belgi tokcha osti/ustiga qoʻyilib qaysi listda relyef borligi koʻrsatiladi",
            "ru": "В А стрелка указывает на лист с рельефом (символ по центру); в В символ выше/ниже полки указывает лист с рельефом",
            "en": "In A, arrow points to sheet with projection (symbol centered); in B, symbol above/below shows which sheet has the projection"
          },
          {
            "uz": "Ikkala tizimda ham bir xil yoziladi",
            "ru": "В обеих системах одинаково",
            "en": "Identical in both systems"
          },
          {
            "uz": "B tizimida relyefli payvandlash ishlatilmaydi",
            "ru": "В системе В не применяется",
            "en": "Not used in System B"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "4.7.2.2A va B: A tizimida strelka relyefli listni koʻrsatadi, B tizimida esa belgining tokchadan yuqori yoki pastda turishi qaysi listda relyef borligini bildiradi.",
          "ru": "Пункты 4.7.2.2А и 4.7.2.2В: В системе А стрелка указывает на лист с рельефом; в системе В положение символа выше/ниже полки определяет лист с рельефом.",
          "en": "Clauses 4.7.2.2A & B: System A uses the arrow to point to the embossed sheet; System B places the symbol above or below the reference line."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "4.7.1-band izohiga koʻra, chizmada joy yetishmasa tokcha chizigʻini qanday chizishga ruxsat etiladi?",
          "ru": "Как допускается чертить линию полки, если место на чертеже не позволяет провести ее параллельно нижнему краю (п. 4.7.1)?",
          "en": "How may the reference line be drawn if space does not allow drawing it parallel to the bottom edge (4.7.1 Note)?"
        },
        "options": [
          {
            "uz": "Chizmaning oʻng chetiga parallel qilib (belgini 90° burib)",
            "ru": "Параллельно правому краю чертежа (повернув на 90°)",
            "en": "Parallel to the right-hand edge of the drawing (rotated 90°)"
          },
          {
            "uz": "45° qiya qilib",
            "ru": "Под углом 45°",
            "en": "At a 45° angle"
          },
          {
            "uz": "Teskari (oyna aksida) qilib",
            "ru": "Зеркально",
            "en": "Mirrored"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "4.7.1-band izohi: Joy boʻlmagan taqdirda tokcha chizigʻini 90° burib, oʻng chetiga parallel chizish mumkin.",
          "ru": "Примечание к п. 4.7.1: Допускается чертить параллельно правому краю чертежа (поворот на 90°).",
          "en": "Note to 4.7.1: The reference line may be drawn parallel to the right-hand edge of the drawing (rotated 90°)."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Ajratgichli (spacer) birikmalarda ajratgich belgisi qaysi tokcha chizigʻida koʻrsatiladi (4.7.3)?",
          "ru": "На какой линии полки располагают обозначение разделителя (spacer, п. 4.7.3)?",
          "en": "On which reference line is the spacer symbol placed when multiple reference lines are used (4.7.3)?"
        },
        "options": [
          {
            "uz": "Strelkaga eng yaqin joylashgan tokcha chizigʻida",
            "ru": "На линии полки, ближайшей к стрелке",
            "en": "On the reference line closest to the arrow"
          },
          {
            "uz": "Eng oxirgi tokcha chizigʻida",
            "ru": "На самой последней линии полки",
            "en": "On the furthest reference line"
          },
          {
            "uz": "Dum qismida",
            "ru": "В хвосте",
            "en": "In the tail"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "4.7.3-band: Ajratgichli birikmalarda ajratgich belgisi strelkaga eng yaqin tokcha chizigʻiga joylashtiriladi.",
          "ru": "Пункт 4.7.3: Для соединений с разделителями обозначение разделителя располагают на линии полки, ближайшей к стрелке.",
          "en": "Clause 4.7.3: For joints with spacers, the spacer symbol is placed on the reference line closest to the arrow."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Yopiq «хвост» (closed tail — uchburchak) qanday maqsadda qoʻllaniladi (4.8)?",
          "ru": "Для чего следует применять закрытый «хвост» (closed tail, п. 4.8)?",
          "en": "When should a closed tail be used (Clause 4.8)?"
        },
        "options": [
          {
            "uz": "Faqat aniq texnologik hujjatga (WPS, WPQR yoki maxsus yoʻriqnomaga) havola koʻrsatish uchun",
            "ru": "Только для указания ссылки на конкретную инструкцию (WPS, WPQR или другой документ)",
            "en": "Only to indicate reference to a specific instruction (e.g., WPS, WPQR)"
          },
          {
            "uz": "Payvandlash jarayoni kodini (135/141) yozish uchun",
            "ru": "Для записи кода процесса сварки",
            "en": "To write the welding process number"
          },
          {
            "uz": "Sifat darajasini (ISO 5817-B) yozish uchun",
            "ru": "Для записи уровня качества",
            "en": "To write the quality level"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "4.8-band: Ochiq dumda sifat/jarayon/holat yoziladi, yopiq dum esa faqat aniq hujjat (masalan, A1 / WPS) havolasi uchun ishlatiladi.",
          "ru": "Пункт 4.8: Закрытый «хвост» применяют только для ссылки на конкретную инструкцию (WPS, WPQR).",
          "en": "Clause 4.8: A closed tail shall only be used to indicate reference to a specific instruction (such as a WPS or WPQR)."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "T-simon (tavr) birikmalarda bitta detalning qirrasini kesish kerak boʻlsa, siniq strelka chizish shartmi (4.6.3)?",
          "ru": "Требуется ли ломаная линия стрелки для Т-образных соединений (п. 4.6.3)?",
          "en": "Is a broken arrow line required for T-joints when one member is bevelled (4.6.3)?"
        },
        "options": [
          {
            "uz": "Yoʻq, 4.6.3-bandda T-simon birikmalar istisno qilingan (chunki qaysi detal kesilishi shundoq ham aniq)",
            "ru": "Нет, Т-образные соединения являются исключением в п. 4.6.3",
            "en": "No, T-joints are explicitly excluded in 4.6.3"
          },
          {
            "uz": "Ha, har doim shart",
            "ru": "Да, всегда обязательно",
            "en": "Yes, always required"
          },
          {
            "uz": "Faqat B tizimida shart",
            "ru": "Только в системе В",
            "en": "Only in System B"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "4.6.3-band: 'При сварке листов (за исключением Т-образных соединений)...' — T-simon birikmalarda faqat vertikal devor kesilishi aniq boʻlgani uchun siniq strelka shart emas.",
          "ru": "Пункт 4.6.3: Для стыковых швов листов (за исключением Т-образных соединений) применяют ломаную стрелку.",
          "en": "Clause 4.6.3: For butt welds in plates (excluding T-joints), a broken arrow line is used."
        },
        "svg": null
      }
    ]
  },
  {
    "id": "2553-elem",
    "pdfPage": 9,
    "title": {
      "uz": "3. Barcha 22 xil boshlangʻich chok belgilari (1 va 2-jadvallar)",
      "ru": "3. Все 22 начальных обозначения швов (Таблицы 1 и 2)",
      "en": "3. All 22 Elementary Weld Symbols (Tables 1 & 2)"
    },
    "theory": {
      "uz": "1-jadvaldagi barcha 22 ta boshlangʻich belgi (Elementary symbols):\n• №1: Square butt weld (||) — qirralari kesilmagan uchma-uch chok.\n• №2: Single-V butt weld (V) — bir tomonlama V-simon chok.\n• №3: Single-V butt weld with broad root face (Y) — toʻmtoqlangan V-simon chok.\n• №4: Single-bevel butt weld (|/) — bir qirrasi qiya kesilgan chok (tik chiziq chapda).\n• №5: Single-bevel butt weld with broad root face — toʻmtoqlangan 1/2 V chok.\n• №6: Single-U butt weld — U-simon chok.\n• №7: Single-J butt weld (P shakli) — J-simon chok.\n• №8: Flare-V weld — ikkita qavariq detal orasidagi chok.\n• №9: Flare-bevel weld — qavariq va tekis detal orasidagi chok.\n• №10: Fillet weld — burchakli chok (uchburchak, tik tomoni chapda).\n• №11: Plug / slot weld — teshikli / tirqishli chok (toʻrtburchak).\n• №12.1: Resistance spot weld (aylana tokcha oʻrtasida) / №12.2: Projection weld.\n• №13: Fusion spot weld (aylana tokcha ustida/ostida).\n• №14: Resistance seam weld (kesilgan aylana tokcha oʻrtasida) / №15: Fusion seam weld.\n• №16: Stud weld — shpilka payvandlash.\n• №17: Steep-flanked single-V / №18: Steep-flanked single-bevel — tik qirrali tor razdelka.\n• №19: Edge weld (Π) — qirra (tortsevoy) chok.\n• №20.1: Flange butt weld (八) / №20.2: Flange corner weld — bortli choklar.\n• №21: Surfacing — qoplama eritish (naplavka).\n• №22: Stake weld — ustunsimon (lazer/elektron nurli) chok.",
      "ru": "Все 22 начальных обозначения (Таблица 1):\n• №1: Стыковой без скоса кромок (||)\n• №2: Односторонний V-образный (V) | №3: С притуплением (Y)\n• №4: Со скосом одной кромки | №5: Со скосом одной кромки и притуплением\n• №6: Односторонний U-образный | №7: Односторонний J-образный (похож на Р)\n• №8: Между двумя закругленными | №9: Между закругленной и плоской деталями\n• №10: Угловой шов | №11: Пробочный шов (прямоугольник)\n• №12.1: Точечный контактной сваркой (по центру полки) | №12.2: Рельефный\n• №13: Точечный сваркой плавлением (на/под полкой)\n• №14: Роликовый контактный | №15: Роликовый плавлением\n• №16: Приварка шпильки\n• №17, №18: С крутой разделкой (в узкую разделку)\n• №19: Торцевой шов (Π)\n• №20.1: Стыковой с отбортовкой (八) | №20.2: Угловой с отбортовкой\n• №21: Наплавка | №22: Столбчатый шов.",
      "en": "All 22 Elementary Symbols in ISO 2553 Table 1:\n• №1: Square butt weld (||)\n• №2: Single-V butt weld (V) | №3: Single-V with broad root face (Y)\n• №4: Single-bevel butt weld | №5: Single-bevel with broad root face\n• №6: Single-U butt weld | №7: Single-J butt weld (P-like shape)\n• №8: Flare-V weld | №9: Flare-bevel weld\n• №10: Fillet weld | №11: Plug / slot weld\n• №12.1: Resistance spot weld | №12.2: Projection weld\n• №13: Fusion spot weld\n• №14: Resistance seam weld | №15: Fusion seam weld\n• №16: Stud weld\n• №17: Steep-flanked single-V | №18: Steep-flanked single-bevel\n• №19: Edge weld (Π)\n• №20.1: Flange butt weld | №20.2: Flange corner weld\n• №21: Surfacing | №22: Stake weld."
    },
    "items": [
      {
        "name": {
          "uz": "№12.1 vs №13 (Nuqtali) va №14 vs №15 (Rolikli)",
          "ru": "№12.1 vs №13 (Точечные) и №14 vs №15 (Роликовые)",
          "en": "Resistance vs Fusion Spot & Seam Welds (№12–15)"
        },
        "desc": {
          "uz": "Kontakt — tokcha oʻrtasida | Eritib — tokcha ustida/ostida",
          "ru": "Контактная — по центру полки | Плавлением — над/под полкой",
          "en": "Resistance — centered on line | Fusion — above/below line"
        },
        "symbolSvg": "<svg viewBox=\"0 0 240 80\"><line x1=\"10\" y1=\"40\" x2=\"110\" y2=\"40\" stroke=\"#38bdf8\" stroke-width=\"2\"/><circle cx=\"35\" cy=\"40\" r=\"9\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2\"/><text x=\"15\" y=\"70\" fill=\"#f59e0b\" font-size=\"9\">№12.1 Spot (Res)</text><circle cx=\"80\" cy=\"30\" r=\"9\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2\"/><text x=\"65\" y=\"70\" fill=\"#22c55e\" font-size=\"9\">№13 (Fusion)</text><line x1=\"130\" y1=\"40\" x2=\"230\" y2=\"40\" stroke=\"#38bdf8\" stroke-width=\"2\"/><circle cx=\"155\" cy=\"40\" r=\"9\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2\"/><line x1=\"143\" y1=\"37\" x2=\"167\" y2=\"37\" stroke=\"#f59e0b\" stroke-width=\"1.5\"/><line x1=\"143\" y1=\"43\" x2=\"167\" y2=\"43\" stroke=\"#f59e0b\" stroke-width=\"1.5\"/><text x=\"135\" y=\"70\" fill=\"#f59e0b\" font-size=\"9\">№14 Seam</text><circle cx=\"205\" cy=\"30\" r=\"9\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2\"/><line x1=\"193\" y1=\"27\" x2=\"217\" y2=\"27\" stroke=\"#22c55e\" stroke-width=\"1.5\"/><line x1=\"193\" y1=\"33\" x2=\"217\" y2=\"33\" stroke=\"#22c55e\" stroke-width=\"1.5\"/><text x=\"190\" y=\"70\" fill=\"#22c55e\" font-size=\"9\">№15 Fusion</text></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 240 80\"><rect x=\"20\" y=\"25\" width=\"90\" height=\"10\" fill=\"#475569\"/><rect x=\"20\" y=\"35\" width=\"90\" height=\"10\" fill=\"#64748b\"/><ellipse cx=\"65\" cy=\"35\" rx=\"12\" ry=\"5\" fill=\"#f59e0b\"/><text x=\"22\" y=\"65\" fill=\"#f59e0b\" font-size=\"9\">Kontakt (ichki yadro)</text><rect x=\"130\" y=\"25\" width=\"90\" height=\"10\" fill=\"#475569\"/><rect x=\"130\" y=\"35\" width=\"90\" height=\"10\" fill=\"#64748b\"/><path d=\"M163,25 L187,25 L178,40 L172,40 Z\" fill=\"#22c55e\"/><text x=\"135\" y=\"65\" fill=\"#22c55e\" font-size=\"9\">Eritib (yuqoridan)</text></svg>"
      },
      {
        "name": {
          "uz": "№16 Shpilka, №19 Qirra (Π), №20.1 Bortli (八)",
          "ru": "№16 Шпилька, №19 Торцевой (Π), №20.1 Отбортовка (八)",
          "en": "№16 Stud, №19 Edge (Π), №20.1 Flange Butt (八)"
        },
        "desc": {
          "uz": "Maxsus birikmalar simvollari",
          "ru": "Символы специальных соединений",
          "en": "Special joint elementary symbols"
        },
        "symbolSvg": "<svg viewBox=\"0 0 240 80\"><line x1=\"10\" y1=\"50\" x2=\"230\" y2=\"50\" stroke=\"#38bdf8\" stroke-width=\"2\"/><circle cx=\"45\" cy=\"40\" r=\"9\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2\"/><line x1=\"45\" y1=\"31\" x2=\"45\" y2=\"50\" stroke=\"#f59e0b\" stroke-width=\"2\"/><text x=\"25\" y=\"72\" fill=\"#f59e0b\" font-size=\"10\">№16 Stud</text><path d=\"M105,50 L105,28 L125,28 L125,50\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2.5\"/><text x=\"95\" y=\"72\" fill=\"#22c55e\" font-size=\"10\">№19 Edge</text><path d=\"M170,25 Q180,25 180,50 M198,25 Q188,25 188,50\" fill=\"none\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><text x=\"162\" y=\"72\" fill=\"#38bdf8\" font-size=\"10\">№20.1 Flange</text></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 240 80\"><rect x=\"20\" y=\"50\" width=\"55\" height=\"10\" fill=\"#475569\"/><rect x=\"43\" y=\"18\" width=\"9\" height=\"32\" fill=\"#f59e0b\"/><rect x=\"95\" y=\"25\" width=\"10\" height=\"35\" fill=\"#475569\"/><rect x=\"107\" y=\"25\" width=\"10\" height=\"35\" fill=\"#64748b\"/><path d=\"M95,25 Q106,16 117,25 Z\" fill=\"#22c55e\"/><path d=\"M155,55 L178,55 L178,25\" fill=\"none\" stroke=\"#475569\" stroke-width=\"8\"/><path d=\"M210,55 L187,55 L187,25\" fill=\"none\" stroke=\"#64748b\" stroke-width=\"8\"/><circle cx=\"182\" cy=\"24\" r=\"6\" fill=\"#38bdf8\"/></svg>"
      }
    ],
    "quiz": [
      {
        "question": {
          "uz": "Ushbu belgi (1-jadval, №7 — lotincha 'P' harfiga oʻxshash) qanday chokni anglatadi?",
          "ru": "Какой тип сварного шва обозначает данный символ (Таблица 1, №7)?",
          "en": "Which weld type is represented by this symbol (Table 1, No. 7)?"
        },
        "options": [
          {
            "uz": "Bir tomonlama J-simon uchma-uch chok (Single-J butt weld)",
            "ru": "Стыковой шов с односторонней J-образной разделкой одной кромки",
            "en": "Single-J butt weld"
          },
          {
            "uz": "Probochniy (teshikli) chok",
            "ru": "Пробочный шов",
            "en": "Plug weld"
          },
          {
            "uz": "Shpilka payvandlash",
            "ru": "Приварка шпильки",
            "en": "Stud weld"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №7: Vertikal chiziq va oʻng tomonda yarim yoy (J-simon qirra kesish).",
          "ru": "Таблица 1, №7: Стыковой шов с односторонней J-образной разделкой одной кромки.",
          "en": "Table 1, No. 7: Single-J butt weld."
        },
        "svg": "<svg viewBox=\"0 0 180 70\"><line x1=\"20\" y1=\"50\" x2=\"160\" y2=\"50\" stroke=\"#38bdf8\" stroke-width=\"2\"/><line x1=\"82\" y1=\"18\" x2=\"82\" y2=\"50\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><path d=\"M82,36 C98,36 98,18 98,18\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/></svg>"
      },
      {
        "question": {
          "uz": "Ushbu 'Π' shaklidagi belgi (1-jadval, №19) qanday chokni bildiradi?",
          "ru": "Что обозначает символ в виде буквы 'Π' на линии полки (Таблица 1, №19)?",
          "en": "What does this 'Π'-shaped symbol represent (Table 1, No. 19)?"
        },
        "options": [
          {
            "uz": "Qirra chok (Edge weld / Торцевой шов)",
            "ru": "Торцевой шов",
            "en": "Edge weld"
          },
          {
            "uz": "Teshikli chok (Plug weld)",
            "ru": "Пробочный шов",
            "en": "Plug weld"
          },
          {
            "uz": "Burchakli chok (Fillet weld)",
            "ru": "Угловой шов",
            "en": "Fillet weld"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №19: Pastki tomoni ochiq 'Π' shakli — yonma-yon qoʻyilgan listlarning qirrasidan payvandlash (торцевой шов).",
          "ru": "Таблица 1, №19: Торцевой шов (edge weld).",
          "en": "Table 1, No. 19: Edge weld."
        },
        "svg": "<svg viewBox=\"0 0 180 70\"><line x1=\"20\" y1=\"50\" x2=\"160\" y2=\"50\" stroke=\"#38bdf8\" stroke-width=\"2\"/><path d=\"M75,50 L75,24 L105,24 L105,50\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/></svg>"
      },
      {
        "question": {
          "uz": "Kontakt nuqtali chok (№12.1) va eritib nuqtali chok (№13) belgilari qanday farqlanadi?",
          "ru": "Как различаются символы контактного точечного (№12.1) и точечного при сварке плавлением (№13) швов?",
          "en": "How do the symbols for resistance spot weld (12.1) and fusion spot weld (13) differ?"
        },
        "options": [
          {
            "uz": "Kontakt nuqtali (№12.1) — aylana tokcha chizigʻining OʻRTASIDA chiziladi; eritib nuqtali (№13) — tokcha USTIDA yoki OSTIDA chiziladi",
            "ru": "Контактный (№12.1) — по центру линии полки; плавлением (№13) — выше или ниже линии полки",
            "en": "Resistance spot (12.1) is centered ON the reference line; fusion spot (13) is placed ABOVE or BELOW the reference line"
          },
          {
            "uz": "Kontakt nuqtali — uchburchak, eritib nuqtali — kvadrat",
            "ru": "Контактный — треугольник, плавлением — квадрат",
            "en": "Resistance is a triangle, fusion is a square"
          },
          {
            "uz": "Hech qanday farqi yoʻq",
            "ru": "Ничем не отличаются",
            "en": "No difference at all"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №12.1 va №13: Kontakt payvandlash ikki list oʻrtasida yadro hosil qilgani uchun belgi tokcha oʻrtasiga qoʻyiladi.",
          "ru": "Таблица 1, №12.1 и №13: Точечный при контактной сварке — по центру полки; при сварке плавлением — на/под полкой.",
          "en": "Table 1, No. 12.1 & 13: Resistance spot weld is centered on the reference line; fusion spot weld sits above or below it."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "1-jadval №16 dagi ichidan vertikal chiziq oʻtgan aylana belgisi nimani bildiradi?",
          "ru": "Что обозначает окружность с вертикальной линией (Таблица 1, №16)?",
          "en": "What does the circle intersected by a vertical line represent (Table 1, No. 16)?"
        },
        "options": [
          {
            "uz": "Shpilka payvandlash (Stud weld / Приварка шпильки)",
            "ru": "Приварка шпильки",
            "en": "Stud weld"
          },
          {
            "uz": "Rolikli payvandlash (Seam weld)",
            "ru": "Роликовый шов",
            "en": "Seam weld"
          },
          {
            "uz": "Teshikli chok (Plug weld)",
            "ru": "Пробочный шов",
            "en": "Plug weld"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №16: Stud weld — maxsus shpilka/bolt payvandlash belgisi.",
          "ru": "Таблица 1, №16: Приварка шпильки (stud weld).",
          "en": "Table 1, No. 16: Stud weld."
        },
        "svg": "<svg viewBox=\"0 0 180 70\"><line x1=\"20\" y1=\"52\" x2=\"160\" y2=\"52\" stroke=\"#38bdf8\" stroke-width=\"2\"/><circle cx=\"90\" cy=\"38\" r=\"12\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><line x1=\"90\" y1=\"26\" x2=\"90\" y2=\"52\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/></svg>"
      },
      {
        "question": {
          "uz": "1-jadval №17 va №18 (tik yonli tor V-razdelka — steep-flanked butt weld) qachon ishlatiladi?",
          "ru": "Для чего применяются обозначения №17 и №18 в Таблице 1?",
          "en": "What do symbols No. 17 and No. 18 in Table 1 denote?"
        },
        "options": [
          {
            "uz": "Tor razdelkali (tik qirrali) V-simon va bir qirrali uchma-uch choklar uchun",
            "ru": "Стыковые швы с крутой разделкой кромок (в узкую разделку)",
            "en": "Steep-flanked single-V and steep-flanked single-bevel butt welds (narrow gap)"
          },
          {
            "uz": "Burchakli choklar uchun",
            "ru": "Для угловых швов",
            "en": "For fillet welds"
          },
          {
            "uz": "Qoplama eritish uchun",
            "ru": "Для наплавки",
            "en": "For surfacing"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №17 va №18: Qalin metallarni tor tirqishga (uzkaya razdelka) payvandlash belgilari.",
          "ru": "Таблица 1, №17 и №18: Стыковые швы с крутой разделкой (в узкую разделку).",
          "en": "Table 1, No. 17 & 18: Steep-flanked single-V and single-bevel butt welds."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "1-jadval №20.1 (八 shaklidagi ikkita yoyilgan chiziq) nimani anglatadi?",
          "ru": "Что обозначает символ №20.1 в Таблице 1?",
          "en": "What does symbol No. 20.1 in Table 1 represent?"
        },
        "options": [
          {
            "uz": "Qirralari qayrilgan (bortli) uchma-uch chok (Flange butt weld / стыковой шов с отбортовкой кромок)",
            "ru": "Стыковой шов с отбортовкой кромок",
            "en": "Flange butt weld"
          },
          {
            "uz": "U-simon chok",
            "ru": "U-образный шов",
            "en": "Single-U butt weld"
          },
          {
            "uz": "Montaj choki",
            "ru": "Монтажный шов",
            "en": "Field weld"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №20.1 va 5.4.3-band: Qirralari qayrilgan yupqa listlarni bir-biriga eritib ulash (har doim toʻliq erish bilan bajariladi).",
          "ru": "Таблица 1, №20.1 и п. 5.4.3: Стыковой шов с отбортовкой кромок (всегда с полным проплавлением).",
          "en": "Table 1, No. 20.1 & Clause 5.4.3: Flange butt weld (always full penetration, no cross-section dimensions given)."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "2-jadval №4 da keng toʻmtoqlangan ikki tomonlama uchma-uch chok bilan birga nima kombinatsiya qilingan?",
          "ru": "Что скомбинировано в Таблице 2, №4 (двусторонний стыковой шов с широким притуплением)?",
          "en": "What is combined in Table 2, No. 4 (double-bevel / double-V with broad root face)?"
        },
        "options": [
          {
            "uz": "Uchma-uch chok va burchakli choklar (fillet welds) kombinatsiyasi",
            "ru": "Комбинация стыкового шва с широким притуплением и угловых швов",
            "en": "Combination of butt weld with broad root face and fillet welds"
          },
          {
            "uz": "Faqat nuqtali choklar",
            "ru": "Только точечные швы",
            "en": "Only spot welds"
          },
          {
            "uz": "Shpilka va naplavka",
            "ru": "Шпилька и наплавка",
            "en": "Stud weld and surfacing"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "2-jadval №4: Keng toʻmtoqlangan uchma-uch razdelka ustidan qoʻshimcha burchakli choklar (fillet welds) qoʻyilishi koʻrsatilgan.",
          "ru": "Таблица 2, №4: Стыковой шов двусторонний с широким притуплением и угловые швы.",
          "en": "Table 2, No. 4: Double butt weld with broad root face combined with fillet welds."
        },
        "svg": null
      }
    ]
  },
  {
    "id": "2553-supp",
    "pdfPage": 13,
    "title": {
      "uz": "4. Qoʻshimcha belgilar: Yuzalar, [M]/[MR], Ajratgich, Eruvchan qoʻshimcha (3–4-jadvallar)",
      "ru": "4. Вспомогательные обозначения: Поверхность, [M]/[MR], Вставка (Таблицы 3–4)",
      "en": "4. Supplementary Symbols: Finish, [M]/[MR], Spacer & Consumable Insert (Tables 3–4)"
    },
    "theory": {
      "uz": "3-jadvaldagi barcha qoʻshimcha belgilar:\n• №1 Flush / flat (—): Qavariqligi olingan tekis yuza.\n• №2 Convex (⌢): Qavariq yuza.\n• №3 Concave (⌣): Botiq yuza.\n• №4 Toes blended smoothly: Chok chekkalari asosiy metallga silliq oʻtgan (плавный переход).\n• №5 Back run / backing weld: Ildiz valigi / taglik choki (yarim doira).\n• №6 Root convexity: Ildiz qavariqligi (qora toʻldirilgan yarim doira qarama-qarshi tomonda).\n• №7 Backing [M] / [MR]: [M] — doimiy qoladigan taglik (permanent backing); [MR] — payvandlashdan keyin olib tashlanadigan taglik (removable backing).\n• №8 Spacer: Ajratgich (ikki detal orasiga qoʻyiladigan plastina/sterjen — toʻrtburchak tokcha oʻrtasida).\n• №9 Consumable insert: Eruvchan qoʻshimcha (masalan, TIG payvandlashda ildizga qoʻyiladigan halqa/sim — kichik kvadrat tokcha chizigʻida).\n• №10 Weld all-around (○): Yopiq kontur boʻylab payvandlash.\n• №11 Weld between two points (A ↔ B): Ikki nuqta orasidagi chok.\n• №12 Field weld (⚑): Montaj choki.\n• №13 Staggered intermittent weld (Z): Shaxmat tartibidagi uzuq chok.",
      "ru": "Все вспомогательные обозначения (Таблица 3):\n• №1 Выпуклость снята (плоский) | №2 Выпуклый | №3 Вогнутый\n• №4 Лицевая поверхность с плавным переходом\n• №5 Подварочный / корневой шов | №6 Выпуклость корня шва (закрашенный полукруг)\n• №7 Подкладка: [M] — остающаяся, [MR] — съемная/временная\n• №8 Разделитель (прямоугольник по центру полки)\n• №9 Плавящаяся вставка (квадрат на линии полки)\n• №10 Сварка по замкнутому контуру (○)\n• №11 Шов между двумя точками (A ↔ B)\n• №12 Монтажный шов (флажок)\n• №13 Шахматные прерывистые швы (Z).",
      "en": "All Supplementary Symbols (Table 3):\n• №1 Flush / flat | №2 Convex | №3 Concave\n• №4 Toes blended smoothly\n• №5 Back run / backing weld | №6 Root convexity (filled semicircle on opposite side)\n• №7 Backing: [M] = permanent backing, [MR] = removable/temporary backing\n• №8 Spacer (rectangle centered on reference line)\n• №9 Consumable insert (small square on reference line)\n• №10 Weld all-around (circle at junction)\n• №11 Weld between two points (A ↔ B)\n• №12 Field weld (flag at junction)\n• №13 Staggered intermittent welds (Z on reference line)."
    },
    "items": [
      {
        "name": {
          "uz": "№8 Ajratgich (Spacer) va №9 Eruvchan qoʻshimcha (Consumable insert)",
          "ru": "№8 Разделитель и №9 Плавящаяся вставка (Табл. 3)",
          "en": "№8 Spacer vs №9 Consumable Insert (Table 3)"
        },
        "desc": {
          "uz": "TIG ildiz payvandlash va ikki tomonlama razdelkalarda qoʻllaniladi",
          "ru": "Применяются при TIG сварке корня и двусторонней разделке",
          "en": "Used in root TIG welding and double-sided preparations"
        },
        "symbolSvg": "<svg viewBox=\"0 0 240 80\"><line x1=\"15\" y1=\"42\" x2=\"105\" y2=\"42\" stroke=\"#38bdf8\" stroke-width=\"2\"/><path d=\"M45,20 L58,34 L71,20 M45,64 L58,50 L71,64\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2\"/><rect x=\"48\" y=\"35\" width=\"20\" height=\"14\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2\"/><text x=\"22\" y=\"76\" fill=\"#22c55e\" font-size=\"9\">№8 Spacer</text><line x1=\"135\" y1=\"42\" x2=\"225\" y2=\"42\" stroke=\"#38bdf8\" stroke-width=\"2\"/><path d=\"M165,20 L178,42 L191,20\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2\"/><rect x=\"172\" y=\"42\" width=\"12\" height=\"12\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2\"/><text x=\"135\" y=\"76\" fill=\"#22c55e\" font-size=\"9\">№9 Consumable insert</text></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 240 80\"><polygon points=\"20,18 52,18 65,40 52,62 20,62\" fill=\"#475569\"/><polygon points=\"115,18 83,18 70,40 83,62 115,62\" fill=\"#475569\"/><rect x=\"63\" y=\"34\" width=\"9\" height=\"12\" fill=\"#22c55e\"/><polygon points=\"145,20 175,20 186,48 145,48\" fill=\"#475569\"/><polygon points=\"225,20 195,20 184,48 225,48\" fill=\"#475569\"/><rect x=\"180\" y=\"44\" width=\"10\" height=\"6\" fill=\"#22c55e\"/></svg>"
      }
    ],
    "quiz": [
      {
        "question": {
          "uz": "3-jadval №9 dagi kichik kvadrat belgisi (consumable insert) nimani bildiradi?",
          "ru": "Что означает маленький квадрат на линии полки (Таблица 3, №9)?",
          "en": "What does the small square supplementary symbol represent (Table 3, No. 9)?"
        },
        "options": [
          {
            "uz": "Eruvchan qoʻshimcha (Consumable insert / Плавящаяся вставка — chok ildiziga erib qoʻshiladigan sim/halqa)",
            "ru": "Плавящаяся вставка (включается в корень шва при сварке)",
            "en": "Consumable insert (melted into the root of the joint)"
          },
          {
            "uz": "Olib tashlanadigan poʻlat taglik",
            "ru": "Съемная подкладка",
            "en": "Removable backing"
          },
          {
            "uz": "Teshikli chok",
            "ru": "Пробочный шов",
            "en": "Plug weld"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №9: Consumable insert (плавящаяся вставка) — masalan, TIG payvandlashda ildizga qoʻyiladigan va toʻliq erib chok tarkibiga kiradigan maxsus qoʻshimcha.",
          "ru": "Таблица 3, №9: Плавящаяся вставка (вставка полностью проплавляется и входит в корень шва).",
          "en": "Table 3, No. 9: Consumable insert — melted into the root pass of the weld."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3-jadval №8 'Spacer' (разделитель) va №7 'Backing' (подкладка) oʻrtasidagi asosiy farq nima?",
          "ru": "В чем разница между разделителем (spacer, №8) и подкладкой (backing, №7)?",
          "en": "What is the main difference between a spacer (No. 8) and backing (No. 7)?"
        },
        "options": [
          {
            "uz": "Spacer — ikki detal qirralari ORASIGA qoʻyiladi; Backing — detalning ORQA (ildiz) tomoniga qoʻyiladi",
            "ru": "Разделитель ставится МЕЖДУ кромками деталей; подкладка — с ОБРАТНОЙ стороны корня",
            "en": "A spacer is placed BETWEEN the joint faces; backing is placed on the ROOT/BACK side"
          },
          {
            "uz": "Spacer faqat alyuminiydan boʻladi",
            "ru": "Разделитель только алюминиевый",
            "en": "Spacer is only made of aluminium"
          },
          {
            "uz": "Hech qanday farqi yoʻq",
            "ru": "Разницы нет",
            "en": "No difference"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №7 va №8: Ajratgich (spacer) ikki detal orasidagi tirqishga oʻrnatiladi, podkladka esa orqa tomondan tirab qoʻyiladi.",
          "ru": "Таблица 3, №7 и №8: Разделитель устанавливается в зазор между деталями, подкладка — с обратной стороны.",
          "en": "Table 3, No. 7 & 8: A spacer sits between the prepared edges; backing supports the root from behind."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3-jadval №4 'toes blended smoothly' (плавный переход) nimani talab qiladi?",
          "ru": "Что означает вспомогательное обозначение №4 в Таблице 3 (лицевая поверхность с плавным переходом)?",
          "en": "What is required by supplementary symbol No. 4 'toes blended smoothly' (Table 3)?"
        },
        "options": [
          {
            "uz": "Chok chekkalari (toes) asosiy metallga keskin oʻyiqsiz, silliq oʻtishi kerak",
            "ru": "Кромки лицевой поверхности шва должны быть плавно сглажены при сварке или обработке",
            "en": "Weld toes shall be smoothly blended by welding or post-weld finishing"
          },
          {
            "uz": "Chok yuzasi mutlaqo tekis silliqlanishi kerak",
            "ru": "Поверхность должна быть зачищена заподлицо",
            "en": "Weld must be ground completely flush"
          },
          {
            "uz": "Chok ildizida 3 mm qavariqlik boʻlishi kerak",
            "ru": "Выпуклость корня 3 мм",
            "en": "Root convexity of 3 mm"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №4 va 'c' izohi: Chokning asosiy metallga tutashgan chetlari silliq oʻtishga ega boʻlishi shart.",
          "ru": "Таблица 3, №4 и прим. c: Кромки лицевой поверхности швов должны быть сглажены.",
          "en": "Table 3, No. 4 & Note c: Weld toes shall be blended smoothly by welding or finishing."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Chok yuzasini payvandlashdan keyin bolgarka/frezada 'tekis qilib silliqlash' (заподлицо) kerak boʻlsa, bu qayerda yoziladi (3-jadval 'b' izohi)?",
          "ru": "Где указывается требование об обработке поверхности заподлицо ПОСЛЕ сварки (примечание b к Таблице 3)?",
          "en": "How is post-weld dressing to a flush/convex/concave profile specified according to Note b of Table 3?"
        },
        "options": [
          {
            "uz": "«Хвост» (tail) ichida qoʻshimcha izoh bilan (yoki ISO 1302 sirt gʻadir-budurligi belgisi bilan)",
            "ru": "Дополнительной информацией в «хвосте» (или обозначением по ИСО 1302)",
            "en": "By complementary information in the tail (e.g. 'ground flush') or ISO 1302 surface texture symbols"
          },
          {
            "uz": "Faqat qavariq yuza belgisi bilan",
            "ru": "Только символом выпуклости",
            "en": "Only with the convex symbol"
          },
          {
            "uz": "Boshlangʻich belgi ichida",
            "ru": "Внутри начального символа",
            "en": "Inside the elementary symbol"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3-jadval 'b' izohi: Oddiy tekis chiziq (—) mexanik ishlovsiz tekis chokni bildiradi; mexanik ishlov berish (silliqlash) talab qilinsa, «хвост» ga yoziladi.",
          "ru": "Примечание b к табл. 3: Обработка после сварки задается примечанием в «хвосте» или по ИСО 1302.",
          "en": "Table 3 Note b: Post-weld dressing/grinding is specified as complementary information in the tail or per ISO 1302."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3-jadval №6 'root convexity' (выпуклость корня шва) qanday choklarda va qayerda qoʻllaniladi (4.5.5)?",
          "ru": "Где и для каких швов применяется обозначение выпуклости корня шва (п. 4.5.5, рис. 3)?",
          "en": "Where and for which welds is the root convexity symbol applied (4.5.5, Fig. 3)?"
        },
        "options": [
          {
            "uz": "Bir tomonlama toʻliq erishli uchma-uch choklarda, asosiy belgining QARAMA-QARSHI tomoniga qoʻyiladi",
            "ru": "При односторонних стыковых швах с полным проплавлением, напротив начального обозначения с другой стороны полки",
            "en": "On single-sided full-penetration butt welds, placed on the opposite side of the reference line from the elementary symbol"
          },
          {
            "uz": "Burchakli choklarda asosiy belgi ustiga qoʻyiladi",
            "ru": "На угловых швах поверх основного символа",
            "en": "On fillet welds on top of the elementary symbol"
          },
          {
            "uz": "Nuqtali choklarda",
            "ru": "На точечных швах",
            "en": "On spot welds"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "4.5.5-band va 3-rasm: Qora yarim doira — chok ildizining orqa tomondan minimal chiqib turish (qavariqlik) oʻlchamini bildiradi.",
          "ru": "Пункт 4.5.5 и рис. 3: Располагают напротив начального обозначения с другой стороны линии полки.",
          "en": "Clause 4.5.5 & Fig. 3: Placed opposite the elementary symbol on the other side of the reference line."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "4-jadval (Table 4) nimaga bagʻishlangan?",
          "ru": "Чему посвящена Таблица 4 стандарта ГОСТ Р ИСО 2553-2022?",
          "en": "What does Table 4 of ISO 2553 cover?"
        },
        "options": [
          {
            "uz": "Qirralari qayrilgan (bortli) uchma-uch va burchakli choklarni A va B tizimlarida belgilashga",
            "ru": "Сварным швам стыковых и угловых соединений с отбортовкой кромок в системах А и В",
            "en": "Flanged butt and flanged corner welds in Systems A and B"
          },
          {
            "uz": "Shpilka payvandlash oʻlchamlariga",
            "ru": "Размерам приварки шпилек",
            "en": "Stud weld dimensions"
          },
          {
            "uz": "Lazerli payvandlash tezligiga",
            "ru": "Скорости лазерной сварки",
            "en": "Laser welding speed"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "4-jadval: Qirralari qayrilgan (flanged) birikmalarning A va B tizimlaridagi chizma yozuvlarini koʻrsatadi.",
          "ru": "Таблица 4: Сварные швы стыковых и угловых соединений с отбортовкой кромок.",
          "en": "Table 4: Flanged butt and corner welds in Systems A and B."
        },
        "svg": null
      }
    ]
  },
  {
    "id": "2553-dim",
    "pdfPage": 21,
    "title": {
      "uz": "5. Barcha oʻlchamlar (a, z, s, d, c, n×l(e)), Razdelka (b, α, h) va Ilova B (5–7-boʻlimlar)",
      "ru": "5. Все размеры (a, z, s, d, c, n×l(e)), Разделка (b, α, h) и Прил. В (Разделы 5–7)",
      "en": "5. All Dimensions (a, z, s, d, c, n×l(e)), Joint Prep (b, α, h) & Annex B (Sections 5–7)"
    },
    "theory": {
      "uz": "6-jadval (Table 6) boʻyicha oʻlcham harflari:\n• s — uchma-uch chokda erish chuqurligi, qirra chokda metall qalinligi, qoplamada (naplavka) qoplama qalinligi; teshikli chokda toʻliq boʻlmagan toʻldirish chuqurligi (belgi ichiga yoziladi!).\n• a — burchakli chok nominal qalinligi | z — burchakli chok kateti (har xil katetli chokda: z1 4 z2 8).\n• sa — chuqur eritishli burchakli chok (masalan, s8 a6).\n• d — yumaloq teshik diametri (№3), nuqtali chok diametri (№5), shpilka diametri (№8).\n• c — choʻzinchoq tirqish (prorez) kengligi (№4) yoki rolikli chok kengligi (№6).\n• n × l (e) — uzuq choklar: n = soni, l = har bir chok uzunligi, (e) = oraliq masofa. (Ilova C — Tinch okeani usulida 'l - e' koʻrinishida yoziladi, bu yerda 'e' — markazlar orasidagi qadam).\n• 6-boʻlim: b — zazor (belgi ichida); α — qirralar ochilish burchagi (belgi tashqarisida); h — qirra kesish chuqurligi (masalan, h6 s8). U- va J-simon choklarning radiusi va toʻmtoqligi shartli belgiga yozilmaydi (6.4-band)!\n• Ilova B (Table B.1): Turli birikma turlari uchun burchak α diapazonlari:\n  - Uchma-uch (Butt): 135° dan 180° gacha\n  - Burchakli (Fillet / T-joint): 30° dan katta va 135° dan kichik\n  - Qirra (Edge): 0° dan 30° gacha\n  - Ustma-ust (Lap): 0° dan 5° gacha.",
      "ru": "Буквенные обозначения размеров (Таблица 6):\n• s — глубина проплавления, толщина наплавки; для пробочных швов с неполным заполнением глубину 's' указывают ВНУТРИ начального обозначения.\n• a — номинальная толщина углового шва | z — катет (при разных катетах: z1 4 z2 8) | sa — глубокое проплавление.\n• d — диаметр пробки, точки или шпильки.\n• c — ширина прорези (продолговатого отверстия) или ширина роликового шва.\n• n × l (e): n — число участков, l — длина, (e) — промежуток. (В Приложении С — альтернативный метод l - e, где e — шаг между центрами).\n• Раздел 6: b — зазор (внутри символа); α — угол разделки (вне символа); h — глубина разделки (напр. h6s8). Радиусы и притупления U- и J-разделок в условном обозначении НЕ указывают (п. 6.4)!\n• Приложение В: Углы α для соединений: стыковое 135°–180°; угловое >30° и <135°; торцевое 0°–30°; нахлесточное 0°–5°.",
      "en": "Dimension Letters in ISO 2553 Table 6:\n• s — penetration depth (butt), weld thickness (edge), cladding thickness (surfacing); for partial-depth plug/slot welds, depth 's' is placed INSIDE the elementary symbol.\n• a — nominal throat thickness | z — leg length (unequal legs: z1 4 z2 8) | sa — deep penetration.\n• d — diameter of plug weld, spot weld, or stud.\n• c — width of slot weld or seam weld.\n• n × l (e): n = number of elements, l = length of each element, (e) = spacing between elements. (Annex C Pacific Rim method uses 'l - e' where e = pitch).\n• Section 6: b = root gap (inside symbol); α = bevel/groove angle (outside symbol); h = depth of preparation (e.g., h6 s8). Radii and root faces of U- and J-grooves are NOT shown on the welding symbol (6.4)!\n• Annex B Tolerances: Butt 135°–180°; Fillet >30° and <135°; Edge 0°–30°; Lap 0°–5°."
    },
    "items": [
      {
        "name": {
          "uz": "Teshikli (№3: d) va Tirqishli (№4: c) choklar + qisman toʻldirish (s)",
          "ru": "Пробочные в круглые (d) и продолговатые (c) отверстия (Табл. 6)",
          "en": "Plug (d) & Slot (c) Welds with Partial Depth (s)"
        },
        "desc": {
          "uz": "Qisman toʻldirish chuqurligi 's' toʻrtburchak belgi ichiga yoziladi",
          "ru": "Глубина неполного заполнения 's' пишется внутри прямоугольника",
          "en": "Partial fill depth 's' is written inside the rectangle symbol"
        },
        "symbolSvg": "<svg viewBox=\"0 0 240 80\"><line x1=\"15\" y1=\"52\" x2=\"225\" y2=\"52\" stroke=\"#38bdf8\" stroke-width=\"2\"/><text x=\"32\" y=\"42\" fill=\"#22c55e\" font-size=\"13\" font-weight=\"bold\">d12</text><rect x=\"58\" y=\"28\" width=\"28\" height=\"24\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2\"/><text x=\"66\" y=\"44\" fill=\"#ef4444\" font-size=\"12\" font-weight=\"bold\">s5</text><text x=\"135\" y=\"42\" fill=\"#38bdf8\" font-size=\"13\" font-weight=\"bold\">c10</text><rect x=\"160\" y=\"28\" width=\"28\" height=\"24\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2\"/></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 240 80\"><rect x=\"25\" y=\"22\" width=\"190\" height=\"22\" fill=\"#475569\"/><rect x=\"25\" y=\"44\" width=\"190\" height=\"16\" fill=\"#64748b\"/><rect x=\"75\" y=\"22\" width=\"32\" height=\"22\" fill=\"#0f172a\"/><rect x=\"75\" y=\"33\" width=\"32\" height=\"11\" fill=\"#f59e0b\"/><text x=\"55\" y=\"72\" fill=\"#ef4444\" font-size=\"10\">s5 (qisman toʻldirilgan)</text></svg>"
      }
    ],
    "quiz": [
      {
        "question": {
          "uz": "Teshikli chokda (probochniy) teshik eritilgan metall bilan TOʻLIQ emas, balki qisman (masalan, 5 mm chuqurlikda) toʻldirilishi kerak boʻlsa, 's5' qayerga yoziladi (5.6)?",
          "ru": "Где указывается глубина заполнения 's5' при неполном заполнении пробочного шва (п. 5.6, Табл. 6 №3.2)?",
          "en": "Where is the depth of filling 's' indicated for a partially filled plug or slot weld (5.6, 5.7)?"
        },
        "options": [
          {
            "uz": "Boshlangʻich belgining (toʻrtburchakning) ICHIGA yoziladi",
            "ru": "Внутри начального обозначения (прямоугольника)",
            "en": "Inside the elementary symbol (rectangle)"
          },
          {
            "uz": "Belgining chap tomoniga 'd' dan oldin yoziladi",
            "ru": "Слева от обозначения перед диаметром",
            "en": "To the left before the diameter"
          },
          {
            "uz": "Dum (tail) ichiga yoziladi",
            "ru": "Внутри хвоста",
            "en": "Inside the tail"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "5.6 va 5.7-bandlar: Teshik yoki tirqish qisman toʻldirilsa, toʻldirish chuqurligi toʻrtburchak belgi ichiga yoziladi; yozilmasa — teshik toʻliq toʻldiriladi.",
          "ru": "Пункты 5.6 и 5.7: Если отверстие заполняется не полностью, глубину заполнения указывают внутри начального обозначения.",
          "en": "Clauses 5.6 & 5.7: If the hole/slot is not to be completely filled, the depth of filling is indicated inside the elementary symbol."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "6-jadval №4 'probochniy chok choʻzinchoq tirqishga' (slot weld) kengligi qaysi harf bilan belgilanadi?",
          "ru": "Какой буквой обозначается ширина продолговатого отверстия (прорези) слева от символа (п. 5.7)?",
          "en": "Which letter designates the required width of a slot weld on the faying surface (5.7)?"
        },
        "options": [
          {
            "uz": "c (masalan, c10)",
            "ru": "c (например, c10)",
            "en": "c (e.g., c10)"
          },
          {
            "uz": "d (masalan, d10)",
            "ru": "d (например, d10)",
            "en": "d (e.g., d10)"
          },
          {
            "uz": "z (masalan, z10)",
            "ru": "z (например, z10)",
            "en": "z (e.g., z10)"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "5.7-band: Yumaloq teshik diametri — 'd', choʻzinchoq tirqish (prorez) va rolikli chok kengligi — 'c' harfi bilan yoziladi.",
          "ru": "Пункт 5.7: Обозначение ширины 'c' располагают перед требуемой шириной продолговатого отверстия слева от обозначения.",
          "en": "Clause 5.7: The width 'c' is placed before the required slot width to the left of the elementary symbol."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "U-simon va J-simon razdelkalarning egrilik radiusi va toʻmtoqlik (pritupleniye) oʻlchamlari shartli belgining oʻzida koʻrsatiladimi (6.4-band)?",
          "ru": "Указываются ли радиусы и размеры притуплений U-образных и J-образных разделок в самом условном обозначении (п. 6.4)?",
          "en": "Are radii and root faces of U- and J-groove preparations indicated on the welding symbol (Clause 6.4)?"
        },
        "options": [
          {
            "uz": "Yoʻq, shartli belgida koʻrsatilmaydi — koʻndalang kesim chizmasida yoki «хвост» da ISO 9692 ga havola orqali beriladi",
            "ru": "Нет, не указывают в условном обозначении — указывают на сечении, детали или ссылкой на ИСО 9692 в «хвосте»",
            "en": "No, they are not shown on the welding symbol; they are given on a cross-section, detail, or via ISO 9692 reference in the tail"
          },
          {
            "uz": "Ha, belgining ichiga yoziladi",
            "ru": "Да, пишутся внутри символа",
            "en": "Yes, written inside the symbol"
          },
          {
            "uz": "Ha, belgining oʻng tomoniga yoziladi",
            "ru": "Да, пишутся справа от символа",
            "en": "Yes, written to the right of the symbol"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "6.4-band: U- va J-razdelka radiusi hamda toʻmtoqligi shartli belgiga yozilmaydi, alohida kesimda yoki ISO 9692 havolasida beriladi.",
          "ru": "Пункт 6.4: Радиусы и притупления U- и J-разделок не указывают в условном обозначении.",
          "en": "Clause 6.4: Radii and root faces of U- and J-preparations shall not be indicated on the welding symbol."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Ilova B (Annex B) ga koʻra, ikki detal orasidagi burchak α necha gradus boʻlganda birikma 'Uchma-uch' (Butt joint) hisoblanadi?",
          "ru": "В каком диапазоне угла α соединение считается стыковым согласно Приложению В?",
          "en": "Within what range of angle α is a joint classified as a Butt joint according to Annex B?"
        },
        "options": [
          {
            "uz": "135° dan 180° gacha (135° va 180° ham kiradi)",
            "ru": "От 135° до 180° включительно",
            "en": "From 135° to 180° inclusive"
          },
          {
            "uz": "30° dan 135° gacha",
            "ru": "Свыше 30° и менее 135°",
            "en": "Greater than 30° and less than 135°"
          },
          {
            "uz": "0° dan 30° gacha",
            "ru": "От 0° до 30° включительно",
            "en": "From 0° to 30° inclusive"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "Ilova B (ISO 17659 dan olingan): 135°–180° = uchma-uch (butt); >30° va <135° = burchakli (fillet); 0°–30° = qirra (edge); 0°–5° = ustma-ust (lap).",
          "ru": "Приложение В: Стыковое — от 135° до 180°; угловое — свыше 30° и менее 135°; торцевое — 0°–30°; нахлесточное — 0°–5°.",
          "en": "Annex B: Butt joint = 135° to 180° inclusive; Fillet = >30° and <135°; Edge = 0° to 30°; Lap = 0° to 5°."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Har xil katetli burchakli chok (masalan, bir kateti 4 mm, ikkinchisi 8 mm) shartli belgida qanday yoziladi (5.5.1)?",
          "ru": "Как записываются размеры углового шва с различными катетами (4 мм и 8 мм) согласно п. 5.5.1?",
          "en": "How is an unequal-leg fillet weld (legs 4 mm and 8 mm) designated according to Clause 5.5.1?"
        },
        "options": [
          {
            "uz": "z1 4 z2 8 (agar chizmadan qaysi katet qayerdaligi aniq boʻlmasa, qoʻshimcha eskiz beriladi)",
            "ru": "z1 4 z2 8 (с дополнительным эскизом при необходимости)",
            "en": "z1 4 z2 8 (with additional sketch if orientation is unclear)"
          },
          {
            "uz": "a4 / a8",
            "ru": "a4 / a8",
            "en": "a4 / a8"
          },
          {
            "uz": "4 × 8",
            "ru": "4 × 8",
            "en": "4 × 8"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "5.5.1-band: Har xil katetli choklarda 'a' ishlatilmaydi, har bir katet 'z1 4 z2 8' shaklida yoziladi.",
          "ru": "Пункт 5.5.1: Для угловых швов с различными катетами используют z1 и z2 (например, z1 4 z2 8), обозначение 'a' не применяют.",
          "en": "Clause 5.5.1: Unequal leg lengths use z1 and z2 (e.g., z1 4 z2 8); 'a' is not used."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Ikki tomonlama simmetrik burchakli choklarda (ikkala tomoni ham bir xil oʻlchamda boʻlsa) oʻlcham qanday yoziladi (5.5.1)?",
          "ru": "Нужно ли указывать размеры обоих швов для симметричных двусторонних угловых швов (п. 5.5.1)?",
          "en": "Must dimensions be given for both sides of identical symmetrical double-sided fillet welds (5.5.1)?"
        },
        "options": [
          {
            "uz": "Ha, bir xil (simmetrik) burchakli choklarda ham IKKALA tomonning oʻlchami alohida yozilishi shart",
            "ru": "Да, для угловых швов размеры обоих швов указывают и для идентичных (симметричных) швов",
            "en": "Yes, dimensions for both fillet welds shall be specified even for identical symmetrical welds"
          },
          {
            "uz": "Yoʻq, faqat bitta tomonga yoziladi",
            "ru": "Нет, только с одной стороны",
            "en": "No, only on one side"
          },
          {
            "uz": "Hech bir tomonga yozilmaydi",
            "ru": "Ни с одной стороны не пишут",
            "en": "Neither side is dimensioned"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "5.5.1-band oxirgi xatboshi: Simmetrik uchma-uch choklardan farqli oʻlaroq, simmetrik burchakli choklarda ikkala tomon oʻlchami ham koʻrsatiladi.",
          "ru": "Пункт 5.5.1: Для угловых швов с обеих сторон размеры обоих швов указывают и для симметричных швов.",
          "en": "Clause 5.5.1: For fillet welds on both sides, dimensions of both welds shall be specified even if symmetrical."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Teshikli choklarda (probochniy, 6.6-band) qirralarni ochish burchagi (masalan, 45°) belgining qayeriga yoziladi?",
          "ru": "Где указывается угол разделки кромок (45°) для пробочных швов (п. 6.6, Таблица 10)?",
          "en": "Where is the bevel angle (e.g., 45°) indicated for plug and slot welds (6.6, Table 10)?"
        },
        "options": [
          {
            "uz": "Boshlangʻich belgining (toʻrtburchakning) USTIGA yoziladi",
            "ru": "Над начальным обозначением (прямоугольником)",
            "en": "Above the elementary symbol"
          },
          {
            "uz": "Belgining chap tomoniga",
            "ru": "Слева от символа",
            "en": "To the left of the symbol"
          },
          {
            "uz": "Belgining ichiga",
            "ru": "Внутри символа",
            "en": "Inside the symbol"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "6.6-band va 10-jadval: Teshikli va tirqishli choklarda qirra burchagi toʻrtburchak belgining ustiga qoʻyiladi.",
          "ru": "Пункт 6.6 и Таблица 10: Угол разделки для пробочных швов указывают над начальным обозначением.",
          "en": "Clause 6.6 & Table 10: The bevel angle for plug/slot welds is placed above the elementary symbol."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Ilova C (Tinch okeani davlatlari: AWS A2.4, JIS Z 3021 usuli) boʻyicha uzuq choklar qanday yoziladi?",
          "ru": "Как записываются прерывистые швы по альтернативному методу в Приложении С (AWS A2.4, JIS)?",
          "en": "How are intermittent welds designated in the alternative method shown in Annex C (AWS A2.4, JIS)?"
        },
        "options": [
          {
            "uz": "l - e koʻrinishida (bu yerda l — chok uzunligi, e — qoʻshni choklar MARKAZLARI orasidagi qadam/pitch)",
            "ru": "В виде l - e (где l — длина участка, e — шаг между центрами соседних участков)",
            "en": "As 'l - e' (where l = weld length, and e = pitch between centres of adjacent weld elements)"
          },
          {
            "uz": "Faqat foizda (%)",
            "ru": "Только в процентах",
            "en": "Only in percent"
          },
          {
            "uz": "n + l + e koʻrinishida",
            "ru": "В виде n + l + e",
            "en": "As n + l + e"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "Ilova C (C.2.1): Asosiy ISO usulida (e) — choklar orasidagi boʻsh masofa; Ilova C (AWS/JIS) usulida esa 'e' — markazlar orasidagi qadam (pitch).",
          "ru": "Приложение С: В методе AWS/JIS запись 'l - e' использует шаг 'e' между центрами соседних участков.",
          "en": "Annex C: In the AWS/JIS method 'l - e', 'e' is the pitch (centre-to-centre distance) rather than clear spacing."
        },
        "svg": null
      }
    ]
  }
];
