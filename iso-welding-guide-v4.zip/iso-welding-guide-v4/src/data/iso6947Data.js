export const iso6947Topics = [
  {
    "id": "6947-main",
    "pdfPage": 6,
    "title": {
      "uz": "1. Barcha asosiy payvandlash holatlari: PA – PK va Burchaklar (S, R, L)",
      "ru": "1. Все основные положения при сварке: PA – PK и Углы (S, R, L)",
      "en": "1. Main Welding Positions (PA – PK) & Angle Definitions (S, R, L)"
    },
    "theory": {
      "uz": "ISO 6947:2011 (ГОСТ Р ИСО 6947-2017) standartidagi barcha tushunchalar:\n• 2.1 welding position — chokning gorizontal tekislikka nisbatan nishablik va burilish burchaklari bilan aniqlanadigan fazoviy holati.\n• 2.2 main welding position — asosiy holatlar: PA, PB, PC, PD, PE, PF, PG (shuningdek maxsus sinovlar uchun quvur holatlari PH, PJ, PK).\n• 2.3 slope (S) — chok oʻqining asosiy holatga nisbatan nishablik burchagi.\n• 2.4 rotation (R) — chok yuzasining asosiy holatga nisbatan burilish burchagi.\n• 2.5 inclined angle (L) — quvur oʻqining qiyalik burchagi.\n• PA (0°) — flat position (нижнее): pastki holat.\n• PB (45° / 315°) — horizontal vertical position (горизонтальное тавровых): tavr birikma va vertikal oʻqli quvurda gorizontal chok.\n• PC (90° / 270°) — horizontal position (горизонтальное): gorizontal holat.\n• PD (135° / 225°) — horizontal overhead position (потолочное тавровых): tavr birikma va vertikal quvurda shift chok.\n• PE (180°) — overhead position (потолочное): shift holati.\n• PF — vertical up (вертикальное снизу вверх): vertikal pastdan yuqoriga.\n• PG — vertical down (вертикальное сверху вниз): vertikal yuqoridan pastga.\n• PH — pipe vertical up (неповоротная труба снизу вверх): qoʻzgʻalmas gorizontal quvurda pastdan yuqoriga.\n• PJ — pipe vertical down (неповоротная труба сверху вниз): qoʻzgʻalmas gorizontal quvurda yuqoridan pastga.\n• PK — orbital welding of pipes (орбитальная сварка): quvurni orbital payvandlash.",
      "ru": "Основные положения и углы по ГОСТ Р ИСО 6947-2017:\n• 2.3 наклон S (slope) — угол наклона оси шва.\n• 2.4 поворот R (rotation) — угол поворота лицевой поверхности шва.\n• 2.5 угол наклона L (inclined angle) — угол наклона оси трубы.\n• PA (0°) — нижнее положение.\n• PB (45° / 315°) — горизонтальное тавровых соединений и при вертикальной оси трубы.\n• PC (90° / 270°) — горизонтальное положение.\n• PD (135° / 225°) — потолочное тавровых соединений и при вертикальной оси трубы.\n• PE (180°) — потолочное положение.\n• PF — вертикальное снизу вверх | PG — вертикальное сверху вниз.\n• PH — вертикальное снизу вверх (труба неповоротная) | PJ — сверху вниз (труба неповоротная).\n• PK — положение трубы при орбитальной сварке.",
      "en": "Original ISO 6947:2011 Definitions & Main Welding Positions:\n• 2.3 slope (S): angle of the weld axis relative to the main welding position.\n• 2.4 rotation (R): angle of the weld face relative to the main welding position.\n• 2.5 inclined angle (L): angle of inclination of the pipe axis.\n• PA (0°): flat position.\n• PB (45° / 315°): horizontal vertical position (fillet welds in T-joints and vertical-axis pipes).\n• PC (90° / 270°): horizontal position.\n• PD (135° / 225°): horizontal overhead position (fillet welds in overhead T-joints and vertical-axis pipes).\n• PE (180°): overhead position.\n• PF: vertical up | PG: vertical down.\n• PH: vertical up (fixed horizontal pipe) | PJ: vertical down (fixed horizontal pipe).\n• PK: pipe position for orbital welding."
    },
    "items": [
      {
        "name": {
          "uz": "1-rasm: 0° dan 360° gacha asosiy holatlar doirasi",
          "ru": "Рисунок 1: Круговая схема основных положений (0°–360°)",
          "en": "Figure 1: Main Welding Positions Circle (0°–360°)"
        },
        "desc": {
          "uz": "0°=PA, 45°/315°=PB, 90°/270°=PC, 135°/225°=PD, 180°=PE",
          "ru": "0°=PA, 45°/315°=PB, 90°/270°=PC, 135°/225°=PD, 180°=PE",
          "en": "0°=PA, 45°/315°=PB, 90°/270°=PC, 135°/225°=PD, 180°=PE"
        },
        "symbolSvg": "<svg viewBox=\"0 0 240 160\"><circle cx=\"120\" cy=\"80\" r=\"48\" fill=\"none\" stroke=\"#38bdf8\" stroke-width=\"2\"/><line x1=\"120\" y1=\"22\" x2=\"120\" y2=\"138\" stroke=\"#334155\" stroke-dasharray=\"3,3\"/><line x1=\"62\" y1=\"80\" x2=\"178\" y2=\"80\" stroke=\"#334155\" stroke-dasharray=\"3,3\"/><line x1=\"80\" y1=\"40\" x2=\"160\" y2=\"120\" stroke=\"#334155\" stroke-dasharray=\"3,3\"/><line x1=\"160\" y1=\"40\" x2=\"80\" y2=\"120\" stroke=\"#334155\" stroke-dasharray=\"3,3\"/><text x=\"104\" y=\"17\" fill=\"#22c55e\" font-size=\"11\" font-weight=\"bold\">PA 0°</text><text x=\"165\" y=\"42\" fill=\"#f59e0b\" font-size=\"10\" font-weight=\"bold\">PB 45°</text><text x=\"174\" y=\"83\" fill=\"#38bdf8\" font-size=\"11\" font-weight=\"bold\">PC 90°</text><text x=\"162\" y=\"124\" fill=\"#f59e0b\" font-size=\"10\" font-weight=\"bold\">PD 135°</text><text x=\"100\" y=\"152\" fill=\"#ef4444\" font-size=\"11\" font-weight=\"bold\">PE 180°</text><text x=\"12\" y=\"83\" fill=\"#38bdf8\" font-size=\"10\">PC 270°</text><text x=\"28\" y=\"42\" fill=\"#f59e0b\" font-size=\"10\">PB 315°</text><text x=\"25\" y=\"124\" fill=\"#f59e0b\" font-size=\"10\">PD 225°</text></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 240 160\"><rect x=\"20\" y=\"55\" width=\"75\" height=\"10\" fill=\"#475569\"/><rect x=\"52\" y=\"20\" width=\"10\" height=\"35\" fill=\"#64748b\"/><polygon points=\"62,55 62,42 75,55\" fill=\"#f59e0b\"/><text x=\"38\" y=\"80\" fill=\"#f59e0b\" font-size=\"11\" font-weight=\"bold\">PB (45°)</text><rect x=\"135\" y=\"100\" width=\"75\" height=\"10\" fill=\"#475569\"/><rect x=\"167\" y=\"110\" width=\"10\" height=\"35\" fill=\"#64748b\"/><polygon points=\"177,110 177,123 190,110\" fill=\"#ef4444\"/><text x=\"150\" y=\"93\" fill=\"#ef4444\" font-size=\"11\" font-weight=\"bold\">PD (135°)</text></svg>"
      }
    ],
    "quiz": [
      {
        "question": {
          "uz": "1-rasmda 225° va 135° burchaklar qaysi payvandlash holatiga (position) toʻgʻri keladi?",
          "ru": "Какому положению при сварке соответствуют углы 135° и 225° на Рисунке 1?",
          "en": "Which welding position corresponds to 135° and 225° in Figure 1 of ISO 6947?"
        },
        "options": [
          {
            "uz": "PD (Tavr birikmalar va vertikal oʻqli quvurlarda shift holati)",
            "ru": "PD (Потолочное тавровых соединений и при вертикальной оси труб)",
            "en": "PD (Horizontal overhead position)"
          },
          {
            "uz": "PB (Tavr birikmalarda gorizontal holat)",
            "ru": "PB (Горизонтальное тавровых соединений)",
            "en": "PB (Horizontal vertical position)"
          },
          {
            "uz": "PE (Uchma-uch shift holati)",
            "ru": "PE (Потолочное положение)",
            "en": "PE (Overhead position)"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "1-rasm: 0°=PA, 45°/315°=PB, 90°/270°=PC, 135°/225°=PD, 180°=PE.",
          "ru": "Рисунок 1: Позиции 4 (135°) и 6 (225°) соответствуют положению PD.",
          "en": "Figure 1: Positions 4 (135°) and 6 (225°) correspond to position PD."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "315° burchak (1-rasm, 8-pozitsiya) qaysi asosiy holatni bildiradi?",
          "ru": "Какое основное положение обозначает позиция 8 (угол 315°) на Рисунке 1?",
          "en": "Which main welding position is shown at 315° (position 8) in Figure 1?"
        },
        "options": [
          {
            "uz": "PB",
            "ru": "PB",
            "en": "PB"
          },
          {
            "uz": "PD",
            "ru": "PD",
            "en": "PD"
          },
          {
            "uz": "PC",
            "ru": "PC",
            "en": "PC"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "1-rasm: 45° (2-pozitsiya) va 315° (8-pozitsiya) ikkalasi ham PB (tavr gorizontal) holatini bildiradi.",
          "ru": "Рисунок 1: Позиции 2 (45°) и 8 (315°) обозначают положение PB.",
          "en": "Figure 1: Both 45° (position 2) and 315° (position 8) denote position PB."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "ISO 6947 2.3 va 2.4-boʻlimlarida 'S' (slope) va 'R' (rotation) harflari nimani anglatadi?",
          "ru": "Что означают буквы 'S' (наклон) и 'R' (поворот) в разделе 2 стандарта ИСО 6947?",
          "en": "What do 'S' (slope) and 'R' (rotation) define in ISO 6947 Clauses 2.3 and 2.4?"
        },
        "options": [
          {
            "uz": "S — chok oʻqining nishablik burchagi; R — chok yuzasining burilish burchagi",
            "ru": "S — угол наклона оси шва; R — угол поворота лицевой поверхности шва",
            "en": "S = angle of the weld axis (slope); R = angle of the weld face (rotation)"
          },
          {
            "uz": "S — erish chuqurligi; R — egrilik radiusi",
            "ru": "S — глубина проплавления; R — радиус",
            "en": "S = penetration depth; R = radius"
          },
          {
            "uz": "S — poʻlat markasi; R — elektrod diametri",
            "ru": "S — марка стали; R — диаметр электрода",
            "en": "S = steel grade; R = electrode diameter"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "2.3 va 2.4-bandlar: S (slope) — chok oʻqining nishabligi, R (rotation) — chok yuzasining oʻz oʻqi atrofida burilishi.",
          "ru": "Пункты 2.3 и 2.4: S — наклон оси сварного шва, R — поворот лицевой поверхности шва.",
          "en": "Clauses 2.3 & 2.4: Slope (S) is the angle of the weld axis; rotation (R) is the angle of the weld face."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "2.5-boʻlimdagi 'L' (inclined angle) harfi qaysi detalning burchagini bildiradi?",
          "ru": "Угол наклона чего обозначает буква 'L' (inclined angle, п. 2.5)?",
          "en": "What does 'inclined angle L' (Clause 2.5) refer to?"
        },
        "options": [
          {
            "uz": "Quvur oʻqining qiyalik burchagini (masalan, L045 = 45° qiya quvur)",
            "ru": "Угол наклона оси трубы (например, L045)",
            "en": "Angle of inclination of the pipe axis (e.g., L045)"
          },
          {
            "uz": "Chok uzunligini",
            "ru": "Длину сварного шва",
            "en": "Length of the weld"
          },
          {
            "uz": "Tavr listlar orasidagi burchakni",
            "ru": "Угол между листами тавра",
            "en": "Angle between T-joint plates"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "2.5-band: L (inclined angle) — quvur oʻqining gorizontga nisbatan qiyalik burchagi.",
          "ru": "Пункт 2.5: Угол наклона L — угол наклона оси трубы.",
          "en": "Clause 2.5: Inclined angle (L) is the angle of inclination of the pipe axis."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Payvandlash holati (masalan, PA yoki PF) birikma turiga (uchma-uch yoki burchakli ekaniga) bogʻliqmi (Kirish boʻlimi)?",
          "ru": "Зависит ли положение при сварке от вида соединения (стыкового или углового) согласно Введению стандарта?",
          "en": "Does the welding position depend on the type of joint (butt or fillet) according to the ISO 6947 Introduction?"
        },
        "options": [
          {
            "uz": "Yoʻq, Kirish boʻlimida 'payvandlash holati birikma turiga bogʻliq emas, barcha turdagi choklarga tatbiq etiladi' deb belgilangan",
            "ru": "Нет, во Введении указано: положение при сварке не зависит от вида соединения и распространяется на швы всех типов",
            "en": "No, the Introduction explicitly states that welding position is independent of joint type and applies to welds of all types"
          },
          {
            "uz": "Ha, faqat uchma-uch choklarga tegishli",
            "ru": "Да, только для стыковых швов",
            "en": "Yes, only for butt welds"
          },
          {
            "uz": "Ha, faqat burchakli choklarga tegishli",
            "ru": "Да, только для угловых швов",
            "en": "Yes, only for fillet welds"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "Kirish (Introduction): Payvandlash holati birikma turiga (butt yoki fillet) bogʻliq emas.",
          "ru": "Введение: Положение при сварке не зависит от вида соединения (стыкового или углового).",
          "en": "Introduction: The welding position is independent of the type of joint (e.g. butt or fillet)."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "PH va PJ holatlari qaysi holatlar bilan bir xil harakat yoʻnalishiga ega, faqat quvurda bajariladi?",
          "ru": "Для какой трубы применяются положения PH и PJ и в чем их отличие?",
          "en": "To what pipe configuration do PH and PJ apply, and how do they differ?"
        },
        "options": [
          {
            "uz": "Qoʻzgʻalmas gorizontal quvurda: PH — pastdan yuqoriga (vertical up), PJ — yuqoridan pastga (vertical down)",
            "ru": "Для неповоротной горизонтальной трубы: PH — снизу вверх, PJ — сверху вниз",
            "en": "For a fixed horizontal pipe: PH = vertical up, PJ = vertical down"
          },
          {
            "uz": "Vertikal turgan quvurda: PH — chapga, PJ — oʻngga",
            "ru": "Для вертикальной трубы: PH — влево, PJ — вправо",
            "en": "For a vertical pipe: PH = left, PJ = right"
          },
          {
            "uz": "Aylanadigan quvurda: PH — tez, PJ — sekin",
            "ru": "Для поворотной трубы",
            "en": "For a rotated pipe"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "2-rasm h) va i): PH va PJ — oʻqi gorizontal joylashgan qoʻzgʻalmas (aylantirilmaydigan) quvur holatlari.",
          "ru": "Рисунок 2 h) и i): Неповоротная труба снизу вверх (PH) и сверху вниз (PJ).",
          "en": "Figure 2 h) & i): Fixed horizontal pipe welded vertical up (PH) or vertical down (PJ)."
        },
        "svg": null
      }
    ]
  },
  {
    "id": "6947-angles",
    "pdfPage": 10,
    "title": {
      "uz": "2. Ishlab chiqarish va Sinov chegaralari (1–2-jadvallar) hamda Qiya quvurlar (4-boʻlim)",
      "ru": "2. Допуски в производстве и при испытаниях (Табл. 1–2) и Наклонные трубы (Раздел 4)",
      "en": "2. Production & Test Tolerances (Tables 1–2) & Inclined Pipes (Section 4)"
    },
    "theory": {
      "uz": "3.2 va 3.3-boʻlimlardagi aniq burchak chegaralari:\n• 3.3 Sinov namunalari (Test pieces): Nishab S = ±5°, Burilish R = ±10° dan oshmasligi shart!\n• 1-jadval (Uchma-uch choklar — Production butt welds):\n  - PA: S = ±15°, R = ±30°\n  - PC: S = ±15°, R = +60° / −10°\n  - PE: S = ±80°, R = ±80°\n  - PF, PG: S = +75° / −10°, R = ±100° / ±180°.\n• 2-jadval (Burchakli choklar — Production fillet welds):\n  - PA: S = ±15°, R = ±30°\n  - PB: S = ±15°, R = +15° / −10°\n  - PC: S = ±15°, R = +35° / −10°\n  - PD: S = ±80°, R = +35° / −10°\n  - PE: S = ±80°, R = +35° / −10°\n  - PF, PG: S = +75° / −10°, R = ±100° / ±180°.\n• 3.2 Izoh: Assimmetrik ruxsatlarda '+' (plyus) belgi chok yuzasining PA (pastki holat) tomon burilishini, '−' (minus) belgi esa PE (shift holati) tomon burilishini bildiradi!\n• 4-boʻlim misollari: PB 015-010 (PB + 15° nishab + 10° burilish); H-L030 (30° qiya quvur, pastdan yuqoriga H); J-L060 (60° qiya quvur, yuqoridan pastga J).",
      "ru": "Предельные углы наклона S и поворота R (разделы 3.2 и 3.3):\n• 3.3 Испытания сварщиков: наклон S = ±5°, поворот R = ±10°.\n• Таблица 1 (Стыковые швы в производстве): PA (±15° / ±30°); PC (±15° / +60°..−10°); PE (±80° / ±80°); PF, PG (+75°..−10° / ±100°..±180°).\n• Таблица 2 (Угловые швы в производстве): PA (±15° / ±30°); PB (±15° / +15°..−10°); PC (±15° / +35°..−10°); PD (±80° / +35°..−10°); PE (±80° / +35°..−10°).\n• Примечание к 3.2: «Плюс» означает поворот в сторону РА, «минус» — в сторону РЕ.\n• Раздел 4: PB 015-010; H-L030 (снизу вверх H, 30°); J-L060 (сверху вниз J, 60°).",
      "en": "ISO 6947 Production & Test Piece Tolerances (3.2, 3.3, Tables 1 & 2):\n• 3.3 Test pieces: Slope S within ±5°, Rotation R within ±10°.\n• Table 1 (Production butt welds): PA (S ±15°, R ±30°); PC (S ±15°, R +60°/−10°); PE (S ±80°, R ±80°); PF/PG (S +75°/−10°, R ±100°/±180°).\n• Table 2 (Production fillet welds): PA (S ±15°, R ±30°); PB (S ±15°, R +15°/−10°); PC (S ±15°, R +35°/−10°); PD (S ±80°, R +35°/−10°); PE (S ±80°, R +35°/−10°).\n• Note to 3.2: '+' means rotation towards PA (flat); '−' means rotation towards PE (overhead).\n• Section 4 Examples: PB 015-010 (PB with 15° slope and 10° rotation); H-L030 (vertical up H, 30° inclined pipe); J-L060 (vertical down J, 60° inclined pipe)."
    },
    "items": [],
    "quiz": [
      {
        "question": {
          "uz": "3.2-boʻlim izohiga koʻra, assimmetrik burchak ruxsatlaridagi '+' (plyus) va '−' (minus) ishoralari nimani bildiradi?",
          "ru": "Что означают знаки «плюс» и «минус» при асимметричных допусках в п. 3.2?",
          "en": "In asymmetric tolerances (Note to 3.2), what do '+' and '−' indicate?"
        },
        "options": [
          {
            "uz": "'+' — chok yuzasining PA (pastki holat) tomon burilishi; '−' — PE (shift holati) tomon burilishi",
            "ru": "«Плюс» — поворот поверхности шва в сторону PA; «минус» — в сторону PE",
            "en": "'+' means rotation towards PA (flat); '−' means rotation towards PE (overhead)"
          },
          {
            "uz": "'+' — soat strelkasi boʻyicha; '−' — teskari",
            "ru": "По часовой и против часовой стрелки",
            "en": "Clockwise and counter-clockwise"
          },
          {
            "uz": "'+' — yuqoriga; '−' — pastga",
            "ru": "Вверх и вниз",
            "en": "Upwards and downwards"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "3.2-boʻlim izohi: '+' — qulayroq boʻlgan PA (pastki) holat tomon burilish, '−' — qiyinroq boʻlgan PE (shift) holat tomon burilish.",
          "ru": "Примечание к п. 3.2: «Плюс» — поворот в направлении РА, «минус» — в направлении РЕ.",
          "en": "Note to 3.2: '+' means rotation towards main welding position PA; '−' means rotation towards PE."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "2-jadvalga koʻra, burchakli choklarni PB holatida ishlab chiqarishda burilish burchagi (R) chegarasi qancha?",
          "ru": "Каковы пределы угла поворота (R) для угловых швов в положении PB в производстве (Таблица 2)?",
          "en": "What are the rotation (R) limits for production fillet welds in position PB (Table 2)?"
        },
        "options": [
          {
            "uz": "+15° / −10° (nishab S = ±15°)",
            "ru": "+15° / −10° (наклон S = ±15°)",
            "en": "+15° / −10° (slope S = ±15°)"
          },
          {
            "uz": "±80°",
            "ru": "±80°",
            "en": "±80°"
          },
          {
            "uz": "±5°",
            "ru": "±5°",
            "en": "±5°"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "2-jadval (Table 2): PB holatida burchakli chok uchun S = ±15°, R = +15° / −10°.",
          "ru": "Таблица 2: Для положения РВ наклон S = ±15°, поворот R = +15° / −10°.",
          "en": "Table 2: For PB fillet welds, slope S = ±15° and rotation R = +15° / −10°."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "1-jadvalga koʻra, uchma-uch choklarni gorizontal holatda (PC) payvandlashda burilish burchagi (R) chegarasi qancha?",
          "ru": "Каковы пределы угла поворота (R) для стыковых швов в положении PC (Таблица 1)?",
          "en": "What are the rotation (R) limits for production butt welds in position PC (Table 1)?"
        },
        "options": [
          {
            "uz": "+60° / −10° (nishab S = ±15°)",
            "ru": "+60° / −10° (наклон S = ±15°)",
            "en": "+60° / −10° (slope S = ±15°)"
          },
          {
            "uz": "±30°",
            "ru": "±30°",
            "en": "±30°"
          },
          {
            "uz": "±180°",
            "ru": "±180°",
            "en": "±180°"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "1-jadval (Table 1): Uchma-uch PC holatida R = +60° (PA tomon) va −10° (PE tomon).",
          "ru": "Таблица 1: Для стыкового положения РС поворот R = +60° / −10°.",
          "en": "Table 1: For PC butt welds, rotation R = +60° / −10°."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "4-boʻlim 3-misoldagi 'H-L030' belgisi nimani anglatadi?",
          "ru": "Что означает обозначение 'H-L030' (Раздел 4, Пример 3)?",
          "en": "What does 'H-L030' designate in ISO 6947 Section 4, Example 3?"
        },
        "options": [
          {
            "uz": "Oʻqi 30° qiya oʻrnatilgan quvurda pastdan yuqoriga (H) payvandlash",
            "ru": "Положение при сварке труб с наклонной осью 30° снизу вверх (H)",
            "en": "Welding of inclined pipe with axis at 30°, vertical up (H)"
          },
          {
            "uz": "30 mm quvurda gorizontal payvandlash",
            "ru": "Горизонтальная сварка трубы 30 мм",
            "en": "Horizontal welding of 30 mm pipe"
          },
          {
            "uz": "Yuqoridan pastga 30° payvandlash",
            "ru": "Сварка сверху вниз под 30°",
            "en": "Vertical down at 30°"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "4-boʻlim, 3-misol: H — pastdan yuqoriga, L030 — quvur oʻqining 30° qiyalik burchagi.",
          "ru": "Раздел 4, Пример 3: H — снизу вверх, L030 — угол наклона оси трубы 30°.",
          "en": "Section 4, Example 3: H = vertical up, L030 = pipe axis inclined at 30°."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "2-jadvalga koʻra, burchakli choklarni PD va PE holatlarida ishlab chiqarishda S va R burchak chegaralari qancha?",
          "ru": "Каковы предельные углы S и R для потолочных угловых швов (PD и PE) в Таблице 2?",
          "en": "What are the slope (S) and rotation (R) limits for production fillet welds in PD and PE (Table 2)?"
        },
        "options": [
          {
            "uz": "S = ±80°, R = +35° / −10°",
            "ru": "S = ±80°, R = +35° / −10°",
            "en": "S = ±80°, R = +35° / −10°"
          },
          {
            "uz": "S = ±15°, R = ±30°",
            "ru": "S = ±15°, R = ±30°",
            "en": "S = ±15°, R = ±30°"
          },
          {
            "uz": "S = ±5°, R = ±10°",
            "ru": "S = ±5°, R = ±10°",
            "en": "S = ±5°, R = ±10°"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "2-jadval (Table 2): Burchakli PD va PE holatlarida nishab S = ±80° gacha, burilish R = +35° / −10° gacha ruxsat etiladi.",
          "ru": "Таблица 2: Для PD и PE угловых швов S = ±80°, R = +35° / −10°.",
          "en": "Table 2: For PD and PE fillet welds, S = ±80° and R = +35° / −10°."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "1 va 2-jadvallarda vertikal holat (PF, PG) uchun nishab S ning ruxsat etilgan chegarasi qancha?",
          "ru": "Каково предельное значение наклона S для вертикального положения (PF, PG) в Таблицах 1 и 2?",
          "en": "What is the slope (S) limit for vertical positions (PF, PG) in Tables 1 and 2?"
        },
        "options": [
          {
            "uz": "+75° / −10°",
            "ru": "+75° / −10°",
            "en": "+75° / −10°"
          },
          {
            "uz": "±15°",
            "ru": "±15°",
            "en": "±15°"
          },
          {
            "uz": "±5°",
            "ru": "±5°",
            "en": "±5°"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "1 va 2-jadvallar: Vertikal PF va PG holatlarida nishab S = +75° / −10° oraligʻida boʻladi.",
          "ru": "Таблицы 1 и 2: Для PF и PG пределы наклона S составляют +75° / −10°.",
          "en": "Tables 1 & 2: Slope (S) limits for PF and PG are +75° / −10°."
        },
        "svg": null
      }
    ]
  },
  {
    "id": "6947-aws",
    "pdfPage": 17,
    "title": {
      "uz": "3. ISO 6947 va AWS / ASME (1G–6G, 1F–5F, 1FR, 2FR) toʻliq taqqoslash jadvali (Ilova B)",
      "ru": "3. Полное сравнение ISO 6947 и AWS / ASME (1G–6G, 1F–5F, 1FR, 2FR) (Прил. В)",
      "en": "3. Complete Comparison: ISO 6947 vs AWS A3.0 / ASME IX (Annex B, Table B.1)"
    },
    "theory": {
      "uz": "Ilova B (Table B.1) — xalqaro ISO 6947 va Amerika (AWS A3.0 / ASME Section IX) belgilari oʻrtasidagi toʻliq muvofiqlik:\n• 1G (plastina va aylanadigan gorizontal quvur) = PA\n• 2G (vertikal devorda gorizontal chok / vertikal quvurda gorizontal chok) = PC\n• 3G uphill = PF | 3G downhill = PG\n• 4G (plastina shift holati) = PE\n• 5G uphill (qoʻzgʻalmas gorizontal quvur, pastdan yuqoriga) = PH\n• 5G downhill (qoʻzgʻalmas gorizontal quvur, yuqoridan pastga) = PJ\n• 6G uphill (45° qiya qoʻzgʻalmas quvur, pastdan yuqoriga) = H-L045\n• 6G downhill (45° qiya qoʻzgʻalmas quvur, yuqoridan pastga) = J-L045\n• 1F (pastki 'qayiqcha' burchakli chok) = PA | 1FR (aylanadigan quvur burchakli chok) = PA\n• 2F (tavr gorizontal / vertikal quvur burchakli) = PB | 2FR (gorizontal oʻqli aylanadigan quvur burchakli) = PB\n• 3F uphill = PF | 3F downhill = PG\n• 4F (tavr shift / vertikal quvur shift burchakli) = PD\n• 5F uphill (qoʻzgʻalmas gorizontal quvur burchakli, pastdan yuqoriga) = PH | 5F downhill = PJ.",
      "ru": "Полная таблица соответствия В.1 (ISO 6947 ↔ AWS A3.0 / ASME IX):\n• 1G / 1F / 1FR = PA\n• 2G = PC | 2F / 2FR = PB\n• 3G uphill / 3F uphill = PF | 3G downhill / 3F downhill = PG\n• 4G = PE | 4F = PD\n• 5G uphill / 5F uphill = PH | 5G downhill / 5F downhill = PJ\n• 6G uphill = H-L045 | 6G downhill = J-L045.",
      "en": "Complete Table B.1 Comparison (ISO 6947 ↔ AWS A3.0 / ASME Section IX):\n• 1G / 1F / 1FR (rotated pipe) = PA\n• 2G = PC | 2F / 2FR (rotated horizontal-axis pipe) = PB\n• 3G uphill / 3F uphill = PF | 3G downhill / 3F downhill = PG\n• 4G = PE | 4F = PD\n• 5G uphill / 5F uphill = PH | 5G downhill / 5F downhill = PJ\n• 6G uphill = H-L045 | 6G downhill = J-L045."
    },
    "items": [],
    "quiz": [
      {
        "question": {
          "uz": "AWS/ASME standartidagi '2FR' (oʻqi gorizontal joylashgan va AYLANTIRIB payvandlanadigan quvur burchakli choki) ISO 6947 da qanday belgilanadi?",
          "ru": "Какому положению по ИСО 6947 соответствует '2FR' (поворотная труба с горизонтальной осью, угловой шов) в Таблице В.1?",
          "en": "Which ISO 6947 position corresponds to '2FR' (horizontal-axis rotated pipe fillet weld) in Table B.1?"
        },
        "options": [
          {
            "uz": "PB",
            "ru": "PB",
            "en": "PB"
          },
          {
            "uz": "PA",
            "ru": "PA",
            "en": "PA"
          },
          {
            "uz": "PC",
            "ru": "PC",
            "en": "PC"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "B.1-jadval (15-bet): 2F va 2FR (gorizontal oʻqli aylanadigan quvur) ikkalasi ham PB ga teng; 1FR (45° qiya aylanadigan quvur) esa PA ga teng.",
          "ru": "Таблица В.1: 2FR (горизонтальное при горизонтальном положении осей труб, труба поворотная) = PB.",
          "en": "Table B.1: 2FR (rotated pipe with horizontal axis) corresponds to PB, whereas 1FR (45° rotated pipe) corresponds to PA."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "AWS/ASME standartidagi '5F downhill' (qoʻzgʻalmas gorizontal quvurda burchakli chokni yuqoridan pastga payvandlash) ISO 6947 da qanday yoziladi?",
          "ru": "Какому обозначению ИСО 6947 соответствует '5F downhill' (Таблица В.1)?",
          "en": "Which ISO 6947 position corresponds to '5F downhill' in Table B.1?"
        },
        "options": [
          {
            "uz": "PJ",
            "ru": "PJ",
            "en": "PJ"
          },
          {
            "uz": "PH",
            "ru": "PH",
            "en": "PH"
          },
          {
            "uz": "PG",
            "ru": "PG",
            "en": "PG"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "B.1-jadval (16-bet): 5G uphill va 5F uphill = PH; 5G downhill va 5F downhill = PJ.",
          "ru": "Таблица В.1: 5F downhill (неповоротная труба сверху вниз) = PJ.",
          "en": "Table B.1: Both 5G downhill and 5F downhill correspond to PJ."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "AWS/ASME standartidagi '6G downhill' (45° qiya qoʻzgʻalmas quvurda yuqoridan pastga payvandlash) ISO 6947 da qanday belgilanadi?",
          "ru": "Какому обозначению ИСО 6947 соответствует '6G downhill'?",
          "en": "What is the ISO 6947 designation for '6G downhill'?"
        },
        "options": [
          {
            "uz": "J-L045",
            "ru": "J-L045",
            "en": "J-L045"
          },
          {
            "uz": "H-L045",
            "ru": "H-L045",
            "en": "H-L045"
          },
          {
            "uz": "PJ-045",
            "ru": "PJ-045",
            "en": "PJ-045"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "B.1-jadval (14-bet): 6G uphill = H-L045; 6G downhill = J-L045.",
          "ru": "Таблица В.1: 6G downhill (сверху вниз, угол 45°) = J-L045.",
          "en": "Table B.1: 6G downhill corresponds to J-L045."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "AWS/ASME standartidagi '3F uphill' holati ISO 6947 boʻyicha qaysi belgiga mos keladi?",
          "ru": "Какому положению ИСО 6947 соответствует '3F uphill'?",
          "en": "Which ISO 6947 position matches '3F uphill'?"
        },
        "options": [
          {
            "uz": "PF",
            "ru": "PF",
            "en": "PF"
          },
          {
            "uz": "PG",
            "ru": "PG",
            "en": "PG"
          },
          {
            "uz": "PB",
            "ru": "PB",
            "en": "PB"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "B.1-jadval (15-bet): 3G uphill va 3F uphill ikkalasi ham PF (vertikal pastdan yuqoriga) ga teng.",
          "ru": "Таблица В.1: 3F uphill (снизу вверх) = PF.",
          "en": "Table B.1: Both 3G uphill and 3F uphill correspond to PF."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Amerika standartidagi 'G' (masalan, 1G, 2G, 6G) va 'F' (1F, 2F, 4F) harflari nimani bildiradi?",
          "ru": "Что означают буквы 'G' и 'F' в американских обозначениях AWS/ASME (1G–6G и 1F–5F)?",
          "en": "What do the letters 'G' and 'F' stand for in AWS/ASME welding position designations (1G–6G, 1F–5F)?"
        },
        "options": [
          {
            "uz": "G = Groove weld (uchma-uch chok), F = Fillet weld (burchakli chok)",
            "ru": "G = стыковой шов (Groove), F = угловой шов (Fillet)",
            "en": "G = Groove weld (butt), F = Fillet weld"
          },
          {
            "uz": "G = Gazli payvandlash, F = Flyus ostida",
            "ru": "G = газовая, F = под флюсом",
            "en": "G = Gas, F = Flux"
          },
          {
            "uz": "G = Gorizontal, F = Vertikal",
            "ru": "G = горизонтальный, F = вертикальный",
            "en": "G = Horizontal, F = Vertical"
          }
        ],
        "correct": 0,
        "explanation": {
          "uz": "AWS A3.0 / ASME IX: G — Groove (uchma-uch choklar), F — Fillet (burchakli choklar), R — Rotated (aylantiriladigan quvur).",
          "ru": "AWS A3.0 / ASME IX: G — стыковые швы (Groove), F — угловые швы (Fillet).",
          "en": "AWS A3.0 / ASME IX: G stands for Groove weld, F stands for Fillet weld, and R stands for Rotated pipe."
        },
        "svg": null
      }
    ]
  }
];
