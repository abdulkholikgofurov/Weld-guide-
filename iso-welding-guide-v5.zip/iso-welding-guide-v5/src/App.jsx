import React, { useState } from 'react';
import { iso2553Topics } from './data/iso2553Data';
import { iso6947Topics } from './data/iso6947Data';
import SymbolBuilder2553 from './components/SymbolBuilder2553';
import AngleSimulator6947 from './components/AngleSimulator6947';
import PdfViewerModal from './components/PdfViewerModal';

export default function App() {
  const [lang, setLang] = useState('uz');
  const [standard, setStandard] = useState(null);
  const [activeTopic, setActiveTopic] = useState(null);
  const [pdfModal, setPdfModal] = useState(null);
  const [quizAnswers, setQuizAnswers] = useState({});

  const topics = standard === '2553' ? iso2553Topics : iso6947Topics;
  const pdfFile = standard === '2553' ? './pdf/ISO-2553_RU.pdf' : './pdf/ISO-6947_RU.pdf';

  const total2553Tests = iso2553Topics.reduce((s, t) => s + t.quiz.length, 0);
  const total6947Tests = iso6947Topics.reduce((s, t) => s + t.quiz.length, 0);

  const correctCount = activeTopic
    ? activeTopic.quiz.reduce((acc, q, idx) => (quizAnswers[idx] === q.correct ? acc + 1 : acc), 0)
    : 0;

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-sans pb-12">
      <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur border-b border-slate-800 px-3 py-2.5 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          {(standard || activeTopic) && (
            <button
              onClick={() => activeTopic ? setActiveTopic(null) : setStandard(null)}
              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-xl text-sky-400 font-bold text-xs shrink-0"
            >
              ← {lang === 'uz' ? 'Orqaga' : lang === 'ru' ? 'Назад' : 'Back'}
            </button>
          )}
          <span className="font-extrabold text-xs sm:text-sm tracking-tight text-white truncate">
            {standard ? `ISO ${standard}` : 'WELDING ISO PRO'}
          </span>
        </div>

        <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl border border-slate-700 shrink-0">
          <button onClick={() => setLang('uz')} className={`px-2 py-1 rounded-lg text-[11px] font-bold transition ${lang === 'uz' ? 'bg-sky-600 text-white shadow' : 'opacity-60'}`}>
            🇺🇿 UZ
          </button>
          <button onClick={() => setLang('ru')} className={`px-2 py-1 rounded-lg text-[11px] font-bold transition ${lang === 'ru' ? 'bg-sky-600 text-white shadow' : 'opacity-60'}`}>
            🇷🇺 RU
          </button>
          <button onClick={() => setLang('en')} className={`px-2 py-1 rounded-lg text-[11px] font-bold transition ${lang === 'en' ? 'bg-amber-600 text-white shadow' : 'opacity-60'}`}>
            🇬🇧 EN
          </button>
        </div>
      </header>

      <main className="max-w-xl mx-auto p-4">
        {!standard && (
          <div className="space-y-4 mt-2">
            <div className="text-center mb-5">
              <div className="inline-block px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-amber-400 text-[11px] font-bold mb-2">
                ISO 9606-1 / ISO 2553:2019 / ISO 6947:2011
              </div>
              <h1 className="text-xl font-black text-white">
                {lang === 'uz' ? 'Payvandlash xalqaro standartlari' : lang === 'ru' ? 'Международные стандарты сварки' : 'International Welding Standards'}
              </h1>
            </div>

            <button
              onClick={() => setStandard('2553')}
              className="w-full text-left bg-slate-800/90 hover:bg-slate-800 border-2 border-sky-500/40 hover:border-sky-400 p-5 rounded-2xl shadow-xl transition"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-extrabold text-sky-400">ISO 2553:2019 / ГОСТ Р ИСО 2553-2022</span>
                <span className="text-[11px] bg-sky-500/20 text-sky-300 px-2 py-0.5 rounded-full font-bold">{total2553Tests} tests</span>
              </div>
              <div className="text-lg font-black text-white mb-2">
                {lang === 'uz' ? 'Chizmalardagi shartli belgilar' : lang === 'ru' ? 'Условные обозначения на чертежах' : 'Symbolic Representation on Drawings'}
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {lang === 'uz'
                  ? '23 ta atama, A va B tizimlari, barcha 22 xil chok belgilari, 13 xil qoʻshimcha belgilar (M/MR, Spacer, Insert) + Jonli konstruktor'
                  : lang === 'ru'
                  ? '23 термина, системы А и В, все 22 начальных и 13 вспомогательных обозначений (M/MR, Spacer, Insert) + Живой конструктор'
                  : 'All 23 terms, Systems A & B, all 22 elementary & 13 supplementary symbols (M/MR, Spacer, Insert) + Live Builder'}
              </p>
            </button>

            <button
              onClick={() => setStandard('6947')}
              className="w-full text-left bg-slate-800/90 hover:bg-slate-800 border-2 border-amber-500/40 hover:border-amber-400 p-5 rounded-2xl shadow-xl transition"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-extrabold text-amber-400">ISO 6947:2011 / ГОСТ Р ИСО 6947-2017</span>
                <span className="text-[11px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-bold">{total6947Tests} tests</span>
              </div>
              <div className="text-lg font-black text-white mb-2">
                {lang === 'uz' ? 'Payvandlash fazoviy holatlari' : lang === 'ru' ? 'Положения при сварке' : 'Welding Positions'}
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {lang === 'uz'
                  ? 'PA–PK holatlari, S/R/L burchaklari, sinov va ishlab chiqarish ruxsatlari, AWS/ASME (1G–6G, 1F–5F, 1FR, 2FR) + Simulyator'
                  : lang === 'ru'
                  ? 'Положения PA–PK, углы S, R, L, допуски испытаний и производства, сравнение с AWS/ASME (1G–6G, 1F–5F) + Симулятор'
                  : 'PA–PK positions, Slope (S), Rotation (R), Inclined Angle (L), tolerances, AWS/ASME (1G–6G, 1F–5F) + Simulator'}
              </p>
            </button>
          </div>
        )}

        {standard && !activeTopic && (
          <div className="space-y-3">
            {standard === '2553' ? <SymbolBuilder2553 lang={lang} /> : <AngleSimulator6947 lang={lang} />}

            <h2 className="text-xs font-extrabold text-slate-400 uppercase tracking-wider mt-5 mb-2">
              {lang === 'uz' ? 'Mavzulashtirilgan boʻlimlar va testlar' : lang === 'ru' ? 'Тематические разделы и тесты' : 'Modules & Practice Tests'}
            </h2>

            {topics.map((t) => (
              <button
                key={t.id}
                onClick={() => { setActiveTopic(t); setQuizAnswers({}); window.scrollTo(0, 0); }}
                className="w-full text-left bg-slate-800 hover:bg-slate-750 border border-slate-700 p-4 rounded-xl flex items-center justify-between transition"
              >
                <div className="pr-2">
                  <div className="font-bold text-white text-sm">{t.title[lang]}</div>
                  <div className="text-xs text-slate-400 mt-1">
                    {lang === 'uz'
                      ? `📝 Test: ${t.quiz.length} savol  |  📖 Kitob: ${t.pdfPage}-bet`
                      : lang === 'ru'
                      ? `📝 Тест: ${t.quiz.length} вопр.  |  📖 Книга: стр. ${t.pdfPage}`
                      : `📝 Quiz: ${t.quiz.length} questions  |  📖 Standard: p. ${t.pdfPage}`}
                  </div>
                </div>
                <span className="text-sky-400 font-black text-lg">→</span>
              </button>
            ))}
          </div>
        )}

        {activeTopic && (
          <div className="space-y-4">
            <h2 className="text-base font-extrabold text-amber-400">{activeTopic.title[lang]}</h2>

            <div className="bg-slate-800/90 border border-slate-700 p-4 rounded-2xl text-xs sm:text-sm leading-relaxed whitespace-pre-line text-slate-200">
              {activeTopic.theory[lang]}
            </div>

            {activeTopic.items.map((item, idx) => (
              <div key={idx} className="bg-slate-800 border border-slate-700 rounded-2xl p-3.5">
                <div className="font-bold text-sky-400 text-xs sm:text-sm mb-0.5">{item.name[lang]}</div>
                <div className="text-[11px] text-slate-400 mb-3">{item.desc[lang]}</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div className="bg-slate-950 p-2 rounded-xl border border-slate-700">
                    <div dangerouslySetInnerHTML={{ __html: item.symbolSvg }} />
                  </div>
                  <div className="bg-slate-950 p-2 rounded-xl border border-slate-700">
                    <div dangerouslySetInnerHTML={{ __html: item.crossSectionSvg }} />
                  </div>
                </div>
              </div>
            ))}

            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-green-400 text-sm">
                  {lang === 'uz' ? '📝 Mavzu boʻyicha test' : lang === 'ru' ? '📝 Тест по разделу' : '📝 Section Quiz'}
                </h3>
                <span className="text-xs font-bold bg-slate-900 px-2.5 py-1 rounded-lg text-amber-400">
                  {correctCount} / {activeTopic.quiz.length}
                </span>
              </div>

              {activeTopic.quiz.map((q, qIdx) => {
                const chosen = quizAnswers[qIdx];
                return (
                  <div key={qIdx} className="border-t border-slate-700 pt-3">
                    <div className="font-semibold text-xs sm:text-sm text-white mb-2">
                      {qIdx + 1}. {q.question[lang]}
                    </div>
                    {q.svg && (
                      <div className="bg-slate-950 p-2 rounded-xl mb-3 max-w-xs mx-auto border border-slate-800" dangerouslySetInnerHTML={{ __html: q.svg }} />
                    )}
                    {q.optionSvgs && (
                      <div className="grid grid-cols-3 gap-1.5 mb-2">
                        {q.optionSvgs.map((osvg, sIdx) => (
                          <div key={sIdx} className="bg-slate-950 p-1.5 rounded-lg border border-slate-700 text-center">
                            <div className="text-[10px] font-bold text-amber-400 mb-0.5">{['A', 'B', 'C'][sIdx]}</div>
                            <div dangerouslySetInnerHTML={{ __html: osvg }} />
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="space-y-2">
                      {q.options.map((opt, oIdx) => {
                        let btnStyle = 'bg-slate-900 border-slate-700 text-slate-200';
                        if (chosen !== undefined) {
                          if (oIdx === q.correct) btnStyle = 'bg-green-900/60 border-green-500 text-green-200 font-bold';
                          else if (oIdx === chosen) btnStyle = 'bg-red-900/60 border-red-500 text-red-200';
                        }
                        return (
                          <button
                            key={oIdx}
                            onClick={() => setQuizAnswers({ ...quizAnswers, [qIdx]: oIdx })}
                            className={`w-full text-left p-3 rounded-xl border text-xs transition ${btnStyle}`}
                          >
                            {opt[lang]}
                          </button>
                        );
                      })}
                    </div>
                    {chosen !== undefined && (
                      <div className="mt-2 p-2.5 bg-sky-950/70 border border-sky-700 rounded-xl text-xs text-sky-200">
                        💡 {q.explanation[lang]}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => setPdfModal(activeTopic.pdfPage)}
              className="w-full py-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-2xl shadow-lg text-xs sm:text-sm flex items-center justify-center gap-2"
            >
              📖 {lang === 'uz'
                ? `Kitobdan tekshirish (${activeTopic.pdfPage}-sahifa)`
                : lang === 'ru'
                ? `Проверить по книге (стр. ${activeTopic.pdfPage})`
                : `Verify in Standard PDF (Page ${activeTopic.pdfPage})`}
            </button>
          </div>
        )}
      </main>

      {pdfModal && (
        <PdfViewerModal
          pdfUrl={pdfFile}
          pageNumber={pdfModal}
          onClose={() => setPdfModal(null)}
          lang={lang}
        />
      )}
    </div>
  );
}
