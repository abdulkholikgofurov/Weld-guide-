import React, { useState } from 'react';

export default function AngleSimulator6947({ lang }) {
  const [mode, setMode] = useState('plate');
  const [slope, setSlope] = useState(0);
  const [rotation, setRotation] = useState(0);
  const [pipeAngle, setPipeAngle] = useState(45);
  const [direction, setDirection] = useState('up');
  const [jointType, setJointType] = useState('butt');

  const T = {
    uz: {
      title: '🧭 ISO 6947 Fazoviy Burchak Simulyatori',
      plateBtn: 'Plastina',
      pipeBtn: 'Quvur',
      buttBtn: 'Uchma-uch (G)',
      filletBtn: 'Burchakli (F)',
      rotLbl: 'Burilish burchagi (R):',
      slopeLbl: 'Chok oʻqi nishabligi (S):',
      pipeLbl: 'Quvur oʻqi qiyaligi (L):',
      upPlate: '↑ Pastdan yuqoriga (PF)',
      downPlate: '↓ Yuqoridan pastga (PG)',
      upPipe: '↑ Pastdan yuqoriga (H / PH)',
      downPipe: '↓ Yuqoridan pastga (J / PJ)',
      d_fixedHoriz: 'Qoʻzgʻalmas gorizontal quvur',
      d_fixedVert: 'Vertikal quvur (gorizontal chok)',
      d_inclined: `Qiya qoʻzgʻalmas quvur (${pipeAngle}°)`,
      d_vertUp: 'Vertikal: pastdan yuqoriga',
      d_vertDown: 'Vertikal: yuqoridan pastga',
      d_flat: 'Pastki holat (0°)',
      d_horiz: 'Gorizontal holat (90°)',
      d_over: 'Shift holati (180°)',
      d_flatFillet: 'Pastki «qayiqcha» holati',
      d_pb: 'Tavr gorizontal holat (45°)',
      d_pd: 'Tavr shift holati (135°)'
    },
    ru: {
      title: '🧭 Симулятор углов ИСО 6947',
      plateBtn: 'Пластина',
      pipeBtn: 'Труба',
      buttBtn: 'Стыковой (G)',
      filletBtn: 'Угловой (F)',
      rotLbl: 'Угол поворота (R):',
      slopeLbl: 'Угол наклона оси (S):',
      pipeLbl: 'Угол наклона трубы (L):',
      upPlate: '↑ Снизу вверх (PF)',
      downPlate: '↓ Сверху вниз (PG)',
      upPipe: '↑ Снизу вверх (H / PH)',
      downPipe: '↓ Сверху вниз (J / PJ)',
      d_fixedHoriz: 'Неповоротная горизонтальная труба',
      d_fixedVert: 'Вертикальная труба (горизонтальный шов)',
      d_inclined: `Наклонная неповоротная труба (${pipeAngle}°)`,
      d_vertUp: 'Вертикальное: снизу вверх',
      d_vertDown: 'Вертикальное: сверху вниз',
      d_flat: 'Нижнее положение (0°)',
      d_horiz: 'Горизонтальное положение (90°)',
      d_over: 'Потолочное положение (180°)',
      d_flatFillet: 'Нижнее положение «в лодочку»',
      d_pb: 'Горизонтальное тавровое (45°)',
      d_pd: 'Потолочное тавровое (135°)'
    },
    en: {
      title: '🧭 ISO 6947 Welding Position Simulator',
      plateBtn: 'Plate',
      pipeBtn: 'Pipe',
      buttBtn: 'Butt (G)',
      filletBtn: 'Fillet (F)',
      rotLbl: 'Rotation angle (R):',
      slopeLbl: 'Slope angle (S):',
      pipeLbl: 'Pipe inclined angle (L):',
      upPlate: '↑ Vertical Up (PF)',
      downPlate: '↓ Vertical Down (PG)',
      upPipe: '↑ Uphill (H / PH)',
      downPipe: '↓ Downhill (J / PJ)',
      d_fixedHoriz: 'Fixed horizontal pipe',
      d_fixedVert: 'Fixed vertical pipe (horizontal weld)',
      d_inclined: `Fixed inclined pipe (${pipeAngle}°)`,
      d_vertUp: 'Vertical up',
      d_vertDown: 'Vertical down',
      d_flat: 'Flat position (0°)',
      d_horiz: 'Horizontal position (90°)',
      d_over: 'Overhead position (180°)',
      d_flatFillet: 'Flat fillet position',
      d_pb: 'Horizontal vertical (45°)',
      d_pd: 'Horizontal overhead (135°)'
    }
  }[lang];

  const detectPosition = () => {
    if (mode === 'pipe') {
      if (pipeAngle === 0) return { code: direction === 'up' ? 'PH' : 'PJ', aws: direction === 'up' ? '5G uphill' : '5G downhill', desc: T.d_fixedHoriz };
      if (pipeAngle === 90) return { code: 'PC', aws: '2G', desc: T.d_fixedVert };
      const pad = String(pipeAngle).padStart(3, '0');
      return {
        code: `${direction === 'up' ? 'H' : 'J'}-L${pad}`,
        aws: pipeAngle === 45 ? (direction === 'up' ? '6G uphill' : '6G downhill') : `L${pad}`,
        desc: T.d_inclined
      };
    }

    if (slope >= 75) {
      return {
        code: direction === 'up' ? 'PF' : 'PG',
        aws: `${jointType === 'butt' ? '3G' : '3F'} ${direction === 'up' ? 'uphill' : 'downhill'}`,
        desc: direction === 'up' ? T.d_vertUp : T.d_vertDown
      };
    }
    if (jointType === 'butt') {
      if (rotation <= 30) return { code: 'PA', aws: '1G', desc: T.d_flat };
      if (rotation > 30 && rotation <= 100) return { code: 'PC', aws: '2G', desc: T.d_horiz };
      return { code: 'PE', aws: '4G', desc: T.d_over };
    } else {
      if (rotation <= 30) return { code: 'PA', aws: '1F', desc: T.d_flatFillet };
      if (rotation > 30 && rotation <= 80) return { code: 'PB', aws: '2F', desc: T.d_pb };
      if (rotation > 80 && rotation <= 100) return { code: 'PC', aws: '2G/2F', desc: T.d_horiz };
      if (rotation > 100 && rotation < 150) return { code: 'PD', aws: '4F', desc: T.d_pd };
      return { code: 'PE', aws: '4G/4F', desc: T.d_over };
    }
  };

  const pos = detectPosition();

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 my-3 shadow-lg">
      <div className="flex items-center justify-between mb-3 gap-1">
        <h3 className="text-sky-400 font-bold text-xs sm:text-sm">{T.title}</h3>
        <div className="flex gap-1">
          <button onClick={() => setMode(m => m === 'plate' ? 'pipe' : 'plate')} className="px-2 py-1 bg-sky-700 rounded-lg text-[11px] font-bold text-white">
            {mode === 'plate' ? T.plateBtn : T.pipeBtn}
          </button>
          {mode === 'plate' && (
            <button onClick={() => setJointType(j => j === 'butt' ? 'fillet' : 'butt')} className="px-2 py-1 bg-slate-700 rounded-lg text-[11px] font-bold text-amber-400">
              {jointType === 'butt' ? T.buttBtn : T.filletBtn}
            </button>
          )}
        </div>
      </div>

      <div className="flex items-center justify-between bg-slate-950 p-4 rounded-xl border border-slate-700 mb-4">
        {mode === 'plate' ? (
          <svg viewBox="0 0 140 140" className="w-32 h-32">
            <circle cx="70" cy="70" r="56" fill="none" stroke="#334155" strokeWidth="2" />
            <g transform={`rotate(${rotation}, 70, 70)`}>
              {jointType === 'butt' ? (
                <>
                  <rect x="32" y="65" width="76" height="10" fill="#64748b" rx="2" />
                  <circle cx="70" cy="63" r="6" fill="#f59e0b" />
                </>
              ) : (
                <>
                  <rect x="35" y="70" width="70" height="8" fill="#64748b" />
                  <rect x="66" y="36" width="8" height="34" fill="#64748b" />
                  <polygon points="74,70 74,56 88,70" fill="#f59e0b" />
                </>
              )}
              <line x1="70" y1="24" x2="70" y2="50" stroke="#22c55e" strokeWidth="3" />
              <polygon points="70,53 65,44 75,44" fill="#22c55e" />
            </g>
          </svg>
        ) : (
          <svg viewBox="0 0 140 140" className="w-32 h-32">
            <line x1="15" y1="120" x2="125" y2="120" stroke="#475569" strokeWidth="2" />
            <g transform={`rotate(${-pipeAngle}, 70, 75)`}>
              <rect x="20" y="65" width="100" height="20" fill="#38bdf8" rx="3" />
              <line x1="70" y1="62" x2="70" y2="88" stroke="#f59e0b" strokeWidth="5" />
            </g>
            <text x="15" y="25" fill="#22c55e" fontSize="11" fontWeight="bold">L = {pipeAngle}°</text>
          </svg>
        )}

        <div className="text-right">
          <div className="text-2xl sm:text-3xl font-black text-amber-400">{pos.code}</div>
          <div className="text-xs text-sky-400 font-bold">AWS/ASME: {pos.aws}</div>
          <div className="text-xs text-slate-300 mt-1">{pos.desc}</div>
        </div>
      </div>

      {mode === 'plate' ? (
        <div className="space-y-3 text-xs">
          <div>
            <div className="flex justify-between mb-1">
              <span>{T.rotLbl}</span>
              <span className="text-amber-400 font-bold">{rotation}°</span>
            </div>
            <input type="range" min="0" max="180" value={rotation} onChange={(e) => setRotation(Number(e.target.value))} className="w-full accent-amber-500" />
          </div>
          <div>
            <div className="flex justify-between mb-1">
              <span>{T.slopeLbl}</span>
              <span className="text-sky-400 font-bold">{slope}°</span>
            </div>
            <input type="range" min="0" max="90" value={slope} onChange={(e) => setSlope(Number(e.target.value))} className="w-full accent-sky-500" />
          </div>
          <div className="flex gap-2">
            <button onClick={() => setDirection('up')} className={`flex-1 py-1.5 rounded-lg font-bold ${direction === 'up' ? 'bg-green-700 text-white' : 'bg-slate-700'}`}>{T.upPlate}</button>
            <button onClick={() => setDirection('down')} className={`flex-1 py-1.5 rounded-lg font-bold ${direction === 'down' ? 'bg-amber-700 text-white' : 'bg-slate-700'}`}>{T.downPlate}</button>
          </div>
        </div>
      ) : (
        <div className="space-y-3 text-xs">
          <div>
            <div className="flex justify-between mb-1">
              <span>{T.pipeLbl}</span>
              <span className="text-amber-400 font-bold">{pipeAngle}°</span>
            </div>
            <input type="range" min="0" max="90" step="15" value={pipeAngle} onChange={(e) => setPipeAngle(Number(e.target.value))} className="w-full accent-amber-500" />
          </div>
          <div className="flex gap-2">
            <button onClick={() => setDirection('up')} className={`flex-1 py-1.5 rounded-lg font-bold ${direction === 'up' ? 'bg-green-700 text-white' : 'bg-slate-700'}`}>{T.upPipe}</button>
            <button onClick={() => setDirection('down')} className={`flex-1 py-1.5 rounded-lg font-bold ${direction === 'down' ? 'bg-amber-700 text-white' : 'bg-slate-700'}`}>{T.downPipe}</button>
          </div>
        </div>
      )}
    </div>
  );
}
