export const iso2553Topics = [
  {
    "id": "2553-terms",
    "pdfPage": 6,
    "title": {
      "uz": "1. Barcha atamalar va ta'riflar (3.1 – 3.23) — 15 ta test",
      "ru": "1. Все термины и определения (3.1 – 3.23) — 15 тестов",
      "en": "1. Terms & Definitions (3.1 – 3.23) — 15 Questions"
    },
    "theory": {
      "uz": "ISO 2553:2019 3-boʻlimidagi barcha 23 ta atama:\n• 3.1 welding symbol — payvandlash shartli belgisi.\n• 3.2 basic welding symbol — asosiy shartli belgi (strelka + tokcha + dum, chok turi koʻrsatilmagan).\n• 3.3 arrow line — strelka chizigʻi (135°).\n• 3.4 reference line — tokcha chizigʻi.\n• 3.5 tail — «хвост» (V-simon dum).\n• 3.6 arrow side / 3.7 other side — strelka tomoni / teskari tomon.\n• 3.8 elementary symbol / 3.9 supplementary symbol — boshlangʻich belgi / qoʻshimcha belgi.\n• 3.10 complementary information — «хвост» ichiga yoziladigan qoʻshimcha ma'lumot.\n• 3.11 intermittent weld — uzuq chok; 3.11.1 chain — zanjirsimon; 3.11.2 staggered — shaxmat.\n• 3.12 offset — siljish (shaxmat chokda ikki tomon boshlanish nuqtalari orasidagi masofa).\n• 3.13 back run — ildiz tomonidan oxirgi qoʻyiladigan valik; 3.14 backing weld — taglik choki.\n• 3.15 nominal weld length — chokning hisobiy uzunligi; 3.15.1 — har bir uchastka uzunligi.\n• 3.16 nominal throat thickness (a) — burchakli chok ichiga chizilgan teng yonli uchburchak balandligi.\n• 3.17 leg length (z) — burchakli chok kateti.\n• 3.18 penetration depth — erish chuqurligi (qavariqlikni hisobga olmaganda).\n• 3.19 deep penetration throat thickness (s) — chuqur eritishli burchakli chok qalinligi.\n• 3.20 flare-bevel weld — bir tomoni yumaloq va tekis detal orasidagi chok.\n• 3.21 flare-V weld — ikkita yumaloq detal orasidagi chok.\n• 3.22 field weld — montaj choki; 3.23 stake weld — ustunsimon (lazer/elektron nurli) chok.",
      "ru": "Все 23 термина стандарта ГОСТ Р ИСО 2553-2022 (раздел 3):\n• 3.1 welding symbol — условное обозначение сварного соединения.\n• 3.2 basic welding symbol — основное условное обозначение.\n• 3.3 arrow line — линия стрелки (135°).\n• 3.4 reference line — линия полки.\n• 3.5 tail — «хвост».\n• 3.6 arrow side / 3.7 other side — сторона стрелки / обратная сторона.\n• 3.8 elementary symbol / 3.9 supplementary symbol — начальное / вспомогательное обозначение.\n• 3.10 complementary information — дополнительная информация.\n• 3.11 intermittent weld — прерывистый шов (3.11.1 цепной, 3.11.2 шахматный).\n• 3.12 offset — смещение.\n• 3.13 back run — подварочный валик / 3.14 backing weld — подварочный шов.\n• 3.15 nominal weld length — номинальная длина шва.\n• 3.16 nominal throat thickness (a) — номинальная толщина углового шва.\n• 3.17 leg length (z) — катет углового шва.\n• 3.18 penetration depth — толщина проплавления.\n• 3.19 deep penetration throat thickness (s) — толщина с глубоким проплавлением.\n• 3.20 flare-bevel weld / 3.21 flare-V weld.\n• 3.22 field weld — монтажный шов / 3.23 stake weld — столбчатый шов.",
      "en": "All 23 Terms & Definitions in ISO 2553:2019 Section 3:\n• 3.1 welding symbol | 3.2 basic welding symbol | 3.3 arrow line (135°) | 3.4 reference line | 3.5 tail.\n• 3.6 arrow side | 3.7 other side | 3.8 elementary symbol | 3.9 supplementary symbol | 3.10 complementary information.\n• 3.11 intermittent weld | 3.11.1 chain intermittent weld | 3.11.2 staggered intermittent weld | 3.12 offset.\n• 3.13 back run | 3.14 backing weld | 3.15 nominal weld length | 3.15.1 nominal length of weld elements.\n• 3.16 nominal throat thickness (a) | 3.17 leg length (z) | 3.18 penetration depth / deposit thickness | 3.19 deep penetration throat thickness (s).\n• 3.20 flare-bevel weld | 3.21 flare-V weld | 3.22 field weld | 3.23 stake weld."
    },
    "items": [
      {
        "name": {
          "uz": "Nominal qalinlik 'a', Katet 'z' va Chuqur eritish 's'",
          "ru": "Толщина 'a', катет 'z' и глубокое проплавление 's'",
          "en": "Throat thickness 'a', Leg length 'z' & Deep penetration 's'"
        },
        "desc": {
          "uz": "3.16, 3.17 va 3.19-atamalar",
          "ru": "Термины 3.16, 3.17 и 3.19",
          "en": "Clauses 3.16, 3.17, 3.19"
        },
        "symbolSvg": "<svg viewBox=\"0 0 240 80\"><line x1=\"15\" y1=\"52\" x2=\"225\" y2=\"52\" stroke=\"#38bdf8\" stroke-width=\"2\"/><text x=\"52\" y=\"42\" fill=\"#22c55e\" font-size=\"14\" font-weight=\"bold\">sa6</text><polygon points=\"58,52 58,26 84,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><text x=\"148\" y=\"42\" fill=\"#38bdf8\" font-size=\"14\" font-weight=\"bold\">z8</text><polygon points=\"154,52 154,26 180,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 240 80\"><rect x=\"30\" y=\"62\" width=\"180\" height=\"12\" fill=\"#475569\"/><rect x=\"85\" y=\"10\" width=\"14\" height=\"52\" fill=\"#64748b\"/><polygon points=\"99,62 99,24 137,62\" fill=\"#f59e0b\" opacity=\"0.8\"/><path d=\"M99,62 L89,68 L99,45 Z\" fill=\"#ef4444\"/><line x1=\"99\" y1=\"62\" x2=\"118\" y2=\"43\" stroke=\"#22c55e\" stroke-width=\"2.5\"/><text x=\"122\" y=\"38\" fill=\"#22c55e\" font-size=\"11\" font-weight=\"bold\">a</text><text x=\"72\" y=\"56\" fill=\"#ef4444\" font-size=\"11\" font-weight=\"bold\">s</text><text x=\"112\" y=\"73\" fill=\"#38bdf8\" font-size=\"11\" font-weight=\"bold\">z</text></svg>"
      }
    ],
    "quiz": [
      {
        "question": {
          "uz": "3.2-atama 'basic welding symbol' (основное условное обозначение) qaysi elementlardan iborat?",
          "ru": "Из каких элементов состоит 'основное условное обозначение' (basic welding symbol, п. 3.2)?",
          "en": "Which elements constitute a 'basic welding symbol' (Clause 3.2)?"
        },
        "options": [
          {
            "uz": "Strelka chizigʻi, tokcha chizigʻi va «хвост» (chok turi koʻrsatilmaydi)",
            "ru": "Линия стрелки, линия полки и «хвост» (тип шва не определен)",
            "en": "Arrow line, reference line, and tail (used when joint details are not specified)"
          },
          {
            "uz": "Faqat uchburchak va oʻlcham",
            "ru": "Только треугольник и размер",
            "en": "Only triangle and size"
          },
          {
            "uz": "Strelka va bayroqcha",
            "ru": "Стрелка и флажок",
            "en": "Arrow and flag"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.2-band: Chok turi aniq belgilanmagan (masalan, prixvatkalar uchun) belgi.",
          "ru": "Пункт 3.2: Линия стрелки, линия полки и «хвост».",
          "en": "Clause 3.2: Arrow line, reference line, and tail."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.3-atama 'arrow line' (линия стрелки) tokcha chizigʻiga odatda necha gradus burchak ostida chiziladi?",
          "ru": "Под каким углом к линии полки обычно вычерчивается линия стрелки (п. 3.3)?",
          "en": "At what angle to the reference line is the arrow line generally drawn (Clause 3.3)?"
        },
        "options": [
          {
            "uz": "135°",
            "ru": "135°",
            "en": "135°"
          },
          {
            "uz": "90°",
            "ru": "90°",
            "en": "90°"
          },
          {
            "uz": "30°",
            "ru": "30°",
            "en": "30°"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.3-band: Odatda 135° burchak ostida chiziladi.",
          "ru": "Пункт 3.3: Обычно под углом 135° к линии полки.",
          "en": "Clause 3.3: Generally drawn at 135° to the reference line."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.5-atama 'tail' («хвост») qanday shaklga ega va qayerda joylashadi?",
          "ru": "Какую форму имеет «хвост» (tail, п. 3.5) и где он располагается?",
          "en": "What shape is the 'tail' (Clause 3.5) and where is it added?"
        },
        "options": [
          {
            "uz": "V-simon element boʻlib, tokcha chizigʻining strelkaga qarama-qarshi uchiga qoʻshiladi",
            "ru": "V-образный элемент на конце линии полки, противоположном линии стрелки",
            "en": "V-shaped element added at the end of the reference line opposite the arrow line"
          },
          {
            "uz": "Aylana shaklida oʻrtada",
            "ru": "Круг в центре полки",
            "en": "Circle at the center"
          },
          {
            "uz": "Kvadrat shaklida strelka uchida",
            "ru": "Квадрат на острие стрелки",
            "en": "Square at arrow tip"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.5-band: Tokcha chizigʻining strelkaga qarama-qarshi uchidagi V-simon element.",
          "ru": "Пункт 3.5: V-образный элемент на конце полки.",
          "en": "Clause 3.5: V-shaped element at the end of the reference line opposite the arrow line."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.10-atama 'complementary information' (дополнительная информация) nimani bildiradi?",
          "ru": "Что такое 'дополнительная информация' (complementary information, п. 3.10)?",
          "en": "What is 'complementary information' (Clause 3.10)?"
        },
        "options": [
          {
            "uz": "«Хвост» ichiga yoziladigan, shartli belgilardan iborat boʻlmagan matnli texnologik ma'lumotlar",
            "ru": "Информация, не содержащая обозначений и относящаяся к выполнению швов, включаемая в «хвост»",
            "en": "Non-symbolic information relevant to making the welds that may be included in the tail"
          },
          {
            "uz": "Boshlangʻich chok belgisi",
            "ru": "Начальное обозначение шва",
            "en": "Elementary weld symbol"
          },
          {
            "uz": "Chok kateti",
            "ru": "Катет шва",
            "en": "Leg length"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.10-band: Masalan, ISO 4063-141, ISO 5817-B kabi matnli ma'lumotlar.",
          "ru": "Пункт 3.10: Информация без символов, включаемая в «хвост».",
          "en": "Clause 3.10: Non-symbolic info included in the tail."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.11.1 'chain intermittent weld' (цепной прерывистый шов) qanday tuzilgan?",
          "ru": "Как устроен 'цепной прерывистый шов' (chain intermittent weld, п. 3.11.1)?",
          "en": "What defines a 'chain intermittent weld' (Clause 3.11.1)?"
        },
        "options": [
          {
            "uz": "Ikki tomonlama uzuq chokda payvandlangan uchastkalar bir-biriga QARAMA-QARSHI joylashadi",
            "ru": "Двусторонний прерывистый шов, у которого заваренные участки с обеих сторон расположены друг против друга",
            "en": "Double-sided intermittent weld with weld elements opposite each other on both sides"
          },
          {
            "uz": "Bir tomondagi chok ikkinchi tomondagi boʻshliq qarshisida turadi",
            "ru": "Участки одной стороны напротив пробелов другой",
            "en": "Weld elements opposite unwelded spaces"
          },
          {
            "uz": "Faqat bir tomonda bajariladi",
            "ru": "Выполняется с одной стороны",
            "en": "Single-sided intermittent weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.11.1-band: Zanjirsimon uzuq chok.",
          "ru": "Пункт 3.11.1: Цепной прерывистый шов.",
          "en": "Clause 3.11.1: Chain intermittent weld."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.11.2 'staggered intermittent weld' (шахматный прерывистый шов) qanday joylashadi?",
          "ru": "Как располагаются участки 'шахматного прерывистого шва' (staggered intermittent weld, п. 3.11.2)?",
          "en": "How are weld elements placed in a 'staggered intermittent weld' (Clause 3.11.2)?"
        },
        "options": [
          {
            "uz": "Bir tomondagi payvandlangan uchastkalar ikkinchi tomondagi PAYVANDLANMAGAN boʻshliqlar qarshisida turadi",
            "ru": "Заваренные с одной стороны участки находятся напротив незаваренных участков с обратной стороны",
            "en": "Weld elements on one side are opposite unwelded spaces on the other side"
          },
          {
            "uz": "Ikkala tomonda bir-birining ustida turadi",
            "ru": "Строго друг напротив друга",
            "en": "Strictly opposite each other"
          },
          {
            "uz": "Uzluksiz bir tekis ketadi",
            "ru": "Сплошной шов",
            "en": "Continuous weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.11.2-band: Shaxmat tartibidagi uzuq chok (Z).",
          "ru": "Пункт 3.11.2: Шахматный прерывистый шов.",
          "en": "Clause 3.11.2: Staggered intermittent weld."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.12-atama 'offset' (смещение) nimani oʻlchaydi?",
          "ru": "Что такое 'смещение' (offset, п. 3.12)?",
          "en": "What is 'offset' (Clause 3.12)?"
        },
        "options": [
          {
            "uz": "Shaxmat uzuq chokning old tomonidagi payvandlash boshlanishi bilan orqa tomonidagi boshlanish orasidagi masofa",
            "ru": "Расстояние между началом сварки на лицевой стороне шахматного шва и началом на обратной стороне",
            "en": "Distance between start of welding on arrow side and other side of a staggered intermittent weld"
          },
          {
            "uz": "Chokning kengligi",
            "ru": "Ширина шва",
            "en": "Width of weld"
          },
          {
            "uz": "Qirralar orasidagi zazor",
            "ru": "Зазор между кромками",
            "en": "Root gap"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.12-band: Offset.",
          "ru": "Пункт 3.12: Смещение.",
          "en": "Clause 3.12: Offset."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.13 'back run' (подварочный валик) va 3.14 'backing weld' (подварочный шов) nimasi bilan farq qiladi?",
          "ru": "В чем отличие 'подварочного валика' (back run, п. 3.13) от 'подварочного шва' (backing weld, п. 3.14)?",
          "en": "How is 'back run' (3.13) defined compared to 'backing weld' (3.14)?"
        },
        "options": [
          {
            "uz": "Back run — eritib payvandlash chokining ildiz tomonidan OXIRGI boʻlib qoʻyiladigan valik; Backing weld — chok koʻrinishidagi taglik",
            "ru": "Back run — последний валик со стороны корня; Backing weld — подварка в виде сварного шва",
            "en": "Back run = final run deposited on root side; Backing weld = backing in the form of a weld"
          },
          {
            "uz": "Ikkalasi ham gaz bilan kesish usuli",
            "ru": "Оба — способы газовой резки",
            "en": "Both are gas cutting methods"
          },
          {
            "uz": "Farqi yoʻq",
            "ru": "Разницы нет",
            "en": "No difference"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.13 va 3.14-bandlar.",
          "ru": "Пункты 3.13 и 3.14.",
          "en": "Clauses 3.13 & 3.14."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.15 'nominal weld length' (номинальная длина сварного шва) nimani bildiradi?",
          "ru": "Что такое 'номинальная длина сварного шва' (nominal weld length, п. 3.15)?",
          "en": "What is 'nominal weld length' (Clause 3.15)?"
        },
        "options": [
          {
            "uz": "Chok nominal oʻlchamga ega boʻlgan hisobiy uzunlik",
            "ru": "Расчетная длина сварного шва, на которой он имеет номинальный размер",
            "en": "Design length of the weld over which it has its nominal size"
          },
          {
            "uz": "Detalning umumiy uzunligi",
            "ru": "Общая длина детали",
            "en": "Total plate length"
          },
          {
            "uz": "Elektrod uzunligi",
            "ru": "Длина электрода",
            "en": "Electrode length"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.15-band.",
          "ru": "Пункт 3.15.",
          "en": "Clause 3.15."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.16 'nominal throat thickness (a)' qanday geometrik kattalik?",
          "ru": "Что такое 'номинальная толщина углового шва a' (nominal throat thickness, п. 3.16)?",
          "en": "What is 'nominal throat thickness (a)' (Clause 3.16)?"
        },
        "options": [
          {
            "uz": "Burchakli chok kesimi ichiga chizilgan eng katta teng yonli uchburchak balandligi",
            "ru": "Высота наибольшего равнобедренного треугольника, вписанного в сечение углового шва",
            "en": "Design height of the largest isosceles triangle inscribed in the fillet weld section"
          },
          {
            "uz": "Burchakli chok kateti",
            "ru": "Катет углового шва",
            "en": "Leg length of fillet weld"
          },
          {
            "uz": "Chok qavariqligi",
            "ru": "Выпуклость шва",
            "en": "Weld reinforcement"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.16-band.",
          "ru": "Пункт 3.16.",
          "en": "Clause 3.16."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.17 'leg length (z)' qanday aniqlanadi?",
          "ru": "Как определяется 'катет углового шва z' (leg length, п. 3.17)?",
          "en": "How is 'leg length (z)' defined (Clause 3.17)?"
        },
        "options": [
          {
            "uz": "Eritiladigan yuzalar kesishmasidan chok chegarasigacha (toe) boʻlgan masofa",
            "ru": "Расстояние от пересечения расплавляемых поверхностей до границы шва",
            "en": "Distance from actual or projected intersection of fusion faces to toe of fillet weld"
          },
          {
            "uz": "Chok ichidagi uchburchak balandligi",
            "ru": "Высота вписанного треугольника",
            "en": "Inscribed triangle height"
          },
          {
            "uz": "Tirqish kengligi",
            "ru": "Ширина зазора",
            "en": "Gap width"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.17-band.",
          "ru": "Пункт 3.17.",
          "en": "Clause 3.17."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.18 'penetration depth' (толщина проплавления) oʻlchanganda nimani chiqarib tashlaymiz?",
          "ru": "Что исключается при определении 'толщины проплавления' (penetration depth, п. 3.18)?",
          "en": "What is excluded from 'penetration depth / deposit thickness' (Clause 3.18)?"
        },
        "options": [
          {
            "uz": "Har qanday tashqi qavariqlikni (reinforcement / выпуклость)",
            "ru": "Любую выпуклость металла шва",
            "en": "Any reinforcement / convexity"
          },
          {
            "uz": "Ildiz qismini",
            "ru": "Корневой проход",
            "en": "Root penetration"
          },
          {
            "uz": "Asosiy metallni",
            "ru": "Основной металл",
            "en": "Parent metal"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.18-band.",
          "ru": "Пункт 3.18.",
          "en": "Clause 3.18."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.19 'deep penetration throat thickness (s)' nimani anglatadi?",
          "ru": "Что означает 'толщина углового шва с глубоким проплавлением s' (п. 3.19)?",
          "en": "What does 'deep penetration throat thickness (s)' mean (Clause 3.19)?"
        },
        "options": [
          {
            "uz": "Nominal yoki samarali chok qalinligi 'a' ga chuqur erish qiymati qoʻshilgan qalinlik",
            "ru": "Номинальная/эффективная толщина углового шва с добавлением величины глубины проплавления",
            "en": "Nominal or effective throat thickness plus a certain amount of fusion penetration"
          },
          {
            "uz": "Faqat qirra kesish chuqurligi",
            "ru": "Только глубина разделки",
            "en": "Preparation depth only"
          },
          {
            "uz": "Chok kengligi",
            "ru": "Ширина шва",
            "en": "Weld width"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.19-band.",
          "ru": "Пункт 3.19.",
          "en": "Clause 3.19."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.20 'flare-bevel weld' va 3.21 'flare-V weld' qanday detallarni ulaydi?",
          "ru": "Какие детали соединяют швы 'flare-bevel' (п. 3.20) и 'flare-V' (п. 3.21)?",
          "en": "Which members are joined by 'flare-bevel' (3.20) and 'flare-V' (3.21) welds?"
        },
        "options": [
          {
            "uz": "flare-bevel: yumaloq + tekis detal; flare-V: ikkita yumaloq detal",
            "ru": "flare-bevel: закругленная + плоская; flare-V: две закругленные детали",
            "en": "flare-bevel: one round + one flat member; flare-V: two round members"
          },
          {
            "uz": "Ikkalasi ham tekis listlarni ulaydi",
            "ru": "Оба соединяют плоские листы",
            "en": "Both join flat plates"
          },
          {
            "uz": "Ikkalasi ham quvur uchlarini ulaydi",
            "ru": "Оба соединяют торцы труб",
            "en": "Both join pipe ends"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.20 va 3.21-bandlar.",
          "ru": "Пункты 3.20 и 3.21.",
          "en": "Clauses 3.20 & 3.21."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3.22 'field weld' va 3.23 'stake weld' atamalari nimani anglatadi?",
          "ru": "Что означают термины 'field weld' (п. 3.22) и 'stake weld' (п. 3.23)?",
          "en": "What do 'field weld' (3.22) and 'stake weld' (3.23) mean?"
        },
        "options": [
          {
            "uz": "field weld — sex tashqarisida montajda bajariladigan chok; stake weld — lazer/elektron nurli ustunsimon chok",
            "ru": "field weld — монтажный шов вне цеха; stake weld — столбчатый шов (лазер/электронный луч)",
            "en": "field weld = weld made outside workshop at site; stake weld = laser/electron beam tee-joint weld"
          },
          {
            "uz": "Ikkalasi ham kontakt payvandlash",
            "ru": "Оба — контактная сварка",
            "en": "Both are resistance welds"
          },
          {
            "uz": "field weld — avtomat chok, stake — qoʻlda",
            "ru": "field — автомат, stake — ручной",
            "en": "field = automatic, stake = manual"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.22 va 3.23-bandlar.",
          "ru": "Пункты 3.22 и 3.23.",
          "en": "Clauses 3.22 & 3.23."
        },
        "svg": null
      }
    ]
  },
  {
    "id": "2553-sys",
    "pdfPage": 19,
    "title": {
      "uz": "2. A va B tizimlari, Strelka, Tokcha va «Хвост» (4.1–4.3, 4.6–4.8) — 12 ta test",
      "ru": "2. Системы А и В, Стрелка, Полка и «Хвост» (4.1–4.3, 4.6–4.8) — 12 тестов",
      "en": "2. Systems A & B, Arrow Line, Reference Line & Tail — 12 Questions"
    },
    "theory": {
      "uz": "• A tizimi (System A — ikkitali tokcha): Tutash (sposhnoy) chiziq = strelka tomoni (arrow side); Shtrix (uzuk-uzuk) chiziq = teskari tomon (other side). Simmetrik ikki tomonlama choklarda shtrix chiziq oʻchiriladi.\n• B tizimi (System B — bittalik tokcha): Tokcha chizigʻi OSTIDA = strelka tomoni; USTIDA = teskari tomon.\n• 4.6.2 Bir nechta strelka: Bir xil (identik) choklarni koʻrsatish uchun bitta tokchaga bir nechta strelka ulash mumkin.\n• 4.6.3 Siniq strelka (Broken arrow line): T-simon birikmalardan tashqari, aynan qaysi detal qirrasini kesish kerakligini koʻrsatish uchun sinib oʻsha detalga qaratiladi.\n• 4.7.2.2 Tutashgan yuzadagi choklar (plug, slot, spot, seam): Belgi tokcha oʻrtasiga qoʻyiladi.\n• 4.7.3 Bir nechta tokcha chiziqlari: Strelkaga eng yaqin tokcha — 1-operatsiya, keyingilari — 2- va 3-operatsiyalar. Ajratgich (spacer) belgisi strelkaga eng yaqin tokchaga qoʻyiladi.\n• 4.8 «Хвост»: Ochiq dumda ma'lumotlar '/' bilan ajratiladi; yopiq dum faqat WPS/WPQR hujjatiga havola uchun ishlatiladi.",
      "ru": "• Система А (двойная линия полки): сплошная — сторона стрелки; штриховая — обратная сторона. Для симметричных швов штриховая линия удаляется.\n• Система В (одинарная линия полки): под линией полки — сторона стрелки; над линией полки — обратная сторона.\n• Несколько линий стрелки (п. 4.6.2) — для идентичных швов.\n• Ломаная линия стрелки (п. 4.6.3) — указывает на конкретный элемент, подлежащий разделке (кроме Т-образных соединений).\n• Несколько линий полки (п. 4.7.3) — первая операция на ближайшей к стрелке полке.\n• «Хвост» (п. 4.8) — открытый (через '/') и закрытый (ссылка на WPS/WPQR).",
      "en": "• System A (dual reference line): solid line = arrow side; dashed line = other side. Dashed line is omitted for symmetrical double-sided welds.\n• System B (single reference line): below reference line = arrow side; above = other side.\n• Multiple arrow lines (4.6.2) — combined with one reference line for identical welds.\n• Broken arrow line (4.6.3) — points to specific member to be prepared (excluding T-joints).\n• Multiple reference lines (4.7.3) — line closest to arrow = 1st operation.\n• Tail (4.8) — open tail separates info with '/'; closed tail is ONLY for reference to a specific instruction (WPS/WPQR)."
    },
    "items": [
      {
        "name": {
          "uz": "A tizimi vs B tizimi (5-jadval)",
          "ru": "Система А vs Система В (Таблица 5)",
          "en": "System A vs System B (Table 5)"
        },
        "desc": {
          "uz": "Strelka tomoni va teskari tomon joylashuvi",
          "ru": "Сторона стрелки и обратная сторона",
          "en": "Arrow side and other side representation"
        },
        "symbolSvg": "<svg viewBox=\"0 0 240 90\"><line x1=\"15\" y1=\"70\" x2=\"50\" y2=\"32\" stroke=\"#38bdf8\" stroke-width=\"2\"/><line x1=\"50\" y1=\"32\" x2=\"115\" y2=\"32\" stroke=\"#38bdf8\" stroke-width=\"2\"/><line x1=\"50\" y1=\"40\" x2=\"115\" y2=\"40\" stroke=\"#38bdf8\" stroke-width=\"1.8\" stroke-dasharray=\"5,3\"/><polygon points=\"75,32 75,16 91,32\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2\"/><text x=\"50\" y=\"84\" fill=\"#22c55e\" font-size=\"10\">System A</text><line x1=\"130\" y1=\"70\" x2=\"165\" y2=\"36\" stroke=\"#38bdf8\" stroke-width=\"2\"/><line x1=\"165\" y1=\"36\" x2=\"230\" y2=\"36\" stroke=\"#38bdf8\" stroke-width=\"2\"/><polygon points=\"188,36 188,52 204,36\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2\"/><text x=\"165\" y=\"84\" fill=\"#22c55e\" font-size=\"10\">System B</text></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 240 90\"><rect x=\"30\" y=\"65\" width=\"180\" height=\"14\" fill=\"#475569\"/><rect x=\"112\" y=\"15\" width=\"16\" height=\"50\" fill=\"#64748b\"/><polygon points=\"92,65 112,65 112,45\" fill=\"#22c55e\"/><text x=\"42\" y=\"55\" fill=\"#38bdf8\" font-size=\"11\">← Arrow side</text></svg>"
      }
    ],
    "quiz": [
      {
        "question": {
          "uz": "A tizimida belgi shtrix chiziqda tursa, chok qayerda bajariladi?",
          "ru": "Где выполняется шов в системе А, если символ на штриховой линии?",
          "en": "In System A, where is the weld made when the symbol is on the dashed line?"
        },
        "options": [
          {
            "uz": "Teskari tomonda (other side)",
            "ru": "На обратной стороне (other side)",
            "en": "On the other side"
          },
          {
            "uz": "Strelka tomonida (arrow side)",
            "ru": "На стороне стрелки",
            "en": "On the arrow side"
          },
          {
            "uz": "Ikkala tomonda",
            "ru": "С обеих сторон",
            "en": "On both sides"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.7.2.1A: Shtrix chiziq = other side.",
          "ru": "Пункт 4.7.2.1А: На штриховой — обратная сторона.",
          "en": "Clause 4.7.2.1A: Dashed line = other side."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"60\" x2=\"55\" y2=\"25\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"55\" y1=\"25\" x2=\"170\" y2=\"25\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"55\" y1=\"33\" x2=\"170\" y2=\"33\" stroke=\"#38bdf8\" stroke-width=\"2\" stroke-dasharray=\"6,3\"/><polygon points=\"95,33 95,50 112,33\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/></svg>"
      },
      {
        "question": {
          "uz": "B tizimida belgi tokcha chizigʻi OSTIDA tursa, chok qaysi tomonda bajariladi?",
          "ru": "Где выполняется шов в системе В, если символ ПОД линией полки?",
          "en": "In System B, where is the weld made when the symbol is BELOW the reference line?"
        },
        "options": [
          {
            "uz": "Strelka tomonida (arrow side)",
            "ru": "На стороне стрелки (arrow side)",
            "en": "On the arrow side"
          },
          {
            "uz": "Teskari tomonda (other side)",
            "ru": "На обратной стороне",
            "en": "On the other side"
          },
          {
            "uz": "Quvur ichida",
            "ru": "Внутри трубы",
            "en": "Inside pipe"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.7.2.1B: Ostida = arrow side.",
          "ru": "Пункт 4.7.2.1В: Под полкой — сторона стрелки.",
          "en": "Clause 4.7.2.1B: Below reference line = arrow side."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"60\" x2=\"55\" y2=\"28\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"55\" y1=\"28\" x2=\"170\" y2=\"28\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><polygon points=\"95,28 95,46 113,28\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/></svg>"
      },
      {
        "question": {
          "uz": "B tizimida belgi tokcha chizigʻi USTIDA tursa, chok qaysi tomonda bajariladi?",
          "ru": "Где выполняется шов в системе В, если символ НАД линией полки?",
          "en": "In System B, where is the weld made when the symbol is ABOVE the reference line?"
        },
        "options": [
          {
            "uz": "Teskari tomonda (other side)",
            "ru": "На обратной стороне (other side)",
            "en": "On the other side"
          },
          {
            "uz": "Strelka tomonida (arrow side)",
            "ru": "На стороне стрелки",
            "en": "On the arrow side"
          },
          {
            "uz": "Faqat prixvatka",
            "ru": "Только прихватка",
            "en": "Tack weld only"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.7.2.1B: Ustida = other side.",
          "ru": "Пункт 4.7.2.1В: Над полкой — обратная сторона.",
          "en": "Clause 4.7.2.1B: Above reference line = other side."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Simmetrik ikki tomonlama choklarda A tizimining shtrix chizigʻi nima qilinadi (4.4.3)?",
          "ru": "Что делают со штриховой линией в системе А при симметричных двусторонних швах (п. 4.4.3)?",
          "en": "What happens to the dashed line in System A for symmetrical double-sided welds (4.4.3)?"
        },
        "options": [
          {
            "uz": "Olib tashlanadi (chizilmaydi)",
            "ru": "Удаляют (не проводят)",
            "en": "It is omitted / removed"
          },
          {
            "uz": "Ikkita shtrix chiziq chiziladi",
            "ru": "Рисуют две штриховые линии",
            "en": "Two dashed lines are drawn"
          },
          {
            "uz": "Qalin qilib chiziladi",
            "ru": "Рисуют толстой линией",
            "en": "Drawn thick"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.4.3 va 4.7.1A: Simmetrik ikki tomonlama choklarda shtrix chiziq oʻchiriladi.",
          "ru": "Пункты 4.4.3 и 4.7.1А: Штриховую линию удаляют.",
          "en": "Clauses 4.4.3 & 4.7.1A: Dashed line is removed."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "4.6.3-bandga koʻra siniq strelka (broken arrow line) qaysi birikma turida qoʻllanilMAYDI?",
          "ru": "Для какого типа соединений НЕ применяется ломаная линия стрелки согласно п. 4.6.3?",
          "en": "Which joint type is excluded from using a broken arrow line in Clause 4.6.3?"
        },
        "options": [
          {
            "uz": "T-simon (tavr) birikmalarda",
            "ru": "В Т-образных соединениях",
            "en": "T-joints"
          },
          {
            "uz": "Listlarni uchma-uch ulashda",
            "ru": "При стыковой сварке листов",
            "en": "Butt welds in plates"
          },
          {
            "uz": "J-simon razdelkada",
            "ru": "При J-образной разделке",
            "en": "J-groove welds"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.6.3-band: T-simon birikmalar istisno qilingan.",
          "ru": "Пункт 4.6.3: За исключением Т-образных соединений.",
          "en": "Clause 4.6.3: Excluding T-joints."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Bir nechta tokcha chizigʻi (5-rasm) qoʻllanilganda 1-operatsiya qayerda koʻrsatiladi (4.7.3)?",
          "ru": "На какой линии полки указывается 1-я операция при нескольких полках (п. 4.7.3)?",
          "en": "Which reference line indicates the 1st operation when multiple reference lines are used (4.7.3)?"
        },
        "options": [
          {
            "uz": "Strelkaga eng yaqin tokchada",
            "ru": "На линии полки, ближайшей к стрелке",
            "en": "Reference line closest to the arrow"
          },
          {
            "uz": "Eng yuqori tokchada",
            "ru": "На самой верхней полке",
            "en": "Topmost reference line"
          },
          {
            "uz": "Dum ichida",
            "ru": "Внутри хвоста",
            "en": "Inside the tail"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.7.3-band: Strelkaga eng yaqin tokcha — birinchi operatsiya.",
          "ru": "Пункт 4.7.3: Ближайшая к стрелке полка.",
          "en": "Clause 4.7.3: Reference line closest to arrow."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Ajratgichli (spacer) birikmalarda ajratgich belgisi qaysi tokchaga qoʻyiladi (4.7.3)?",
          "ru": "На какой линии полки располагают обозначение разделителя (п. 4.7.3)?",
          "en": "On which reference line is the spacer symbol placed (4.7.3)?"
        },
        "options": [
          {
            "uz": "Strelkaga eng yaqin tokchaga",
            "ru": "На линии полки, ближайшей к стрелке",
            "en": "On the reference line closest to the arrow"
          },
          {
            "uz": "Eng oxirgi tokchaga",
            "ru": "На последней линии полки",
            "en": "On the last reference line"
          },
          {
            "uz": "Strelka uchiga",
            "ru": "На острие стрелки",
            "en": "On the arrow tip"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.7.3-band.",
          "ru": "Пункт 4.7.3.",
          "en": "Clause 4.7.3."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Yopiq «хвост» (closed tail) qachon ishlatiladi (4.8)?",
          "ru": "Когда применяют закрытый «хвост» (п. 4.8)?",
          "en": "When is a closed tail used (4.8)?"
        },
        "options": [
          {
            "uz": "Faqat aniq texnologik hujjatga (WPS, WPQR) havola koʻrsatish uchun",
            "ru": "Только для ссылки на конкретную инструкцию (WPS, WPQR)",
            "en": "Only to indicate reference to a specific instruction (WPS, WPQR)"
          },
          {
            "uz": "Jarayon kodini yozish uchun",
            "ru": "Для кода процесса",
            "en": "For process number"
          },
          {
            "uz": "Oʻlcham yozish uchun",
            "ru": "Для размеров",
            "en": "For dimensions"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.8-band.",
          "ru": "Пункт 4.8.",
          "en": "Clause 4.8."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "Ochiq «хвост» ichida sifat darajasi, payvandlash usuli va fazoviy holat qanday belgi bilan ajratiladi (4.8)?",
          "ru": "Каким знаком разделяют информацию в открытом «хвосте» (п. 4.8)?",
          "en": "Which character separates information items in an open tail (4.8)?"
        },
        "options": [
          {
            "uz": "Qiya chiziq «/» bilan",
            "ru": "Знаком «/»",
            "en": "Slash '/'"
          },
          {
            "uz": "Nuqta-vergul «;» bilan",
            "ru": "Точкой с запятой «;»",
            "en": "Semicolon ';'"
          },
          {
            "uz": "Chiziqcha «-» bilan",
            "ru": "Дефисом «-»",
            "en": "Hyphen '-'"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.8-band va 6a-rasm.",
          "ru": "Пункт 4.8 и рис. 6а).",
          "en": "Clause 4.8 & Fig. 6a."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "4.7.1-band izohiga koʻra chizmada joy yetishmasa tokcha chizigʻini necha gradus burish mumkin?",
          "ru": "На сколько градусов допускается повернуть условное обозначение при нехватке места (п. 4.7.1)?",
          "en": "By how many degrees may the welding symbol be rotated if space is limited (4.7.1 Note)?"
        },
        "options": [
          {
            "uz": "90° (oʻng chetga parallel qilib)",
            "ru": "90° (параллельно правому краю чертежа)",
            "en": "90° (parallel to right-hand edge)"
          },
          {
            "uz": "45°",
            "ru": "45°",
            "en": "45°"
          },
          {
            "uz": "180°",
            "ru": "180°",
            "en": "180°"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.7.1-band izohi.",
          "ru": "Примечание к п. 4.7.1.",
          "en": "Note to 4.7.1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "4.6.2-bandga koʻra bir nechta strelkani bitta tokchaga ulash qachon ruxsat etiladi?",
          "ru": "Когда допускается комбинировать несколько линий стрелки с одной линией полки (п. 4.6.2)?",
          "en": "When may multiple arrow lines be combined with a single reference line (4.6.2)?"
        },
        "options": [
          {
            "uz": "Bir xil (identik) choklarning joylashuvini koʻrsatish uchun",
            "ru": "Для указания расположения идентичных сварных швов",
            "en": "To indicate locations of identical welds"
          },
          {
            "uz": "Har xil chok turlarini birlashtirish uchun",
            "ru": "Для разных типов швов",
            "en": "For different weld types"
          },
          {
            "uz": "Hech qachon mumkin emas",
            "ru": "Никогда",
            "en": "Never"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.6.2-band va 4-rasm.",
          "ru": "Пункт 4.6.2 и рис. 4.",
          "en": "Clause 4.6.2 & Fig. 4."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "A va B tizimlarini bitta chizmada aralashtirib qoʻllash mumkinmi (4.3)?",
          "ru": "Допускается ли совмещать системы А и В на одном чертеже (п. 4.3)?",
          "en": "May Systems A and B be mixed on the same drawing (4.3)?"
        },
        "options": [
          {
            "uz": "Yoʻq, tizimlarni aralashtirish mumkin emas",
            "ru": "Нет, системы А и В не следует совмещать",
            "en": "No, Systems A and B shall not be mixed"
          },
          {
            "uz": "Ha, istalgan joyda",
            "ru": "Да, где угодно",
            "en": "Yes, anywhere"
          },
          {
            "uz": "Faqat Ilova A da",
            "ru": "Только в Приложении А",
            "en": "Only in Annex A"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.3-band.",
          "ru": "Пункт 4.3.",
          "en": "Clause 4.3."
        },
        "svg": null
      }
    ]
  },
  {
    "id": "2553-elem",
    "pdfPage": 9,
    "title": {
      "uz": "3. Barcha 22 xil boshlangʻich chok belgilari (1–2-jadvallar) — 22 ta test",
      "ru": "3. Все 22 начальных обозначения швов (Табл. 1–2) — 22 теста",
      "en": "3. All 22 Elementary Weld Symbols (Tables 1–2) — 22 Questions"
    },
    "theory": {
      "uz": "1-jadvaldagi barcha 22 ta boshlangʻich belgi (har biri alohida test qilingan):\n• №1: Square butt weld (||) — qirralari kesilmagan uchma-uch chok.\n• №2: Single-V butt weld (V) — bir tomonlama V-simon chok.\n• №3: Single-V butt weld with broad root face (Y) — toʻmtoqlangan V-simon chok.\n• №4: Single-bevel butt weld (|/) — bir qirrasi qiya kesilgan chok.\n• №5: Single-bevel butt weld with broad root face — toʻmtoqlangan 1/2 V chok.\n• №6: Single-U butt weld — U-simon chok.\n• №7: Single-J butt weld (P shakli) — J-simon chok.\n• №8: Flare-V weld — ikkita yumaloq detal orasidagi chok.\n• №9: Flare-bevel weld — yumaloq va tekis detal orasidagi chok.\n• №10: Fillet weld — burchakli chok.\n• №11: Plug / slot weld — teshikli / tirqishli chok.\n• №12.1: Resistance spot weld / №12.2: Projection weld.\n• №13: Fusion spot weld.\n• №14: Resistance seam weld / №15: Fusion seam weld.\n• №16: Stud weld — shpilka payvandlash.\n• №17: Steep-flanked single-V / №18: Steep-flanked single-bevel.\n• №19: Edge weld (Π) — qirra chok.\n• №20.1: Flange butt weld (八) / №20.2: Flange corner weld.\n• №21: Surfacing — qoplama eritish (naplavka).\n• №22: Stake weld — ustunsimon (lazer/elektron nurli) chok.",
      "ru": "Все 22 начальных обозначения (Таблица 1):\n• №1: Стыковой без скоса кромок | №2: V-образный | №3: Y (с притуплением)\n• №4: Со скосом одной кромки | №5: Со скосом одной кромки и притуплением\n• №6: U-образный | №7: J-образный\n• №8: Между двумя закругленными | №9: Между закругленной и плоской\n• №10: Угловой | №11: Пробочный\n• №12.1: Точечный контактный | №12.2: Рельефный | №13: Точечный плавлением\n• №14: Роликовый контактный | №15: Роликовый плавлением\n• №16: Приварка шпильки | №17–18: С крутой разделкой (в узкую разделку)\n• №19: Торцевой | №20.1: Стыковой с отбортовкой | №20.2: Угловой с отбортовкой\n• №21: Наплавка | №22: Столбчатый шов.",
      "en": "All 22 Elementary Weld Symbols in ISO 2553 Table 1:\n• №1: Square butt | №2: Single-V | №3: Single-V with broad root face (Y)\n• №4: Single-bevel | №5: Single-bevel with broad root face\n• №6: Single-U | №7: Single-J\n• №8: Flare-V | №9: Flare-bevel\n• №10: Fillet | №11: Plug / slot\n• №12.1: Resistance spot | №12.2: Projection | №13: Fusion spot\n• №14: Resistance seam | №15: Fusion seam\n• №16: Stud | №17: Steep-flanked single-V | №18: Steep-flanked single-bevel\n• №19: Edge | №20.1: Flange butt | №20.2: Flange corner\n• №21: Surfacing | №22: Stake weld."
    },
    "items": [
      {
        "name": {
          "uz": "№1 Square butt (||) va №3 Single-V broad root (Y)",
          "ru": "№1 Без скоса (||) и №3 С притуплением (Y)",
          "en": "№1 Square butt (||) & №3 Single-V broad root (Y)"
        },
        "desc": {
          "uz": "1-jadval",
          "ru": "Таблица 1",
          "en": "Table 1"
        },
        "symbolSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"50\" x2=\"180\" y2=\"50\" stroke=\"#64748b\" stroke-width=\"2\"/><line x1=\"94\" y1=\"22\" x2=\"94\" y2=\"50\" stroke=\"#f59e0b\" stroke-width=\"3\"/><line x1=\"106\" y1=\"22\" x2=\"106\" y2=\"50\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,20 L100,37 L116,20 M100,37 L100,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "name": {
          "uz": "№6 Single-U va №7 Single-J",
          "ru": "№6 U-образный и №7 J-образный",
          "en": "№6 Single-U & №7 Single-J"
        },
        "desc": {
          "uz": "1-jadval",
          "ru": "Таблица 1",
          "en": "Table 1"
        },
        "symbolSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M86,20 L86,32 A14,14 0 0,0 114,32 L114,20 M100,46 L100,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M90,20 L90,52 M90,38 C108,38 108,20 108,20\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "name": {
          "uz": "№8 Flare-V va №9 Flare-bevel",
          "ru": "№8 Между двумя закругл. и №9 Закругл.+плоская",
          "en": "№8 Flare-V & №9 Flare-bevel"
        },
        "desc": {
          "uz": "1-jadval",
          "ru": "Таблица 1",
          "en": "Table 1"
        },
        "symbolSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M82,22 C94,22 96,50 96,50 M118,22 C106,22 104,50 104,50\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M90,22 L90,52 M116,22 C102,22 98,50 98,50\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "name": {
          "uz": "№10 Fillet va №11 Plug/Slot",
          "ru": "№10 Угловой и №11 Пробочный",
          "en": "№10 Fillet & №11 Plug/Slot"
        },
        "desc": {
          "uz": "1-jadval",
          "ru": "Таблица 1",
          "en": "Table 1"
        },
        "symbolSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><polygon points=\"88,52 88,24 116,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><rect x=\"82\" y=\"28\" width=\"36\" height=\"24\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "name": {
          "uz": "№12.1 Spot (Resistance) va №14 Seam (Resistance)",
          "ru": "№12.1 Точечный и №14 Роликовый контактный",
          "en": "№12.1 Resistance Spot & №14 Resistance Seam"
        },
        "desc": {
          "uz": "1-jadval",
          "ru": "Таблица 1",
          "en": "Table 1"
        },
        "symbolSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"38\" x2=\"180\" y2=\"38\" stroke=\"#64748b\" stroke-width=\"2\"/><circle cx=\"100\" cy=\"38\" r=\"14\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"38\" x2=\"180\" y2=\"38\" stroke=\"#64748b\" stroke-width=\"2\"/><circle cx=\"100\" cy=\"38\" r=\"14\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><line x1=\"80\" y1=\"34\" x2=\"120\" y2=\"34\" stroke=\"#f59e0b\" stroke-width=\"2\"/><line x1=\"80\" y1=\"42\" x2=\"120\" y2=\"42\" stroke=\"#f59e0b\" stroke-width=\"2\"/></svg>"
      },
      {
        "name": {
          "uz": "№16 Stud, №19 Edge, №21 Surfacing, №22 Stake",
          "ru": "№16 Шпилька, №19 Торцевой, №21 Наплавка, №22 Столбчатый",
          "en": "№16 Stud, №19 Edge, №21 Surfacing, №22 Stake"
        },
        "desc": {
          "uz": "1-jadval",
          "ru": "Таблица 1",
          "en": "Table 1"
        },
        "symbolSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"54\" x2=\"180\" y2=\"54\" stroke=\"#64748b\" stroke-width=\"2\"/><circle cx=\"100\" cy=\"38\" r=\"13\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><line x1=\"100\" y1=\"25\" x2=\"100\" y2=\"54\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"50\" x2=\"180\" y2=\"50\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M74,50 A13,13 0 0,1 100,50 A13,13 0 0,1 126,50\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      }
    ],
    "quiz": [
      {
        "question": {
          "uz": "1. Rasmdagi belgi (1-jadval, №1) qaysi chok turini bildiradi?",
          "ru": "Какой тип шва обозначает данный символ (Таблица 1, №1)?",
          "en": "Identify this elementary symbol (Table 1, No. 1):"
        },
        "options": [
          {
            "uz": "Qirralari kesilmagan uchma-uch chok (Square butt weld)",
            "ru": "Стыковой шов без скоса кромок",
            "en": "Square butt weld"
          },
          {
            "uz": "Burchakli chok",
            "ru": "Угловой шов",
            "en": "Fillet weld"
          },
          {
            "uz": "Qirra chok",
            "ru": "Торцевой шов",
            "en": "Edge weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №1: Square butt weld.",
          "ru": "Таблица 1, №1.",
          "en": "Table 1, No. 1: Square butt weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"50\" x2=\"180\" y2=\"50\" stroke=\"#64748b\" stroke-width=\"2\"/><line x1=\"94\" y1=\"22\" x2=\"94\" y2=\"50\" stroke=\"#f59e0b\" stroke-width=\"3\"/><line x1=\"106\" y1=\"22\" x2=\"106\" y2=\"50\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "2. Rasmdagi belgi (1-jadval, №2) nimani anglatadi?",
          "ru": "Какой тип шва обозначает данный символ (Таблица 1, №2)?",
          "en": "Identify this elementary symbol (Table 1, No. 2):"
        },
        "options": [
          {
            "uz": "Bir tomonlama V-simon uchma-uch chok (Single-V butt weld)",
            "ru": "Стыковой шов с односторонней V-образной разделкой",
            "en": "Single-V butt weld"
          },
          {
            "uz": "Burchakli chok",
            "ru": "Угловой шов",
            "en": "Fillet weld"
          },
          {
            "uz": "Ustunsimon chok",
            "ru": "Столбчатый шов",
            "en": "Stake weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №2: Single-V butt weld.",
          "ru": "Таблица 1, №2.",
          "en": "Table 1, No. 2: Single-V butt weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"50\" x2=\"180\" y2=\"50\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,22 L100,50 L116,22\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "3. Rasmdagi 'Y' belgisi (1-jadval, №3) qanday chokni bildiradi?",
          "ru": "Какой тип шва обозначает символ Y (Таблица 1, №3)?",
          "en": "Identify this elementary symbol (Table 1, No. 3):"
        },
        "options": [
          {
            "uz": "Toʻmtoqlangan bir tomonlama V-simon chok (Single-V with broad root face)",
            "ru": "Стыковой шов с односторонней V-образной разделкой и притуплением",
            "en": "Single-V butt weld with broad root face"
          },
          {
            "uz": "U-simon chok",
            "ru": "U-образный шов",
            "en": "Single-U butt weld"
          },
          {
            "uz": "Shpilka payvandlash",
            "ru": "Приварка шпильки",
            "en": "Stud weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №3: Single-V butt weld with broad root face.",
          "ru": "Таблица 1, №3.",
          "en": "Table 1, No. 3: Single-V butt weld with broad root face."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,20 L100,37 L116,20 M100,37 L100,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "4. Rasmdagi belgi (1-jadval, №4) qanday chokni anglatadi?",
          "ru": "Какой тип шва обозначает данный символ (Таблица 1, №4)?",
          "en": "Identify this elementary symbol (Table 1, No. 4):"
        },
        "options": [
          {
            "uz": "Bir qirrasi qiya kesilgan uchma-uch chok (Single-bevel butt weld)",
            "ru": "Стыковой шов с односторонней V-образной разделкой одной кромки",
            "en": "Single-bevel butt weld"
          },
          {
            "uz": "Burchakli chok",
            "ru": "Угловой шов",
            "en": "Fillet weld"
          },
          {
            "uz": "J-simon chok",
            "ru": "J-образный шов",
            "en": "Single-J butt weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №4: Single-bevel butt weld.",
          "ru": "Таблица 1, №4.",
          "en": "Table 1, No. 4: Single-bevel butt weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"50\" x2=\"180\" y2=\"50\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M90,22 L90,50 L114,22\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "5. Rasmdagi belgi (1-jadval, №5) qaysi chok turiga tegishli?",
          "ru": "Какой тип шва обозначает данный символ (Таблица 1, №5)?",
          "en": "Identify this elementary symbol (Table 1, No. 5):"
        },
        "options": [
          {
            "uz": "Bir qirrasi qiya kesilgan va toʻmtoqlangan chok (Single-bevel with broad root face)",
            "ru": "Стыковой шов со скосом одной кромки и притуплением",
            "en": "Single-bevel butt weld with broad root face"
          },
          {
            "uz": "Toʻmtoqlangan V-chok",
            "ru": "V-образный с притуплением",
            "en": "Single-V with broad root face"
          },
          {
            "uz": "Bortli chok",
            "ru": "Шов с отбортовкой",
            "en": "Flange weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №5.",
          "ru": "Таблица 1, №5.",
          "en": "Table 1, No. 5: Single-bevel butt weld with broad root face."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M90,20 L90,52 M90,37 L112,20\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "6. Rasmdagi belgi (1-jadval, №6) qanday chokni bildiradi?",
          "ru": "Какой тип шва обозначает данный символ (Таблица 1, №6)?",
          "en": "Identify this elementary symbol (Table 1, No. 6):"
        },
        "options": [
          {
            "uz": "Bir tomonlama U-simon uchma-uch chok (Single-U butt weld)",
            "ru": "Стыковой шов с односторонней U-образной разделкой",
            "en": "Single-U butt weld"
          },
          {
            "uz": "Teshikli chok",
            "ru": "Пробочный шов",
            "en": "Plug weld"
          },
          {
            "uz": "Qirra chok",
            "ru": "Торцевой шов",
            "en": "Edge weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №6.",
          "ru": "Таблица 1, №6.",
          "en": "Table 1, No. 6: Single-U butt weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M86,20 L86,32 A14,14 0 0,0 114,32 L114,20 M100,46 L100,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "7. Rasmdagi 'P' shaklidagi belgi (1-jadval, №7) nimani anglatadi?",
          "ru": "Какой тип шва обозначает данный символ (Таблица 1, №7)?",
          "en": "Identify this elementary symbol (Table 1, No. 7):"
        },
        "options": [
          {
            "uz": "Bir tomonlama J-simon uchma-uch chok (Single-J butt weld)",
            "ru": "Стыковой шов с односторонней J-образной разделкой одной кромки",
            "en": "Single-J butt weld"
          },
          {
            "uz": "Shpilka payvandlash",
            "ru": "Приварка шпильки",
            "en": "Stud weld"
          },
          {
            "uz": "Rolikli chok",
            "ru": "Роликовый шов",
            "en": "Seam weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №7.",
          "ru": "Таблица 1, №7.",
          "en": "Table 1, No. 7: Single-J butt weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M90,20 L90,52 M90,38 C108,38 108,20 108,20\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "8. Rasmdagi belgi (1-jadval, №8) qaysi chokni bildiradi?",
          "ru": "Какой тип шва обозначает данный символ (Таблица 1, №8)?",
          "en": "Identify this elementary symbol (Table 1, No. 8):"
        },
        "options": [
          {
            "uz": "Ikkita yumaloq detal orasidagi chok (Flare-V weld)",
            "ru": "Шов между двумя закругленными деталями",
            "en": "Flare-V weld"
          },
          {
            "uz": "Bortli uchma-uch chok",
            "ru": "Стыковой с отбортовкой",
            "en": "Flange butt weld"
          },
          {
            "uz": "U-simon chok",
            "ru": "U-образный шов",
            "en": "Single-U butt weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №8: Flare-V weld.",
          "ru": "Таблица 1, №8.",
          "en": "Table 1, No. 8: Flare-V weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M82,22 C94,22 96,50 96,50 M118,22 C106,22 104,50 104,50\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "9. Rasmdagi belgi (1-jadval, №9) nimani anglatadi?",
          "ru": "Какой тип шва обозначает данный символ (Таблица 1, №9)?",
          "en": "Identify this elementary symbol (Table 1, No. 9):"
        },
        "options": [
          {
            "uz": "Yumaloq va tekis detal orasidagi chok (Flare-bevel weld)",
            "ru": "Шов между закругленной и плоской деталями",
            "en": "Flare-bevel weld"
          },
          {
            "uz": "Bortli burchakli chok",
            "ru": "Угловой с отбортовкой",
            "en": "Flange corner weld"
          },
          {
            "uz": "Bir qirrali V-chok",
            "ru": "Со скосом одной кромки",
            "en": "Single-bevel butt weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №9: Flare-bevel weld.",
          "ru": "Таблица 1, №9.",
          "en": "Table 1, No. 9: Flare-bevel weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M90,22 L90,52 M116,22 C102,22 98,50 98,50\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "10. Rasmdagi toʻgʻri burchakli uchburchak (1-jadval, №10) qanday chok?",
          "ru": "Какой тип шва обозначает данный символ (Таблица 1, №10)?",
          "en": "Identify this elementary symbol (Table 1, No. 10):"
        },
        "options": [
          {
            "uz": "Burchakli chok (Fillet weld)",
            "ru": "Угловой шов",
            "en": "Fillet weld"
          },
          {
            "uz": "Ustunsimon chok",
            "ru": "Столбчатый шов",
            "en": "Stake weld"
          },
          {
            "uz": "Relefli chok",
            "ru": "Рельефный шов",
            "en": "Projection weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №10: Fillet weld.",
          "ru": "Таблица 1, №10.",
          "en": "Table 1, No. 10: Fillet weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><polygon points=\"88,52 88,24 116,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "11. Rasmdagi toʻrtburchak belgi (1-jadval, №11) qanday chokni bildiradi?",
          "ru": "Какой тип шва обозначает данный символ (Таблица 1, №11)?",
          "en": "Identify this elementary symbol (Table 1, No. 11):"
        },
        "options": [
          {
            "uz": "Teshikli / tirqishli chok (Plug / slot weld)",
            "ru": "Пробочный шов (в круглые или продолговатые отверстия)",
            "en": "Plug or slot weld"
          },
          {
            "uz": "Uchma-uch tekis chok",
            "ru": "Стыковой без скоса",
            "en": "Square butt weld"
          },
          {
            "uz": "Qoplama eritish",
            "ru": "Наплавка",
            "en": "Surfacing"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №11: Plug / slot weld.",
          "ru": "Таблица 1, №11.",
          "en": "Table 1, No. 11: Plug or slot weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><rect x=\"82\" y=\"28\" width=\"36\" height=\"24\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "12. Tokcha chizigʻi oʻrtasidagi aylana (1-jadval, №12.1) qaysi payvandlash turi?",
          "ru": "Какой шов обозначает окружность по центру полки (Таблица 1, №12.1)?",
          "en": "Identify this elementary symbol centered on the reference line (Table 1, No. 12.1):"
        },
        "options": [
          {
            "uz": "Kontakt nuqtali chok (Resistance spot weld)",
            "ru": "Точечный при контактной сварке сопротивлением",
            "en": "Resistance spot weld"
          },
          {
            "uz": "Eritib nuqtali chok",
            "ru": "Точечный при сварке плавлением",
            "en": "Fusion spot weld"
          },
          {
            "uz": "Shpilka payvandlash",
            "ru": "Приварка шпильки",
            "en": "Stud weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №12.1.",
          "ru": "Таблица 1, №12.1.",
          "en": "Table 1, No. 12.1: Resistance spot weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"38\" x2=\"180\" y2=\"38\" stroke=\"#64748b\" stroke-width=\"2\"/><circle cx=\"100\" cy=\"38\" r=\"14\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "13. Rasmdagi uchburchak (1-jadval, №12.2) nimani anglatadi?",
          "ru": "Какой шов обозначает данный символ (Таблица 1, №12.2)?",
          "en": "Identify this elementary symbol (Table 1, No. 12.2):"
        },
        "options": [
          {
            "uz": "Kontakt relefli chok (Projection weld)",
            "ru": "Шов контактной рельефной сварки",
            "en": "Projection weld"
          },
          {
            "uz": "Burchakli chok",
            "ru": "Угловой шов",
            "en": "Fillet weld"
          },
          {
            "uz": "Ustunsimon chok",
            "ru": "Столбчатый шов",
            "en": "Stake weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №12.2: Projection weld.",
          "ru": "Таблица 1, №12.2.",
          "en": "Table 1, No. 12.2: Projection weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"45\" x2=\"180\" y2=\"45\" stroke=\"#64748b\" stroke-width=\"2\"/><polygon points=\"100,20 116,45 84,45\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "14. Tokcha chizigʻi ustidagi/ostidagi aylana (1-jadval, №13) qaysi chok?",
          "ru": "Какой шов обозначает окружность над/под линией полки (Таблица 1, №13)?",
          "en": "Identify this elementary symbol placed above/below the reference line (Table 1, No. 13):"
        },
        "options": [
          {
            "uz": "Eritib nuqtali chok (Fusion spot weld)",
            "ru": "Точечный при сварке плавлением",
            "en": "Fusion spot weld"
          },
          {
            "uz": "Kontakt nuqtali chok",
            "ru": "Точечный контактной сваркой",
            "en": "Resistance spot weld"
          },
          {
            "uz": "Yopiq kontur belgisi",
            "ru": "По замкнутому контуру",
            "en": "Weld all-around"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №13: Fusion spot weld.",
          "ru": "Таблица 1, №13.",
          "en": "Table 1, No. 13: Fusion spot weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><circle cx=\"100\" cy=\"37\" r=\"14\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "15. Tokcha chizigʻi oʻrtasidagi ikki chiziqli aylana (1-jadval, №14) nimani bildiradi?",
          "ru": "Какой шов обозначает символ №14 по центру полки (Таблица 1)?",
          "en": "Identify this elementary symbol centered on the reference line (Table 1, No. 14):"
        },
        "options": [
          {
            "uz": "Kontakt rolikli chok (Resistance seam weld)",
            "ru": "Роликовый при контактной шовной сварке",
            "en": "Resistance seam weld"
          },
          {
            "uz": "Eritib rolikli chok",
            "ru": "Роликовый при сварке плавлением",
            "en": "Fusion seam weld"
          },
          {
            "uz": "Shpilka payvandlash",
            "ru": "Приварка шпильки",
            "en": "Stud weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №14: Resistance seam weld.",
          "ru": "Таблица 1, №14.",
          "en": "Table 1, No. 14: Resistance seam weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"38\" x2=\"180\" y2=\"38\" stroke=\"#64748b\" stroke-width=\"2\"/><circle cx=\"100\" cy=\"38\" r=\"14\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><line x1=\"80\" y1=\"34\" x2=\"120\" y2=\"34\" stroke=\"#f59e0b\" stroke-width=\"2\"/><line x1=\"80\" y1=\"42\" x2=\"120\" y2=\"42\" stroke=\"#f59e0b\" stroke-width=\"2\"/></svg>"
      },
      {
        "question": {
          "uz": "16. Tokcha ustidagi/ostidagi ikki chiziqli aylana (1-jadval, №15) nimani bildiradi?",
          "ru": "Какой шов обозначает символ №15 над/под полкой (Таблица 1)?",
          "en": "Identify this elementary symbol above/below the reference line (Table 1, No. 15):"
        },
        "options": [
          {
            "uz": "Eritib rolikli chok (Fusion seam weld)",
            "ru": "Роликовый при сварке плавлением",
            "en": "Fusion seam weld"
          },
          {
            "uz": "Kontakt rolikli chok",
            "ru": "Роликовый при контактной сварке",
            "en": "Resistance seam weld"
          },
          {
            "uz": "Qoplama eritish",
            "ru": "Наплавка",
            "en": "Surfacing"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №15: Fusion seam weld.",
          "ru": "Таблица 1, №15.",
          "en": "Table 1, No. 15: Fusion seam weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"54\" x2=\"180\" y2=\"54\" stroke=\"#64748b\" stroke-width=\"2\"/><circle cx=\"100\" cy=\"38\" r=\"14\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><line x1=\"80\" y1=\"34\" x2=\"120\" y2=\"34\" stroke=\"#f59e0b\" stroke-width=\"2\"/><line x1=\"80\" y1=\"42\" x2=\"120\" y2=\"42\" stroke=\"#f59e0b\" stroke-width=\"2\"/></svg>"
      },
      {
        "question": {
          "uz": "17. Rasmdagi belgi (1-jadval, №16) qanday payvandlash turini bildiradi?",
          "ru": "Какой тип соединения обозначает символ №16 (Таблица 1)?",
          "en": "Identify this elementary symbol (Table 1, No. 16):"
        },
        "options": [
          {
            "uz": "Shpilka payvandlash (Stud weld)",
            "ru": "Приварка шпильки",
            "en": "Stud weld"
          },
          {
            "uz": "Nuqtali chok",
            "ru": "Точечный шов",
            "en": "Spot weld"
          },
          {
            "uz": "Teshikli chok",
            "ru": "Пробочный шов",
            "en": "Plug weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №16: Stud weld.",
          "ru": "Таблица 1, №16.",
          "en": "Table 1, No. 16: Stud weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"54\" x2=\"180\" y2=\"54\" stroke=\"#64748b\" stroke-width=\"2\"/><circle cx=\"100\" cy=\"38\" r=\"13\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><line x1=\"100\" y1=\"25\" x2=\"100\" y2=\"54\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/></svg>"
      },
      {
        "question": {
          "uz": "18. Rasmdagi tik qirrali tor V-belgi (1-jadval, №17) nimani anglatadi?",
          "ru": "Какой шов обозначает символ №17 (Таблица 1)?",
          "en": "Identify this elementary symbol (Table 1, No. 17):"
        },
        "options": [
          {
            "uz": "Tik qirrali tor V-simon chok (Steep-flanked single-V butt weld)",
            "ru": "Стыковой шов с односторонней V-образной крутой разделкой (в узкую разделку)",
            "en": "Steep-flanked single-V butt weld"
          },
          {
            "uz": "Oddiy V-chok",
            "ru": "Обычный V-образный шов",
            "en": "Single-V butt weld"
          },
          {
            "uz": "U-simon chok",
            "ru": "U-образный шов",
            "en": "Single-U butt weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №17: Steep-flanked single-V butt weld.",
          "ru": "Таблица 1, №17.",
          "en": "Table 1, No. 17: Steep-flanked single-V butt weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M91,20 L97,52 L103,52 L109,20\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "19. Rasmdagi tik qirrali tor bir tomonlama belgi (1-jadval, №18) nimani bildiradi?",
          "ru": "Какой шов обозначает символ №18 (Таблица 1)?",
          "en": "Identify this elementary symbol (Table 1, No. 18):"
        },
        "options": [
          {
            "uz": "Tik qirrali tor bir qirrali chok (Steep-flanked single-bevel butt weld)",
            "ru": "Стыковой шов с крутой разделкой одной кромки (в узкую разделку)",
            "en": "Steep-flanked single-bevel butt weld"
          },
          {
            "uz": "Burchakli chok",
            "ru": "Угловой шов",
            "en": "Fillet weld"
          },
          {
            "uz": "Qirra chok",
            "ru": "Торцевой шов",
            "en": "Edge weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №18: Steep-flanked single-bevel butt weld.",
          "ru": "Таблица 1, №18.",
          "en": "Table 1, No. 18: Steep-flanked single-bevel butt weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M92,20 L92,52 L100,52 L108,20\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "20. Rasmdagi 'Π' shaklidagi belgi (1-jadval, №19) qanday chok?",
          "ru": "Какой шов обозначает символ №19 в виде буквы Π (Таблица 1)?",
          "en": "Identify this elementary symbol (Table 1, No. 19):"
        },
        "options": [
          {
            "uz": "Qirra chok (Edge weld)",
            "ru": "Торцевой шов",
            "en": "Edge weld"
          },
          {
            "uz": "Teshikli chok",
            "ru": "Пробочный шов",
            "en": "Plug weld"
          },
          {
            "uz": "Qoplama eritish",
            "ru": "Наплавка",
            "en": "Surfacing"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №19: Edge weld.",
          "ru": "Таблица 1, №19.",
          "en": "Table 1, No. 19: Edge weld."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,52 L84,26 L116,26 L116,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "21. Rasmdagi №20.1 va №20.2 belgilari qanday birikmalarga tegishli?",
          "ru": "К каким соединениям относятся символы №20.1 и №20.2 в Таблице 1?",
          "en": "Which joint types are shown by symbols No. 20.1 and No. 20.2 (Table 1)?"
        },
        "options": [
          {
            "uz": "Qirralari qayrilgan (bortli) uchma-uch (Flange butt) va burchakli (Flange corner) choklar",
            "ru": "Стыковой (№20.1) и угловой (№20.2) швы с отбортовкой кромок",
            "en": "Flange butt weld (20.1) and Flange corner weld (20.2)"
          },
          {
            "uz": "Flare-V va Flare-bevel choklar",
            "ru": "Швы между закругленными деталями",
            "en": "Flare-V and Flare-bevel welds"
          },
          {
            "uz": "U-simon va J-simon choklar",
            "ru": "U- и J-образные швы",
            "en": "U- and J-groove welds"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №20.1 va №20.2.",
          "ru": "Таблица 1, №20.1 и №20.2.",
          "en": "Table 1, No. 20.1 & 20.2."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M82,24 Q94,24 94,52 M118,24 Q106,24 106,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "22. Rasmdagi ikkita yoy (№21) va uchburchak (№22) qaysi choklarni bildiradi?",
          "ru": "Какие швы обозначают символы №21 и №22 в Таблице 1?",
          "en": "Identify elementary symbols No. 21 and No. 22 (Table 1):"
        },
        "options": [
          {
            "uz": "№21 — Qoplama eritish (Surfacing / Наплавка); №22 — Ustunsimon lazer/elektron-nurli chok (Stake weld)",
            "ru": "№21 — Наплавка; №22 — Столбчатый шов",
            "en": "No. 21 = Surfacing; No. 22 = Stake weld"
          },
          {
            "uz": "№21 — Rolikli chok; №22 — Burchakli chok",
            "ru": "№21 — Роликовый; №22 — Угловой",
            "en": "No. 21 = Seam; No. 22 = Fillet"
          },
          {
            "uz": "№21 — Ildiz valigi; №22 — Relefli chok",
            "ru": "№21 — Подварочный; №22 — Рельефный",
            "en": "No. 21 = Back run; No. 22 = Projection"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval №21 va №22.",
          "ru": "Таблица 1, №21 и №22.",
          "en": "Table 1, No. 21 & 22."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><polygon points=\"92,24 108,24 100,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"3\"/></svg>"
      }
    ]
  },
  {
    "id": "2553-supp",
    "pdfPage": 13,
    "title": {
      "uz": "4. Barcha 13 xil qoʻshimcha belgilar (3–4-jadvallar) — 15 ta test (belgidan nomga va nomdan belgiga)",
      "ru": "4. Все 13 вспомогательных обозначений (Табл. 3–4) — 15 тестов (прямые и обратные)",
      "en": "4. All 13 Supplementary Symbols (Tables 3–4) — 15 Questions (Symbol ↔ Meaning)"
    },
    "theory": {
      "uz": "3-jadvaldagi barcha 13 ta qoʻshimcha belgi (har biri alohida testda soʻraladi — ham belgi boʻyicha nomini topish, ham nom boʻyicha belgini tanlash):\n• №1 Flush / flat (—): Qavariqligi olingan tekis yuza.\n• №2 Convex (⌢): Qavariq yuza.\n• №3 Concave (⌣): Botiq yuza.\n• №4 Toes blended smoothly: Chok chekkalari asosiy metallga silliq oʻtgan.\n• №5 Back run / backing weld: Ildiz valigi / taglik choki.\n• №6 Root convexity: Ildiz qavariqligi (qora yarim doira qarama-qarshi tomonda).\n• №7a Backing (unspecified): Taglik (turi koʻrsatilmagan).\n• №7b Permanent backing [M]: Doimiy qoladigan taglik.\n• №7c Removable backing [MR]: Payvandlashdan keyin olib tashlanadigan taglik.\n• №8 Spacer: Ajratgich (ikki detal orasiga qoʻyiladigan plastina).\n• №9 Consumable insert: Eruvchan qoʻshimcha (ildizga qoʻyiladigan halqa/sim).\n• №10 Weld all-around (○): Yopiq kontur boʻylab payvandlash.\n• №11 Weld between two points (A ↔ B): Ikki nuqta orasidagi chok.\n• №12 Field weld (⚑): Montaj choki.\n• №13 Staggered intermittent weld (Z): Shaxmat tartibidagi uzuq chok.",
      "ru": "Все 13 вспомогательных обозначений (Таблица 3):\n• №1 Выпуклость снята (плоский) | №2 Выпуклый | №3 Вогнутый\n• №4 Лицевая поверхность с плавным переходом\n• №5 Подварочный / корневой шов | №6 Выпуклость корня шва\n• №7a Подкладка (не определена) | №7b Остающаяся [M] | №7c Съемная [MR]\n• №8 Разделитель (Spacer)\n• №9 Плавящаяся вставка (Consumable insert)\n• №10 Сварка по замкнутому контуру (○)\n• №11 Шов между двумя точками (A ↔ B)\n• №12 Монтажный шов (флажок)\n• №13 Шахматные прерывистые швы (Z).",
      "en": "All 13 Supplementary Symbols in ISO 2553 Table 3:\n• №1 Flush / flat | №2 Convex | №3 Concave\n• №4 Toes blended smoothly\n• №5 Back run / backing weld | №6 Root convexity\n• №7a Backing (unspecified) | №7b Permanent backing [M] | №7c Removable backing [MR]\n• №8 Spacer\n• №9 Consumable insert\n• №10 Weld all-around (○)\n• №11 Weld between two points (A ↔ B)\n• №12 Field weld (flag)\n• №13 Staggered intermittent welds (Z)."
    },
    "items": [
      {
        "name": {
          "uz": "№1 Tekis, №2 Qavariq, №3 Botiq, №4 Silliq oʻtish",
          "ru": "№1 Плоский, №2 Выпуклый, №3 Вогнутый, №4 Плавный переход",
          "en": "№1 Flush, №2 Convex, №3 Concave, №4 Blended Smoothly"
        },
        "desc": {
          "uz": "3-jadval (1–4)",
          "ru": "Таблица 3 (1–4)",
          "en": "Table 3 (1–4)"
        },
        "symbolSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,26 L100,52 L116,26\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><line x1=\"80\" y1=\"20\" x2=\"120\" y2=\"20\" stroke=\"#22c55e\" stroke-width=\"3\"/></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><polygon points=\"86,52 86,26 112,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><path d=\"M90,22 C96,36 104,44 118,48\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"3\"/></svg>"
      },
      {
        "name": {
          "uz": "№5 Ildiz valigi va №6 Ildiz qavariqligi",
          "ru": "№5 Подварочный шов и №6 Выпуклость корня",
          "en": "№5 Back Run & №6 Root Convexity"
        },
        "desc": {
          "uz": "3-jadval (5–6)",
          "ru": "Таблица 3 (5–6)",
          "en": "Table 3 (5–6)"
        },
        "symbolSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"40\" x2=\"180\" y2=\"40\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,16 L100,40 L116,16\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><path d=\"M86,40 A14,14 0 0,0 114,40\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"3\"/></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"40\" x2=\"180\" y2=\"40\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,16 L100,40 L116,16\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><path d=\"M86,40 A14,14 0 0,0 114,40 Z\" fill=\"#22c55e\"/></svg>"
      },
      {
        "name": {
          "uz": "№7b [M] Doimiy taglik va №7c [MR] Olinadigan taglik",
          "ru": "№7b [M] Остающаяся и №7c [MR] Съемная подкладка",
          "en": "№7b Permanent [M] & №7c Removable [MR] Backing"
        },
        "desc": {
          "uz": "3-jadval (7)",
          "ru": "Таблица 3 (7)",
          "en": "Table 3 (7)"
        },
        "symbolSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"40\" x2=\"180\" y2=\"40\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,16 L100,40 L116,16\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><rect x=\"85\" y=\"40\" width=\"30\" height=\"18\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2.5\"/><text x=\"100\" y=\"53\" fill=\"#22c55e\" font-size=\"12\" font-weight=\"bold\" text-anchor=\"middle\">M</text></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"40\" x2=\"180\" y2=\"40\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,16 L100,40 L116,16\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><rect x=\"82\" y=\"40\" width=\"36\" height=\"18\" fill=\"none\" stroke=\"#ef4444\" stroke-width=\"2.5\"/><text x=\"100\" y=\"53\" fill=\"#ef4444\" font-size=\"11\" font-weight=\"bold\" text-anchor=\"middle\">MR</text></svg>"
      },
      {
        "name": {
          "uz": "№8 Ajratgich (Spacer) va №9 Eruvchan qoʻshimcha (Insert)",
          "ru": "№8 Разделитель и №9 Плавящаяся вставка",
          "en": "№8 Spacer & №9 Consumable Insert"
        },
        "desc": {
          "uz": "3-jadval (8–9)",
          "ru": "Таблица 3 (8–9)",
          "en": "Table 3 (8–9)"
        },
        "symbolSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"38\" x2=\"180\" y2=\"38\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M86,14 L100,30 L114,14 M86,62 L100,46 L114,62\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2\"/><rect x=\"88\" y=\"31\" width=\"24\" height=\"14\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2.5\"/></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"42\" x2=\"180\" y2=\"42\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,18 L100,42 L116,18\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><rect x=\"93\" y=\"42\" width=\"14\" height=\"14\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2.5\"/></svg>"
      },
      {
        "name": {
          "uz": "№10 Kontur (○), №11 (A↔B), №12 Montaj (⚑), №13 Shaxmat (Z)",
          "ru": "№10 Контур (○), №11 (A↔B), №12 Монтаж (⚑), №13 Шахматный (Z)",
          "en": "№10 All-around (○), №11 (A↔B), №12 Field (⚑), №13 Staggered (Z)"
        },
        "desc": {
          "uz": "3-jadval (10–13)",
          "ru": "Таблица 3 (10–13)",
          "en": "Table 3 (10–13)"
        },
        "symbolSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"30\" y1=\"62\" x2=\"75\" y2=\"32\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"75\" y1=\"32\" x2=\"170\" y2=\"32\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><circle cx=\"75\" cy=\"32\" r=\"9\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"3\"/></svg>",
        "crossSectionSvg": "<svg viewBox=\"0 0 200 75\"><line x1=\"30\" y1=\"62\" x2=\"75\" y2=\"38\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"75\" y1=\"38\" x2=\"170\" y2=\"38\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"75\" y1=\"38\" x2=\"75\" y2=\"12\" stroke=\"#22c55e\" stroke-width=\"2.5\"/><polygon points=\"75,12 96,19 75,26\" fill=\"#22c55e\"/></svg>"
      }
    ],
    "quiz": [
      {
        "question": {
          "uz": "1. Rasmdagi qoʻshimcha belgi (3-jadval, №1) nimani bildiradi?",
          "ru": "Что означает данное вспомогательное обозначение (Таблица 3, №1)?",
          "en": "What does this supplementary symbol indicate (Table 3, No. 1)?"
        },
        "options": [
          {
            "uz": "Qavariqligi olingan tekis yuza (Flush / flat)",
            "ru": "Выпуклость снята (плоский)",
            "en": "Flush / flat weld face"
          },
          {
            "uz": "Qavariq yuza",
            "ru": "Выпуклый",
            "en": "Convex"
          },
          {
            "uz": "Botiq yuza",
            "ru": "Вогнутый",
            "en": "Concave"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №1.",
          "ru": "Таблица 3, №1.",
          "en": "Table 3, No. 1: Flush / flat."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,26 L100,52 L116,26\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><line x1=\"80\" y1=\"20\" x2=\"120\" y2=\"20\" stroke=\"#22c55e\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "2. Rasmdagi qoʻshimcha belgi (3-jadval, №2) nimani anglatadi?",
          "ru": "Что означает данное вспомогательное обозначение (Таблица 3, №2)?",
          "en": "What does this supplementary symbol indicate (Table 3, No. 2)?"
        },
        "options": [
          {
            "uz": "Qavariq yuza (Convex)",
            "ru": "Выпуклый",
            "en": "Convex weld face"
          },
          {
            "uz": "Botiq yuza (Concave)",
            "ru": "Вогнутый",
            "en": "Concave"
          },
          {
            "uz": "Tekis yuza (Flush)",
            "ru": "Плоский",
            "en": "Flush"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №2.",
          "ru": "Таблица 3, №2.",
          "en": "Table 3, No. 2: Convex."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,26 L100,52 L116,26\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><path d=\"M80,22 Q100,10 120,22\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "3. Rasmdagi qoʻshimcha belgi (3-jadval, №3) qanday yuza shaklini talab qiladi?",
          "ru": "Какую форму поверхности задает символ №3 (Таблица 3)?",
          "en": "Which weld face profile is specified by this symbol (Table 3, No. 3)?"
        },
        "options": [
          {
            "uz": "Botiq yuza (Concave)",
            "ru": "Вогнутый",
            "en": "Concave weld face"
          },
          {
            "uz": "Qavariq yuza (Convex)",
            "ru": "Выпуклый",
            "en": "Convex"
          },
          {
            "uz": "Silliq oʻtish",
            "ru": "Плавный переход",
            "en": "Toes blended smoothly"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №3.",
          "ru": "Таблица 3, №3.",
          "en": "Table 3, No. 3: Concave."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,26 L100,52 L116,26\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><path d=\"M80,15 Q100,27 120,15\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "4. Rasmdagi egri chiziq belgisi (3-jadval, №4) nimani talab qiladi?",
          "ru": "Что означает вспомогательное обозначение №4 (Таблица 3)?",
          "en": "What is required by this supplementary symbol (Table 3, No. 4)?"
        },
        "options": [
          {
            "uz": "Chok chekkalari asosiy metallga silliq oʻtgan yuza (Toes blended smoothly)",
            "ru": "Лицевая поверхность шва с плавным переходом",
            "en": "Toes blended smoothly"
          },
          {
            "uz": "Montaj choki",
            "ru": "Монтажный шов",
            "en": "Field weld"
          },
          {
            "uz": "Ildiz qavariqligi",
            "ru": "Выпуклость корня",
            "en": "Root convexity"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №4.",
          "ru": "Таблица 3, №4.",
          "en": "Table 3, No. 4: Toes blended smoothly."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><polygon points=\"86,52 86,26 112,52\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><path d=\"M90,22 C96,36 104,44 118,48\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"3\"/></svg>"
      },
      {
        "question": {
          "uz": "5. Boʻsh yarim doira (3-jadval, №5) va qora boʻyalgan yarim doira (№6) nimasi bilan farq qiladi?",
          "ru": "В чем разница между пустым полукругом (№5) и закрашенным полукругом (№6) в Таблице 3?",
          "en": "How do the open semicircle (No. 5) and filled semicircle (No. 6) differ in Table 3?"
        },
        "options": [
          {
            "uz": "№5 (boʻsh) — ildiz valigi / taglik choki (back run / backing weld); №6 (qora) — ildiz qavariqligi (root convexity)",
            "ru": "№5 — подварочный/корневой шов; №6 — выпуклость корня шва",
            "en": "No. 5 = back run / backing weld; No. 6 = root convexity"
          },
          {
            "uz": "№5 — qavariq yuza; №6 — botiq yuza",
            "ru": "№5 — выпуклый; №6 — вогнутый",
            "en": "No. 5 = convex; No. 6 = concave"
          },
          {
            "uz": "Farqi yoʻq",
            "ru": "Разницы нет",
            "en": "No difference"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №5 va №6.",
          "ru": "Таблица 3, №5 и №6.",
          "en": "Table 3, No. 5 & 6."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"40\" x2=\"180\" y2=\"40\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,16 L100,40 L116,16\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><path d=\"M86,40 A14,14 0 0,0 114,40 Z\" fill=\"#22c55e\"/></svg>"
      },
      {
        "question": {
          "uz": "6. Rasmdagi [M] va [MR] belgilarining (3-jadval, №7b va №7c) ma'nosi nima?",
          "ru": "Что означают обозначения [M] и [MR] в Таблице 3 (№7b и №7c)?",
          "en": "What do [M] and [MR] indicate in Table 3 (No. 7b & 7c)?"
        },
        "options": [
          {
            "uz": "[M] — doimiy qoladigan taglik (permanent backing); [MR] — payvandlashdan keyin olib tashlanadigan taglik (removable backing)",
            "ru": "[M] — остающаяся подкладка; [MR] — съемная/временная подкладка",
            "en": "[M] = permanent backing; [MR] = removable / temporary backing"
          },
          {
            "uz": "[M] — mis taglik; [MR] — rezina taglik",
            "ru": "[M] — медная; [MR] — резиновая",
            "en": "[M] = copper; [MR] = rubber"
          },
          {
            "uz": "[M] — montaj; [MR] — remont",
            "ru": "[M] — монтаж; [MR] — ремонт",
            "en": "[M] = field; [MR] = repair"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №7b va №7c.",
          "ru": "Таблица 3, №7b и №7c.",
          "en": "Table 3, No. 7b & 7c."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"40\" x2=\"180\" y2=\"40\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,16 L100,40 L116,16\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><rect x=\"82\" y=\"40\" width=\"36\" height=\"18\" fill=\"none\" stroke=\"#ef4444\" stroke-width=\"2.5\"/><text x=\"100\" y=\"53\" fill=\"#ef4444\" font-size=\"11\" font-weight=\"bold\" text-anchor=\"middle\">MR</text></svg>"
      },
      {
        "question": {
          "uz": "7. Rasmdagi tokcha oʻrtasidagi toʻrtburchak (3-jadval, №8) nimani bildiradi?",
          "ru": "Что означает прямоугольник по центру линии полки (Таблица 3, №8)?",
          "en": "What does the rectangle centered on the reference line represent (Table 3, No. 8)?"
        },
        "options": [
          {
            "uz": "Ajratgich (Spacer / Разделитель)",
            "ru": "Разделитель (Spacer)",
            "en": "Spacer"
          },
          {
            "uz": "Eruvchan qoʻshimcha (Consumable insert)",
            "ru": "Плавящаяся вставка",
            "en": "Consumable insert"
          },
          {
            "uz": "Teshikli chok (Plug weld)",
            "ru": "Пробочный шов",
            "en": "Plug weld"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №8: Spacer.",
          "ru": "Таблица 3, №8: Разделитель.",
          "en": "Table 3, No. 8: Spacer."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"38\" x2=\"180\" y2=\"38\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M86,14 L100,30 L114,14 M86,62 L100,46 L114,62\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2\"/><rect x=\"88\" y=\"31\" width=\"24\" height=\"14\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2.5\"/></svg>"
      },
      {
        "question": {
          "uz": "8. Rasmdagi kichik kvadrat (3-jadval, №9) nimani anglatadi?",
          "ru": "Что означает маленький квадрат на линии полки (Таблица 3, №9)?",
          "en": "What does the small square on the reference line represent (Table 3, No. 9)?"
        },
        "options": [
          {
            "uz": "Eruvchan qoʻshimcha (Consumable insert / Плавящаяся вставка)",
            "ru": "Плавящаяся вставка (Consumable insert)",
            "en": "Consumable insert"
          },
          {
            "uz": "Ajratgich (Spacer)",
            "ru": "Разделитель",
            "en": "Spacer"
          },
          {
            "uz": "Olib tashlanadigan taglik [MR]",
            "ru": "Съемная подкладка",
            "en": "Removable backing"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №9: Consumable insert.",
          "ru": "Таблица 3, №9: Плавящаяся вставка.",
          "en": "Table 3, No. 9: Consumable insert."
        },
        "svg": "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"42\" x2=\"180\" y2=\"42\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,18 L100,42 L116,18\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><rect x=\"93\" y=\"42\" width=\"14\" height=\"14\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2.5\"/></svg>"
      },
      {
        "question": {
          "uz": "9. [TESKARI SAVOL] Quyidagi belgilardan qaysi biri 'Yopiq kontur boʻylab payvandlash' (Weld all-around, №10) ni bildiradi?",
          "ru": "[ОБРАТНЫЙ ВОПРОС] Какой из символов обозначает 'Сварку по замкнутому контуру' (Таблица 3, №10)?",
          "en": "[REVERSE] Which symbol represents 'Weld all-around' (Table 3, No. 10)?"
        },
        "options": [
          {
            "uz": "A — Strelka va tokcha kesishmasidagi aylana (○)",
            "ru": "А — Окружность в месте соединения стрелки и полки",
            "en": "A — Circle at junction of arrow and reference line"
          },
          {
            "uz": "B — Kesishish nuqtasidagi bayroqcha (⚑)",
            "ru": "B — Флажок в месте соединения",
            "en": "B — Flag at junction"
          },
          {
            "uz": "C — Tokchadagi Z belgisi",
            "ru": "C — Знак Z на полке",
            "en": "C — Z symbol on reference line"
          }
        ],
        "optionSvgs": [
          "<svg viewBox=\"0 0 200 75\"><line x1=\"30\" y1=\"62\" x2=\"75\" y2=\"32\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"75\" y1=\"32\" x2=\"170\" y2=\"32\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><circle cx=\"75\" cy=\"32\" r=\"9\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"3\"/></svg>",
          "<svg viewBox=\"0 0 200 75\"><line x1=\"30\" y1=\"62\" x2=\"75\" y2=\"38\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"75\" y1=\"38\" x2=\"170\" y2=\"38\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"75\" y1=\"38\" x2=\"75\" y2=\"12\" stroke=\"#22c55e\" stroke-width=\"2.5\"/><polygon points=\"75,12 96,19 75,26\" fill=\"#22c55e\"/></svg>",
          "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"38\" x2=\"180\" y2=\"38\" stroke=\"#38bdf8\" stroke-width=\"2\"/><polygon points=\"62,38 62,18 82,38\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><polygon points=\"116,38 116,58 136,38\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><text x=\"93\" y=\"44\" fill=\"#22c55e\" font-size=\"16\" font-weight=\"bold\">Z</text></svg>"
        ],
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №10: Weld all-around.",
          "ru": "Таблица 3, №10.",
          "en": "Table 3, No. 10: Weld all-around."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "10. [TESKARI SAVOL] Qaysi belgi 'Montaj choki' (Field weld, №12 — sex tashqarisida) ni bildiradi?",
          "ru": "[ОБРАТНЫЙ ВОПРОС] Какой символ обозначает 'Монтажный шов' (Field weld, Таблица 3, №12)?",
          "en": "[REVERSE] Which symbol represents a 'Field weld' (Table 3, No. 12)?"
        },
        "options": [
          {
            "uz": "A — Kesishish nuqtasidagi bayroqcha (⚑)",
            "ru": "А — Флажок в месте соединения стрелки и полки",
            "en": "A — Flag at junction"
          },
          {
            "uz": "B — Ikki tomonlama strelka (A ↔ B)",
            "ru": "B — Шов между двумя точками (A ↔ B)",
            "en": "B — Between two points (A ↔ B)"
          },
          {
            "uz": "C — Qora yarim doira",
            "ru": "C — Закрашенный полукруг",
            "en": "C — Filled semicircle"
          }
        ],
        "optionSvgs": [
          "<svg viewBox=\"0 0 200 75\"><line x1=\"30\" y1=\"62\" x2=\"75\" y2=\"38\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"75\" y1=\"38\" x2=\"170\" y2=\"38\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"75\" y1=\"38\" x2=\"75\" y2=\"12\" stroke=\"#22c55e\" stroke-width=\"2.5\"/><polygon points=\"75,12 96,19 75,26\" fill=\"#22c55e\"/></svg>",
          "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"42\" x2=\"180\" y2=\"42\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><text x=\"72\" y=\"32\" fill=\"#22c55e\" font-size=\"13\" font-weight=\"bold\">A</text><text x=\"122\" y=\"32\" fill=\"#22c55e\" font-size=\"13\" font-weight=\"bold\">B</text><line x1=\"84\" y1=\"28\" x2=\"118\" y2=\"28\" stroke=\"#22c55e\" stroke-width=\"2\"/><polygon points=\"84,28 90,25 90,31\" fill=\"#22c55e\"/><polygon points=\"118,28 112,25 112,31\" fill=\"#22c55e\"/></svg>",
          "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"40\" x2=\"180\" y2=\"40\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,16 L100,40 L116,16\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><path d=\"M86,40 A14,14 0 0,0 114,40 Z\" fill=\"#22c55e\"/></svg>"
        ],
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №12: Field weld.",
          "ru": "Таблица 3, №12.",
          "en": "Table 3, No. 12: Field weld."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "11. [TESKARI SAVOL] Qaysi belgi 'Ikki nuqta orasidagi uzluksiz chok' (Weld between two points A ↔ B, №11) ni bildiradi?",
          "ru": "[ОБРАТНЫЙ ВОПРОС] Какой символ обозначает 'Шов между двумя точками' (Таблица 3, №11)?",
          "en": "[REVERSE] Which symbol indicates 'Weld between two points' (Table 3, No. 11)?"
        },
        "options": [
          {
            "uz": "A — A ↔ B ikki tomonlama strelka",
            "ru": "А — Двусторонняя стрелка A ↔ B",
            "en": "A — Double-headed arrow A ↔ B"
          },
          {
            "uz": "B — Aylana (○)",
            "ru": "B — Окружность (○)",
            "en": "B — Circle (○)"
          },
          {
            "uz": "C — Kichik kvadrat",
            "ru": "C — Маленький квадрат",
            "en": "C — Small square"
          }
        ],
        "optionSvgs": [
          "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"42\" x2=\"180\" y2=\"42\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><text x=\"72\" y=\"32\" fill=\"#22c55e\" font-size=\"13\" font-weight=\"bold\">A</text><text x=\"122\" y=\"32\" fill=\"#22c55e\" font-size=\"13\" font-weight=\"bold\">B</text><line x1=\"84\" y1=\"28\" x2=\"118\" y2=\"28\" stroke=\"#22c55e\" stroke-width=\"2\"/><polygon points=\"84,28 90,25 90,31\" fill=\"#22c55e\"/><polygon points=\"118,28 112,25 112,31\" fill=\"#22c55e\"/></svg>",
          "<svg viewBox=\"0 0 200 75\"><line x1=\"30\" y1=\"62\" x2=\"75\" y2=\"32\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><line x1=\"75\" y1=\"32\" x2=\"170\" y2=\"32\" stroke=\"#38bdf8\" stroke-width=\"2.5\"/><circle cx=\"75\" cy=\"32\" r=\"9\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"3\"/></svg>",
          "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"42\" x2=\"180\" y2=\"42\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,18 L100,42 L116,18\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><rect x=\"93\" y=\"42\" width=\"14\" height=\"14\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2.5\"/></svg>"
        ],
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №11: Weld between two points.",
          "ru": "Таблица 3, №11.",
          "en": "Table 3, No. 11: Weld between two points."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "12. [TESKARI SAVOL] Qaysi belgi 'Shaxmat tartibidagi uzuq chok' (Staggered intermittent weld, №13) ni bildiradi?",
          "ru": "[ОБРАТНЫЙ ВОПРОС] Какой символ обозначает 'Шахматные прерывистые швы' (Таблица 3, №13)?",
          "en": "[REVERSE] Which symbol represents 'Staggered intermittent welds' (Table 3, No. 13)?"
        },
        "options": [
          {
            "uz": "A — Tokcha chizigʻida Z belgisi",
            "ru": "А — Знак Z по линии полки",
            "en": "A — Z symbol along the reference line"
          },
          {
            "uz": "B — Ajratgich toʻrtburchagi",
            "ru": "B — Прямоугольник разделителя",
            "en": "B — Spacer rectangle"
          },
          {
            "uz": "C — Tekis chiziq",
            "ru": "C — Прямая линия",
            "en": "C — Flat line"
          }
        ],
        "optionSvgs": [
          "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"38\" x2=\"180\" y2=\"38\" stroke=\"#38bdf8\" stroke-width=\"2\"/><polygon points=\"62,38 62,18 82,38\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><polygon points=\"116,38 116,58 136,38\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><text x=\"93\" y=\"44\" fill=\"#22c55e\" font-size=\"16\" font-weight=\"bold\">Z</text></svg>",
          "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"38\" x2=\"180\" y2=\"38\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M86,14 L100,30 L114,14 M86,62 L100,46 L114,62\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2\"/><rect x=\"88\" y=\"31\" width=\"24\" height=\"14\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2.5\"/></svg>",
          "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"52\" x2=\"180\" y2=\"52\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,26 L100,52 L116,26\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><line x1=\"80\" y1=\"20\" x2=\"120\" y2=\"20\" stroke=\"#22c55e\" stroke-width=\"3\"/></svg>"
        ],
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №13: Staggered intermittent welds.",
          "ru": "Таблица 3, №13.",
          "en": "Table 3, No. 13: Staggered intermittent welds."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "13. [TESKARI SAVOL] Qaysi belgi 'Eruvchan qoʻshimcha' (Consumable insert, №9) ni bildiradi?",
          "ru": "[ОБРАТНЫЙ ВОПРОС] Какой символ обозначает 'Плавящуюся вставку' (Таблица 3, №9)?",
          "en": "[REVERSE] Which symbol represents a 'Consumable insert' (Table 3, No. 9)?"
        },
        "options": [
          {
            "uz": "A — Tokcha chizigʻidagi kichik kvadrat",
            "ru": "А — Маленький квадрат на линии полки",
            "en": "A — Small square on reference line"
          },
          {
            "uz": "B — Tokcha oʻrtasidagi keng toʻrtburchak (Spacer)",
            "ru": "B — Прямоугольник по центру полки",
            "en": "B — Centered rectangle (Spacer)"
          },
          {
            "uz": "C — [MR] yozuvli toʻrtburchak",
            "ru": "C — Прямоугольник с надписью MR",
            "en": "C — Rectangle with MR"
          }
        ],
        "optionSvgs": [
          "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"42\" x2=\"180\" y2=\"42\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,18 L100,42 L116,18\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><rect x=\"93\" y=\"42\" width=\"14\" height=\"14\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2.5\"/></svg>",
          "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"38\" x2=\"180\" y2=\"38\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M86,14 L100,30 L114,14 M86,62 L100,46 L114,62\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2\"/><rect x=\"88\" y=\"31\" width=\"24\" height=\"14\" fill=\"none\" stroke=\"#22c55e\" stroke-width=\"2.5\"/></svg>",
          "<svg viewBox=\"0 0 200 75\"><line x1=\"20\" y1=\"40\" x2=\"180\" y2=\"40\" stroke=\"#64748b\" stroke-width=\"2\"/><path d=\"M84,16 L100,40 L116,16\" fill=\"none\" stroke=\"#f59e0b\" stroke-width=\"2.5\"/><rect x=\"82\" y=\"40\" width=\"36\" height=\"18\" fill=\"none\" stroke=\"#ef4444\" stroke-width=\"2.5\"/><text x=\"100\" y=\"53\" fill=\"#ef4444\" font-size=\"11\" font-weight=\"bold\" text-anchor=\"middle\">MR</text></svg>"
        ],
        "correct": 0,
        "explanation": {
          "uz": "3-jadval №9.",
          "ru": "Таблица 3, №9.",
          "en": "Table 3, No. 9: Consumable insert."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "14. Yopiq kontur belgisi (○) qaysi 3 holatda qoʻllanilMAYDI (4.5.2)?",
          "ru": "В каких случаях НЕ применяют обозначение сварки по замкнутому контуру (п. 4.5.2)?",
          "en": "When is the 'weld all-around' symbol NOT used (Clause 4.5.2)?"
        },
        "options": [
          {
            "uz": "Chok bir nuqtada boshlanib tugamasa, chok turi oʻzgarsa yoki chok oʻlchami oʻzgarsa",
            "ru": "Если шов не непрерывный, изменяется тип шва или изменяется размер шва",
            "en": "When the weld is not continuous, weld type changes, or weld size changes"
          },
          {
            "uz": "Toʻrtburchak profilni aylantirib payvandlaganda",
            "ru": "При обварке трубы по периметру",
            "en": "When welding around a rectangular tube"
          },
          {
            "uz": "Burchakli chokda",
            "ru": "При угловом шве",
            "en": "For fillet welds"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.5.2-band.",
          "ru": "Пункт 4.5.2.",
          "en": "Clause 4.5.2."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "15. Teshik yoki truba aylanasi boʻylab uzluksiz payvandlashda yopiq kontur (○) belgisini qoʻyish kerakmi (4.5.2)?",
          "ru": "Требуется ли знак замкнутого контура (○) для швов по окружности отверстия (п. 4.5.2)?",
          "en": "Is the 'weld all-around' symbol required for welds around the circumference of a circular hole/pipe (4.5.2)?"
        },
        "options": [
          {
            "uz": "Yoʻq, talab qilinmaydi",
            "ru": "Нет, не требуется",
            "en": "No, it is not required"
          },
          {
            "uz": "Ha, har doim shart",
            "ru": "Да, всегда требуется",
            "en": "Yes, always required"
          },
          {
            "uz": "Faqat B tizimida shart",
            "ru": "Только в системе В",
            "en": "Only in System B"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4.5.2-band.",
          "ru": "Пункт 4.5.2.",
          "en": "Clause 4.5.2."
        },
        "svg": null
      }
    ]
  },
  {
    "id": "2553-dim",
    "pdfPage": 21,
    "title": {
      "uz": "5. Oʻlchamlar (a, z, s, d, c, n×l(e)), Razdelka (b, α, h) va Ilova B/C (5–7-boʻlimlar) — 12 ta test",
      "ru": "5. Размеры (a, z, s, d, c, n×l(e)), Разделка (b, α, h) и Прил. В/С — 12 тестов",
      "en": "5. Dimensions (a, z, s, d, c, n×l(e)), Joint Prep (b, α, h) & Annex B/C — 12 Questions"
    },
    "theory": {
      "uz": "• Chap tomonda (koʻndalang kesim): a (qalinlik), z (katet), sa (chuqur eritish), d (teshik/nuqta/shpilka diametri), c (tirqish/rolikli chok kengligi), h va s (qirra kesish va erish chuqurligi, masalan h6 s8).\n• Oʻng tomonda (uzunlik): n × l (e) — n = uchastkalar soni, l = har bir uchastka uzunligi, (e) = oraliq masofa.\n• Belgi ichida: b (zazor — 7-jadval), s (qisman toʻldirilgan teshikli chok chuqurligi — 6-jadval №3.2, 4.2).\n• Belgi tashqarisida: α (qirralar ochilish burchagi — 8-jadval, 10-jadval).\n• 7-boʻlim (11-jadval): Ichida X bor toʻrtburchak — talab qilingan sifat darajasi (ISO 5817) boʻyicha uchma-uch chok.\n• Ilova B (1-jadval): Burchak α diapazonlari — Butt (135°–180°), Fillet (>30° va <135°), Edge (0°–30°), Lap (0°–5°).\n• Ilova C: AWS/JIS uzuq chok yozuvi 'l - e' (bu yerda e — markazlar orasidagi qadam / pitch).",
      "ru": "• Слева от символа: a, z, sa, d (диаметр), c (ширина прорези/роликового шва), h и s (глубина разделки и проплавления, напр. h6s8).\n• Справа от символа: n × l (e).\n• Внутри символа: b (зазор), s (глубина неполного заполнения пробочного шва).\n• Снаружи символа: угол разделки α (например, 50°).\n• Раздел 7 (Табл. 11): Прямоугольник с крестом (X) — по требуемому качеству.\n• Приложение В: Стыковое 135°–180°; угловое >30° и <135°; торцевое 0°–30°; нахлесточное 0°–5°.",
      "en": "• Left of symbol: a, z, sa, d (diameter), c (width), h & s (prep depth & penetration depth, e.g., h6 s8).\n• Right of symbol: n × l (e).\n• Inside symbol: b (root gap), s (partial fill depth for plug/slot welds).\n• Outside symbol: bevel/groove angle α.\n• Section 7 (Table 11): Box with 'X' — alternative butt weld symbol based on required quality.\n• Annex B: Butt 135°–180°; Fillet >30° and <135°; Edge 0°–30°; Lap 0°–5°."
    },
    "items": [],
    "quiz": [
      {
        "question": {
          "uz": "1. Burchakli chokda chuqur eritish qalinligi 's' va nominal qalinlik 'a' birga qanday tartibda yoziladi (5.5.2, 6-jadval №2.2)?",
          "ru": "В каком порядке записываются 's' и 'a' для углового шва с глубоким проплавлением (п. 5.5.2)?",
          "en": "How are 's' and 'a' ordered for a deep-penetration fillet weld (Clause 5.5.2, Table 6 No. 2.2)?"
        },
        "options": [
          {
            "uz": "s birinchi, keyin a (masalan, s8 a6)",
            "ru": "Буква s перед номинальной толщиной a (например, s8 a6)",
            "en": "'s' placed in front of 'a' (e.g., s8 a6)"
          },
          {
            "uz": "a birinchi, keyin s",
            "ru": "Сначала a, потом s",
            "en": "'a' before 's'"
          },
          {
            "uz": "a + s koʻrinishida",
            "ru": "В виде a + s",
            "en": "As a + s"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "5.5.2-band: s harfi a dan oldin qoʻyiladi.",
          "ru": "Пункт 5.5.2: Букву s проставляют перед номинальной толщиной а.",
          "en": "Clause 5.5.2: 's' is placed in front of 'a'."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "2. Teshikli chokda (6-jadval №3.2) qisman toʻldirish chuqurligi 's' qayerga yoziladi?",
          "ru": "Где указывается глубина неполного заполнения 's' пробочного шва (Табл. 6, №3.2)?",
          "en": "Where is partial filling depth 's' placed for a plug weld (Table 6, No. 3.2)?"
        },
        "options": [
          {
            "uz": "Toʻrtburchak belgining ICHIGA",
            "ru": "Внутри начального обозначения (прямоугольника)",
            "en": "Inside the elementary symbol"
          },
          {
            "uz": "Chap tomonga 'd' dan oldin",
            "ru": "Слева перед диаметром d",
            "en": "To the left before 'd'"
          },
          {
            "uz": "Oʻng tomonga",
            "ru": "Справа от символа",
            "en": "To the right"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "5.6-band.",
          "ru": "Пункт 5.6.",
          "en": "Clause 5.6."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3. Choʻzinchoq tirqishli chokda (slot weld, 5.7) tirqish kengligi qaysi harf bilan belgilanadi?",
          "ru": "Какой буквой обозначается ширина продолговатого отверстия (прорези) (п. 5.7)?",
          "en": "Which letter designates the width of a slot weld (Clause 5.7)?"
        },
        "options": [
          {
            "uz": "c",
            "ru": "c",
            "en": "c"
          },
          {
            "uz": "d",
            "ru": "d",
            "en": "d"
          },
          {
            "uz": "b",
            "ru": "b",
            "en": "b"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "5.7-band: c — tirqish va rolikli chok kengligi.",
          "ru": "Пункт 5.7: c — ширина прорези.",
          "en": "Clause 5.7: 'c' = width."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "4. Qirra chok (edge weld, 5.10) va Qoplama eritish (surfacing, 5.12) qalinligi chap tomonda qaysi harf bilan yoziladi?",
          "ru": "Какой буквой обозначается толщина торцевого шва (п. 5.10) и наплавки (п. 5.12)?",
          "en": "Which letter designates weld thickness for edge welds (5.10) and surfacing (5.12)?"
        },
        "options": [
          {
            "uz": "s",
            "ru": "s",
            "en": "s"
          },
          {
            "uz": "a",
            "ru": "a",
            "en": "a"
          },
          {
            "uz": "z",
            "ru": "z",
            "en": "z"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "5.10 va 5.12-bandlar, 6-jadval №7.1 va №9.1: s harfi bilan yoziladi.",
          "ru": "Пункты 5.10 и 5.12, Таблица 6 №7.1 и №9.1.",
          "en": "Clauses 5.10 & 5.12, Table 6 No. 7.1 & 9.1: 's'."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "5. Zazor 'b' (7-jadval) shartli belgining qayeriga yoziladi?",
          "ru": "Где указывается зазор 'b' стыкового соединения (Таблица 7)?",
          "en": "Where is root gap 'b' placed (Table 7)?"
        },
        "options": [
          {
            "uz": "Boshlangʻich belgining ICHIGA",
            "ru": "Внутри начального обозначения",
            "en": "Inside the elementary symbol"
          },
          {
            "uz": "Belgining chap tomoniga",
            "ru": "Слева от символа",
            "en": "Left of symbol"
          },
          {
            "uz": "Dum qismiga",
            "ru": "В хвосте",
            "en": "In the tail"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "6.2-band.",
          "ru": "Пункт 6.2.",
          "en": "Clause 6.2."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "6. Qirralar ochilish burchagi α (8-jadval) shartli belgining qayeriga yoziladi?",
          "ru": "Где указывается угол разделки кромок α (Таблица 8)?",
          "en": "Where is groove/bevel angle α placed (Table 8)?"
        },
        "options": [
          {
            "uz": "Boshlangʻich belgining TASHQARISIGA",
            "ru": "Вне начального обозначения",
            "en": "Outside the elementary symbol"
          },
          {
            "uz": "Belgining ichiga",
            "ru": "Внутри символа",
            "en": "Inside the symbol"
          },
          {
            "uz": "Chap tomonga",
            "ru": "Слева",
            "en": "To the left"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "6.3-band.",
          "ru": "Пункт 6.3.",
          "en": "Clause 6.3."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "7. U- va J-simon razdelkalarning radiusi va toʻmtoqligi shartli belgining oʻziga yoziladimi (6.4)?",
          "ru": "Указываются ли радиусы и притупления U- и J-разделок на самом условном обозначении (п. 6.4)?",
          "en": "Are radii and root faces of U- and J-grooves shown on the welding symbol (Clause 6.4)?"
        },
        "options": [
          {
            "uz": "Yoʻq, koʻndalang kesimda yoki ISO 9692 havolasi orqali beriladi",
            "ru": "Нет, указываются на сечении или ссылкой на ИСО 9692",
            "en": "No, shown on cross-section or via ISO 9692 reference"
          },
          {
            "uz": "Ha, belgi ichiga yoziladi",
            "ru": "Да, внутри символа",
            "en": "Yes, inside symbol"
          },
          {
            "uz": "Ha, chap tomonga yoziladi",
            "ru": "Да, слева",
            "en": "Yes, on the left"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "6.4-band.",
          "ru": "Пункт 6.4.",
          "en": "Clause 6.4."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "8. 'h6 s8' yozuvida (9-jadval) 'h' va 's' nimani bildiradi?",
          "ru": "Что означают буквы 'h' и 's' в записи 'h6 s8' (Таблица 9)?",
          "en": "What do 'h' and 's' mean in 'h6 s8' (Table 9)?"
        },
        "options": [
          {
            "uz": "h = qirra kesish chuqurligi (6 mm), s = erish chuqurligi (8 mm)",
            "ru": "h = глубина разделки кромок (6 мм), s = глубина проплавления (8 мм)",
            "en": "h = preparation depth (6 mm), s = penetration depth (8 mm)"
          },
          {
            "uz": "h = balandlik, s = uzunlik",
            "ru": "h = высота, s = длина",
            "en": "h = height, s = length"
          },
          {
            "uz": "h = elektrod, s = tok",
            "ru": "h = электрод, s = ток",
            "en": "h = electrode, s = current"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "6.5-band.",
          "ru": "Пункт 6.5.",
          "en": "Clause 6.5."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "9. 7-boʻlim (11-jadval) dagi ichida 'X' bor toʻrtburchak belgisi faqat qaysi chok turi uchun qoʻllaniladi?",
          "ru": "Только для каких швов допускается применять альтернативное обозначение с крестом (X) (п. 7.1)?",
          "en": "For which weld type ONLY is the alternative 'X'-box symbol permitted (Clause 7.1)?"
        },
        "options": [
          {
            "uz": "Faqat uchma-uch choklar (butt welds) uchun",
            "ru": "Только для стыковых швов",
            "en": "Only for butt welds"
          },
          {
            "uz": "Faqat burchakli choklar uchun",
            "ru": "Только для угловых швов",
            "en": "Only for fillet welds"
          },
          {
            "uz": "Faqat nuqtali choklar uchun",
            "ru": "Только для точечных швов",
            "en": "Only for spot welds"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "7.1-band.",
          "ru": "Пункт 7.1.",
          "en": "Clause 7.1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "10. Ilova B ga koʻra, burchakli birikma (Fillet joint) uchun ikki detal orasidagi burchak α necha gradus oraligʻida boʻladi?",
          "ru": "В каком диапазоне угла α соединение считается угловым согласно Приложению В?",
          "en": "What is the angle α range for a fillet joint according to Annex B?"
        },
        "options": [
          {
            "uz": "30° dan katta va 135° dan kichik (>30° and <135°)",
            "ru": "Свыше 30° и менее 135°",
            "en": "Greater than 30° and less than 135°"
          },
          {
            "uz": "135° dan 180° gacha",
            "ru": "От 135° до 180°",
            "en": "135° to 180°"
          },
          {
            "uz": "0° dan 5° gacha",
            "ru": "От 0° до 5°",
            "en": "0° to 5°"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "Ilova B.",
          "ru": "Приложение В.",
          "en": "Annex B."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "11. Ilova B ga koʻra, ustma-ust birikma (Lap joint) va qirra birikma (Edge joint) burchak α chegaralari qancha?",
          "ru": "Каковы углы α для нахлесточного и торцевого соединений в Приложении В?",
          "en": "What are the α angle limits for Lap and Edge joints in Annex B?"
        },
        "options": [
          {
            "uz": "Lap (ustma-ust): 0°–5°; Edge (qirra): 0°–30°",
            "ru": "Нахлесточное: 0°–5°; Торцевое: 0°–30°",
            "en": "Lap: 0° to 5° inclusive; Edge: 0° to 30° inclusive"
          },
          {
            "uz": "Lap: 45°–90°; Edge: 90°–135°",
            "ru": "Нахлесточное: 45°–90°",
            "en": "Lap: 45°–90°"
          },
          {
            "uz": "Ikkalasi ham 90°",
            "ru": "Оба по 90°",
            "en": "Both 90°"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "Ilova B.",
          "ru": "Приложение В.",
          "en": "Annex B."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "12. Ilova C (AWS/JIS usuli) boʻyicha 'l - e' yozuvida 'e' nimani bildiradi?",
          "ru": "Что обозначает 'e' в записи 'l - e' по альтернативному методу Приложения С?",
          "en": "What does 'e' represent in 'l - e' under Annex C?"
        },
        "options": [
          {
            "uz": "Qoʻshni chok uchastkalari MARKAZLARI orasidagi qadam (pitch)",
            "ru": "Шаг между центрами соседних участков шва",
            "en": "Pitch (distance between centres of adjacent weld elements)"
          },
          {
            "uz": "Choklar orasidagi boʻsh masofa",
            "ru": "Промежуток между участками",
            "en": "Clear spacing"
          },
          {
            "uz": "Chok qalinligi",
            "ru": "Толщина шва",
            "en": "Weld thickness"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "Ilova C (C.2.1).",
          "ru": "Приложение С.",
          "en": "Annex C (C.2.1)."
        },
        "svg": null
      }
    ]
  }
];
