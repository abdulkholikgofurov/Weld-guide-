export const iso6947Topics = [
  {
    "id": "6947-main",
    "pdfPage": 6,
    "title": {
      "uz": "1. Barcha asosiy holatlar (PA – PK) va Burchaklar (S, R, L) — 12 ta test",
      "ru": "1. Все основные положения (PA – PK) и Углы (S, R, L) — 12 тестов",
      "en": "1. All Main Positions (PA – PK) & Angles (S, R, L) — 12 Questions"
    },
    "theory": {
      "uz": "• PA (0°): pastki holat (flat position)\n• PB (45°/315°): tavr gorizontal (horizontal vertical position)\n• PC (90°/270°): gorizontal holat (horizontal position)\n• PD (135°/225°): tavr shift holati (horizontal overhead position)\n• PE (180°): shift holati (overhead position)\n• PF: vertikal pastdan yuqoriga (vertical up) | PG: vertikal yuqoridan pastga (vertical down)\n• PH: qoʻzgʻalmas gorizontal quvur pastdan yuqoriga | PJ: qoʻzgʻalmas gorizontal quvur yuqoridan pastga\n• PK: orbital payvandlash (orbital welding)\n• S (slope): chok oʻqi nishabligi | R (rotation): chok yuzasi burilishi | L (inclined angle): quvur oʻqi qiyaligi.",
      "ru": "• PA (0°): нижнее | PB (45°/315°): горизонтальное тавровое | PC (90°/270°): горизонтальное | PD (135°/225°): потолочное тавровое | PE (180°): потолочное\n• PF: вертикальное снизу вверх | PG: вертикальное сверху вниз\n• PH: неповоротная труба снизу вверх | PJ: неповоротная труба сверху вниз | PK: орбитальная сварка\n• S: наклон оси шва | R: поворот лицевой поверхности | L: угол наклона оси трубы.",
      "en": "• PA (0°): flat | PB (45°/315°): horizontal vertical | PC (90°/270°): horizontal | PD (135°/225°): horizontal overhead | PE (180°): overhead\n• PF: vertical up | PG: vertical down\n• PH: fixed pipe vertical up | PJ: fixed pipe vertical down | PK: orbital welding\n• S: slope of weld axis | R: rotation of weld face | L: inclined angle of pipe axis."
    },
    "items": [],
    "quiz": [
      {
        "question": {
          "uz": "1. 0° burchak (1-rasm, 1-pozitsiya) qaysi asosiy holatni bildiradi?",
          "ru": "Какое положение соответствует 0° на Рисунке 1?",
          "en": "Which main position corresponds to 0° in Figure 1?"
        },
        "options": [
          {
            "uz": "PA (Pastki holat / Flat)",
            "ru": "PA (Нижнее положение)",
            "en": "PA (Flat position)"
          },
          {
            "uz": "PB",
            "ru": "PB",
            "en": "PB"
          },
          {
            "uz": "PE",
            "ru": "PE",
            "en": "PE"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-rasm.",
          "ru": "Рисунок 1.",
          "en": "Figure 1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "2. 45° va 315° burchaklar (1-rasm, 2 va 8-pozitsiyalar) qaysi holat?",
          "ru": "Какому положению соответствуют 45° и 315° (Рис. 1)?",
          "en": "Which position corresponds to 45° and 315° (Figure 1)?"
        },
        "options": [
          {
            "uz": "PB (Tavr va vertikal quvurda gorizontal)",
            "ru": "PB (Горизонтальное тавровых соединений)",
            "en": "PB (Horizontal vertical position)"
          },
          {
            "uz": "PD",
            "ru": "PD",
            "en": "PD"
          },
          {
            "uz": "PC",
            "ru": "PC",
            "en": "PC"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-rasm.",
          "ru": "Рисунок 1.",
          "en": "Figure 1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3. 90° va 270° burchaklar (1-rasm, 3 va 7-pozitsiyalar) qaysi holat?",
          "ru": "Какому положению соответствуют 90° и 270° (Рис. 1)?",
          "en": "Which position corresponds to 90° and 270° (Figure 1)?"
        },
        "options": [
          {
            "uz": "PC (Gorizontal holat)",
            "ru": "PC (Горизонтальное положение)",
            "en": "PC (Horizontal position)"
          },
          {
            "uz": "PB",
            "ru": "PB",
            "en": "PB"
          },
          {
            "uz": "PA",
            "ru": "PA",
            "en": "PA"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-rasm.",
          "ru": "Рисунок 1.",
          "en": "Figure 1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "4. 135° va 225° burchaklar (1-rasm, 4 va 6-pozitsiyalar) qaysi holat?",
          "ru": "Какому положению соответствуют 135° и 225° (Рис. 1)?",
          "en": "Which position corresponds to 135° and 225° (Figure 1)?"
        },
        "options": [
          {
            "uz": "PD (Tavr va vertikal quvurda shift holati)",
            "ru": "PD (Потолочное тавровых соединений)",
            "en": "PD (Horizontal overhead position)"
          },
          {
            "uz": "PE",
            "ru": "PE",
            "en": "PE"
          },
          {
            "uz": "PB",
            "ru": "PB",
            "en": "PB"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-rasm.",
          "ru": "Рисунок 1.",
          "en": "Figure 1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "5. 180° burchak (1-rasm, 5-pozitsiya) qaysi holat?",
          "ru": "Какому положению соответствует 180° (Рис. 1)?",
          "en": "Which position corresponds to 180° (Figure 1)?"
        },
        "options": [
          {
            "uz": "PE (Shift holati / Overhead)",
            "ru": "PE (Потолочное положение)",
            "en": "PE (Overhead position)"
          },
          {
            "uz": "PD",
            "ru": "PD",
            "en": "PD"
          },
          {
            "uz": "PA",
            "ru": "PA",
            "en": "PA"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-rasm.",
          "ru": "Рисунок 1.",
          "en": "Figure 1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "6. Vertikal chokni PASTDAN YUQORIGA (vertical up) payvandlash qanday belgilanadi?",
          "ru": "Как обозначается вертикальная сварка СНИЗУ ВВЕРХ?",
          "en": "How is vertical-up welding designated?"
        },
        "options": [
          {
            "uz": "PF",
            "ru": "PF",
            "en": "PF"
          },
          {
            "uz": "PG",
            "ru": "PG",
            "en": "PG"
          },
          {
            "uz": "PH",
            "ru": "PH",
            "en": "PH"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "2-rasm f).",
          "ru": "Рисунок 2 f).",
          "en": "Figure 2 f)."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "7. Vertikal chokni YUQORIDAN PASTGA (vertical down) payvandlash qanday belgilanadi?",
          "ru": "Как обозначается вертикальная сварка СВЕРХУ ВНИЗ?",
          "en": "How is vertical-down welding designated?"
        },
        "options": [
          {
            "uz": "PG",
            "ru": "PG",
            "en": "PG"
          },
          {
            "uz": "PF",
            "ru": "PF",
            "en": "PF"
          },
          {
            "uz": "PJ",
            "ru": "PJ",
            "en": "PJ"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "2-rasm g).",
          "ru": "Рисунок 2 g).",
          "en": "Figure 2 g)."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "8. Qoʻzgʻalmas gorizontal quvurda PASTDAN YUQORIGA payvandlash qanday belgilanadi?",
          "ru": "Как обозначается сварка неповоротной горизонтальной трубы СНИЗУ ВВЕРХ?",
          "en": "How is fixed horizontal pipe welding vertical-up designated?"
        },
        "options": [
          {
            "uz": "PH",
            "ru": "PH",
            "en": "PH"
          },
          {
            "uz": "PJ",
            "ru": "PJ",
            "en": "PJ"
          },
          {
            "uz": "PK",
            "ru": "PK",
            "en": "PK"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "2-rasm h).",
          "ru": "Рисунок 2 h).",
          "en": "Figure 2 h)."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "9. Qoʻzgʻalmas gorizontal quvurda YUQORIDAN PASTGA payvandlash qanday belgilanadi?",
          "ru": "Как обозначается сварка неповоротной горизонтальной трубы СВЕРХУ ВНИЗ?",
          "en": "How is fixed horizontal pipe welding vertical-down designated?"
        },
        "options": [
          {
            "uz": "PJ",
            "ru": "PJ",
            "en": "PJ"
          },
          {
            "uz": "PH",
            "ru": "PH",
            "en": "PH"
          },
          {
            "uz": "PG",
            "ru": "PG",
            "en": "PG"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "2-rasm i).",
          "ru": "Рисунок 2 i).",
          "en": "Figure 2 i)."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "10. Quvurni orbital payvandlash (orbital welding) qanday belgilanadi?",
          "ru": "Как обозначается положение трубы при орбитальной сварке?",
          "en": "How is the pipe position for orbital welding designated?"
        },
        "options": [
          {
            "uz": "PK",
            "ru": "PK",
            "en": "PK"
          },
          {
            "uz": "PH",
            "ru": "PH",
            "en": "PH"
          },
          {
            "uz": "PA",
            "ru": "PA",
            "en": "PA"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "2-rasm j).",
          "ru": "Рисунок 2 j).",
          "en": "Figure 2 j)."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "11. 'S' (slope) va 'R' (rotation) harflari nimani bildiradi (2.3, 2.4)?",
          "ru": "Что означают 'S' и 'R' (п. 2.3, 2.4)?",
          "en": "What do 'S' and 'R' mean (Clauses 2.3, 2.4)?"
        },
        "options": [
          {
            "uz": "S — chok oʻqi nishabligi; R — chok yuzasi burilishi",
            "ru": "S — угол наклона оси шва; R — угол поворота лицевой поверхности шва",
            "en": "S = slope of weld axis; R = rotation of weld face"
          },
          {
            "uz": "S — quvur burchagi; R — radius",
            "ru": "S — угол трубы; R — радиус",
            "en": "S = pipe angle; R = radius"
          },
          {
            "uz": "S — tezlik; R — tok",
            "ru": "S — скорость; R — ток",
            "en": "S = speed; R = current"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "2.3 va 2.4-bandlar.",
          "ru": "Пункты 2.3 и 2.4.",
          "en": "Clauses 2.3 & 2.4."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "12. 'L' (inclined angle, 2.5) qaysi burchak?",
          "ru": "Что такое 'L' (inclined angle, п. 2.5)?",
          "en": "What is 'inclined angle L' (Clause 2.5)?"
        },
        "options": [
          {
            "uz": "Quvur oʻqining qiyalik burchagi",
            "ru": "Угол наклона оси трубы",
            "en": "Angle of inclination of the pipe axis"
          },
          {
            "uz": "Chok uzunligi",
            "ru": "Длина шва",
            "en": "Weld length"
          },
          {
            "uz": "Katet oʻlchami",
            "ru": "Размер катета",
            "en": "Leg size"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "2.5-band.",
          "ru": "Пункт 2.5.",
          "en": "Clause 2.5."
        },
        "svg": null
      }
    ]
  },
  {
    "id": "6947-angles",
    "pdfPage": 10,
    "title": {
      "uz": "2. Sinov va Ishlab chiqarish ruxsatlari (1–2-jadvallar) va Qiya quvurlar — 9 ta test",
      "ru": "2. Допуски испытаний и производства (Табл. 1–2) и Наклонные трубы — 9 тестов",
      "en": "2. Test & Production Tolerances (Tables 1–2) & Inclined Pipes — 9 Questions"
    },
    "theory": {
      "uz": "• Sinov namunalari (3.3): S = ±5°, R = ±10°.\n• Ishlab chiqarish PA: S = ±15°, R = ±30°.\n• PB (burchakli): S = ±15°, R = +15°/−10°.\n• PC (uchma-uch): S = ±15°, R = +60°/−10° | PC (burchakli): S = ±15°, R = +35°/−10°.\n• PD (burchakli): S = ±80°, R = +35°/−10°.\n• PE (uchma-uch): S = ±80°, R = ±80° | PE (burchakli): S = ±80°, R = +35°/−10°.\n• PF, PG: S = +75°/−10°, R = ±100° / ±180°.\n• '+' = PA tomon burilish; '−' = PE tomon burilish.\n• Misollar: PB 015-010, H-L030, J-L060.",
      "ru": "• Испытания (п. 3.3): S = ±5°, R = ±10°.\n• Производство PA: S = ±15°, R = ±30°.\n• PB (угловой): S = ±15°, R = +15°/−10°.\n• PC (стыковой): S = ±15°, R = +60°/−10° | PC (угловой): S = ±15°, R = +35°/−10°.\n• PD (угловой): S = ±80°, R = +35°/−10°.\n• PE (стыковой): S = ±80°, R = ±80° | PE (угловой): S = ±80°, R = +35°/−10°.\n• PF, PG: S = +75°/−10°, R = ±100° / ±180°.",
      "en": "• Test pieces (3.3): S = ±5°, R = ±10°.\n• Production PA: S = ±15°, R = ±30°.\n• PB (fillet): S = ±15°, R = +15°/−10°.\n• PC (butt): S = ±15°, R = +60°/−10° | PC (fillet): S = ±15°, R = +35°/−10°.\n• PD (fillet): S = ±80°, R = +35°/−10°.\n• PE (butt): S = ±80°, R = ±80° | PE (fillet): S = ±80°, R = +35°/−10°.\n• PF, PG: S = +75°/−10°, R = ±100° / ±180°."
    },
    "items": [],
    "quiz": [
      {
        "question": {
          "uz": "1. Sinov namunalarini payvandlashda (3.3-band) S va R ogʻishlari necha gradus?",
          "ru": "Каковы допуски S и R при сварке испытательных образцов (п. 3.3)?",
          "en": "What are the S and R tolerances for welding test pieces (Clause 3.3)?"
        },
        "options": [
          {
            "uz": "S = ±5°, R = ±10°",
            "ru": "S = ±5°, R = ±10°",
            "en": "S = ±5°, R = ±10°"
          },
          {
            "uz": "S = ±15°, R = ±30°",
            "ru": "S = ±15°, R = ±30°",
            "en": "S = ±15°, R = ±30°"
          },
          {
            "uz": "0°",
            "ru": "0°",
            "en": "0°"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.3-band.",
          "ru": "Пункт 3.3.",
          "en": "Clause 3.3."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "2. Assimmetrik ruxsatlarda '+' va '−' ishoralari qaysi holatlar tomon burilishni bildiradi (3.2 izoh)?",
          "ru": "В сторону каких основных положений направлен поворот при знаках «+» и «−» (п. 3.2)?",
          "en": "Towards which positions do '+' and '−' rotations point (Note to 3.2)?"
        },
        "options": [
          {
            "uz": "'+': PA (pastki) tomon; '−': PE (shift) tomon",
            "ru": "«+» — в сторону PA; «−» — в сторону PE",
            "en": "'+' = towards PA; '−' = towards PE"
          },
          {
            "uz": "'+': PF tomon; '−': PG tomon",
            "ru": "В сторону PF и PG",
            "en": "Towards PF and PG"
          },
          {
            "uz": "'+': chapga; '−': oʻngga",
            "ru": "Влево и вправо",
            "en": "Left and right"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "3.2 izoh.",
          "ru": "Примечание к 3.2.",
          "en": "Note to 3.2."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3. Ishlab chiqarishda PA holati uchun S va R chegaralari (1 va 2-jadvallar) qancha?",
          "ru": "Каковы пределы S и R для нижнего положения PA в производстве (Табл. 1 и 2)?",
          "en": "What are the S and R limits for PA in production (Tables 1 & 2)?"
        },
        "options": [
          {
            "uz": "S = ±15°, R = ±30°",
            "ru": "S = ±15°, R = ±30°",
            "en": "S = ±15°, R = ±30°"
          },
          {
            "uz": "S = ±5°, R = ±10°",
            "ru": "S = ±5°, R = ±10°",
            "en": "S = ±5°, R = ±10°"
          },
          {
            "uz": "S = ±80°, R = ±80°",
            "ru": "S = ±80°, R = ±80°",
            "en": "S = ±80°, R = ±80°"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1 va 2-jadvallar.",
          "ru": "Таблицы 1 и 2.",
          "en": "Tables 1 & 2."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "4. Burchakli chokda PB holati uchun burilish R chegarasi (2-jadval) qancha?",
          "ru": "Каковы пределы поворота R для углового шва в положении PB (Таблица 2)?",
          "en": "What are the rotation (R) limits for fillet welds in PB (Table 2)?"
        },
        "options": [
          {
            "uz": "+15° / −10°",
            "ru": "+15° / −10°",
            "en": "+15° / −10°"
          },
          {
            "uz": "+60° / −10°",
            "ru": "+60° / −10°",
            "en": "+60° / −10°"
          },
          {
            "uz": "±80°",
            "ru": "±80°",
            "en": "±80°"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "2-jadval.",
          "ru": "Таблица 2.",
          "en": "Table 2."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "5. Uchma-uch PC holati vs Burchakli PC holatida burilish R chegaralari qanday farqlanadi?",
          "ru": "В чем разница пределов поворота R для стыкового PC (Табл. 1) и углового PC (Табл. 2)?",
          "en": "How do rotation (R) limits differ between butt PC (Table 1) and fillet PC (Table 2)?"
        },
        "options": [
          {
            "uz": "Uchma-uch PC: +60°/−10°; Burchakli PC: +35°/−10°",
            "ru": "Стыковой PC: +60°/−10°; Угловой PC: +35°/−10°",
            "en": "Butt PC: +60°/−10°; Fillet PC: +35°/−10°"
          },
          {
            "uz": "Ikkalasi ham ±30°",
            "ru": "Оба по ±30°",
            "en": "Both ±30°"
          },
          {
            "uz": "Ikkalasi ham ±80°",
            "ru": "Оба по ±80°",
            "en": "Both ±80°"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1 va 2-jadvallar.",
          "ru": "Таблицы 1 и 2.",
          "en": "Tables 1 & 2."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "6. Uchma-uch PE holatida S va R chegaralari (1-jadval) qancha?",
          "ru": "Каковы пределы S и R для потолочного положения PE стыковых швов (Таблица 1)?",
          "en": "What are the S and R limits for PE butt welds (Table 1)?"
        },
        "options": [
          {
            "uz": "S = ±80°, R = ±80°",
            "ru": "S = ±80°, R = ±80°",
            "en": "S = ±80°, R = ±80°"
          },
          {
            "uz": "S = ±15°, R = ±30°",
            "ru": "S = ±15°, R = ±30°",
            "en": "S = ±15°, R = ±30°"
          },
          {
            "uz": "S = ±5°, R = ±10°",
            "ru": "S = ±5°, R = ±10°",
            "en": "S = ±5°, R = ±10°"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "1-jadval.",
          "ru": "Таблица 1.",
          "en": "Table 1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "7. 'PB 015-010' belgisi nimani bildiradi (4-boʻlim, 2-misol)?",
          "ru": "Что означает обозначение 'PB 015-010' (Раздел 4, Пример 2)?",
          "en": "What does 'PB 015-010' mean (Section 4, Example 2)?"
        },
        "options": [
          {
            "uz": "PB asosiy holati + 15° nishab (S) + 10° burilish (R)",
            "ru": "Основное положение PB с наклоном 15° и поворотом 10°",
            "en": "Main position PB with 15° slope and 10° rotation"
          },
          {
            "uz": "150 mm uzunlik va 10 mm qalinlik",
            "ru": "Длина 150 мм и толщина 10 мм",
            "en": "150 mm length and 10 mm thickness"
          },
          {
            "uz": "15 ta chok",
            "ru": "15 швов",
            "en": "15 welds"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4-boʻlim, 2-misol.",
          "ru": "Раздел 4, Пример 2.",
          "en": "Section 4, Example 2."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "8. 'H-L030' belgisi nimani bildiradi (4-boʻlim, 3-misol)?",
          "ru": "Что означает обозначение 'H-L030' (Раздел 4, Пример 3)?",
          "en": "What does 'H-L030' mean (Section 4, Example 3)?"
        },
        "options": [
          {
            "uz": "30° qiya oʻqli quvurda pastdan yuqoriga (H) payvandlash",
            "ru": "Сварка трубы с наклонной осью 30° снизу вверх (H)",
            "en": "Inclined pipe at 30° welded vertical up (H)"
          },
          {
            "uz": "Yuqoridan pastga 30°",
            "ru": "Сверху вниз 30°",
            "en": "Vertical down 30°"
          },
          {
            "uz": "30 mm truba",
            "ru": "Труба 30 мм",
            "en": "30 mm pipe"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4-boʻlim, 3-misol.",
          "ru": "Раздел 4, Пример 3.",
          "en": "Section 4, Example 3."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "9. 'J-L060' belgisi nimani bildiradi (4-boʻlim, 4-misol)?",
          "ru": "Что означает обозначение 'J-L060' (Раздел 4, Пример 4)?",
          "en": "What does 'J-L060' mean (Section 4, Example 4)?"
        },
        "options": [
          {
            "uz": "60° qiya oʻqli quvurda yuqoridan pastga (J) payvandlash",
            "ru": "Сварка трубы с наклонной осью 60° сверху вниз (J)",
            "en": "Inclined pipe at 60° welded vertical down (J)"
          },
          {
            "uz": "Pastdan yuqoriga 60°",
            "ru": "Снизу вверх 60°",
            "en": "Vertical up 60°"
          },
          {
            "uz": "Gorizontal 60°",
            "ru": "Горизонтально 60°",
            "en": "Horizontal 60°"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "4-boʻlim, 4-misol.",
          "ru": "Раздел 4, Пример 4.",
          "en": "Section 4, Example 4."
        },
        "svg": null
      }
    ]
  },
  {
    "id": "6947-aws",
    "pdfPage": 17,
    "title": {
      "uz": "3. ISO 6947 va AWS / ASME (1G–6G, 1F–5F, 1FR, 2FR) — 9 ta test",
      "ru": "3. Сравнение ISO 6947 и AWS / ASME (1G–6G, 1F–5F, 1FR, 2FR) — 9 тестов",
      "en": "3. ISO 6947 vs AWS / ASME (1G–6G, 1F–5F, 1FR, 2FR) — 9 Questions"
    },
    "theory": {
      "uz": "B.1-jadval: 1G/1F/1FR = PA | 2G = PC | 2F/2FR = PB | 3G/3F uphill = PF | 3G/3F downhill = PG | 4G = PE | 4F = PD | 5G/5F uphill = PH | 5G/5F downhill = PJ | 6G uphill = H-L045 | 6G downhill = J-L045.",
      "ru": "Таблица В.1: 1G/1F/1FR = PA | 2G = PC | 2F/2FR = PB | 3G/3F uphill = PF | 3G/3F downhill = PG | 4G = PE | 4F = PD | 5G/5F uphill = PH | 5G/5F downhill = PJ | 6G uphill = H-L045 | 6G downhill = J-L045.",
      "en": "Table B.1: 1G/1F/1FR = PA | 2G = PC | 2F/2FR = PB | 3G/3F uphill = PF | 3G/3F downhill = PG | 4G = PE | 4F = PD | 5G/5F uphill = PH | 5G/5F downhill = PJ | 6G uphill = H-L045 | 6G downhill = J-L045."
    },
    "items": [],
    "quiz": [
      {
        "question": {
          "uz": "1. AWS/ASME '1G' va '1FR' holatlari ISO 6947 da qanday belgilanadi?",
          "ru": "Какому положению ИСО 6947 соответствуют '1G' и '1FR'?",
          "en": "Which ISO 6947 position corresponds to '1G' and '1FR'?"
        },
        "options": [
          {
            "uz": "PA",
            "ru": "PA",
            "en": "PA"
          },
          {
            "uz": "PB",
            "ru": "PB",
            "en": "PB"
          },
          {
            "uz": "PC",
            "ru": "PC",
            "en": "PC"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "B.1-jadval.",
          "ru": "Таблица В.1.",
          "en": "Table B.1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "2. AWS/ASME '2G' va '2F / 2FR' holatlari ISO 6947 da qaysi belgilarga teng?",
          "ru": "Каким обозначениям ИСО 6947 соответствуют '2G' и '2F / 2FR'?",
          "en": "Which ISO 6947 designations match '2G' and '2F / 2FR'?"
        },
        "options": [
          {
            "uz": "2G = PC; 2F / 2FR = PB",
            "ru": "2G = PC; 2F / 2FR = PB",
            "en": "2G = PC; 2F / 2FR = PB"
          },
          {
            "uz": "2G = PB; 2F = PC",
            "ru": "2G = PB; 2F = PC",
            "en": "2G = PB; 2F = PC"
          },
          {
            "uz": "Ikkalasi ham PA",
            "ru": "Оба PA",
            "en": "Both PA"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "B.1-jadval.",
          "ru": "Таблица В.1.",
          "en": "Table B.1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "3. AWS/ASME '3G uphill' va '3F downhill' mos ravishda ISO 6947 da nima boʻladi?",
          "ru": "Чему соответствуют '3G uphill' и '3F downhill' в ИСО 6947?",
          "en": "What are the ISO 6947 equivalents of '3G uphill' and '3F downhill'?"
        },
        "options": [
          {
            "uz": "3G uphill = PF; 3F downhill = PG",
            "ru": "3G uphill = PF; 3F downhill = PG",
            "en": "3G uphill = PF; 3F downhill = PG"
          },
          {
            "uz": "3G uphill = PG; 3F downhill = PF",
            "ru": "3G uphill = PG; 3F downhill = PF",
            "en": "3G uphill = PG; 3F downhill = PF"
          },
          {
            "uz": "3G = PH; 3F = PJ",
            "ru": "3G = PH; 3F = PJ",
            "en": "3G = PH; 3F = PJ"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "B.1-jadval.",
          "ru": "Таблица В.1.",
          "en": "Table B.1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "4. AWS/ASME '4G' va '4F' holatlari ISO 6947 da qanday farqlanadi?",
          "ru": "В чем разница между '4G' и '4F' в обозначениях ИСО 6947?",
          "en": "How do '4G' and '4F' translate into ISO 6947?"
        },
        "options": [
          {
            "uz": "4G = PE (uchma-uch shift); 4F = PD (tavr/burchakli shift)",
            "ru": "4G = PE; 4F = PD",
            "en": "4G = PE; 4F = PD"
          },
          {
            "uz": "4G = PD; 4F = PE",
            "ru": "4G = PD; 4F = PE",
            "en": "4G = PD; 4F = PE"
          },
          {
            "uz": "Ikkalasi ham PE",
            "ru": "Оба PE",
            "en": "Both PE"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "B.1-jadval.",
          "ru": "Таблица В.1.",
          "en": "Table B.1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "5. AWS/ASME '5G uphill' va '5F downhill' ISO 6947 da qanday yoziladi?",
          "ru": "Как записываются '5G uphill' и '5F downhill' по ИСО 6947?",
          "en": "How are '5G uphill' and '5F downhill' designated in ISO 6947?"
        },
        "options": [
          {
            "uz": "5G uphill = PH; 5F downhill = PJ",
            "ru": "5G uphill = PH; 5F downhill = PJ",
            "en": "5G uphill = PH; 5F downhill = PJ"
          },
          {
            "uz": "5G = PF; 5F = PG",
            "ru": "5G = PF; 5F = PG",
            "en": "5G = PF; 5F = PG"
          },
          {
            "uz": "5G = H-L045",
            "ru": "5G = H-L045",
            "en": "5G = H-L045"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "B.1-jadval.",
          "ru": "Таблица В.1.",
          "en": "Table B.1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "6. AWS/ASME '6G uphill' va '6G downhill' ISO 6947 da qanday belgilanadi?",
          "ru": "Как обозначаются '6G uphill' и '6G downhill' по ИСО 6947?",
          "en": "What are the ISO 6947 designations for '6G uphill' and '6G downhill'?"
        },
        "options": [
          {
            "uz": "6G uphill = H-L045; 6G downhill = J-L045",
            "ru": "6G uphill = H-L045; 6G downhill = J-L045",
            "en": "6G uphill = H-L045; 6G downhill = J-L045"
          },
          {
            "uz": "6G uphill = PH; 6G downhill = PJ",
            "ru": "6G uphill = PH; 6G downhill = PJ",
            "en": "6G uphill = PH; 6G downhill = PJ"
          },
          {
            "uz": "6G = PK",
            "ru": "6G = PK",
            "en": "6G = PK"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "B.1-jadval.",
          "ru": "Таблица В.1.",
          "en": "Table B.1."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "7. Amerika standartidagi 'G' va 'F' harflari nimani anglatadi?",
          "ru": "Что означают буквы 'G' и 'F' в стандартах AWS / ASME?",
          "en": "What do 'G' and 'F' stand for in AWS / ASME?"
        },
        "options": [
          {
            "uz": "G = Groove weld (uchma-uch), F = Fillet weld (burchakli)",
            "ru": "G = стыковой (Groove), F = угловой (Fillet)",
            "en": "G = Groove weld, F = Fillet weld"
          },
          {
            "uz": "G = Gas, F = Flux",
            "ru": "G = газ, F = флюс",
            "en": "G = Gas, F = Flux"
          },
          {
            "uz": "G = Gorizontal, F = Vertikal",
            "ru": "G = горизонтальный, F = вертикальный",
            "en": "G = Horizontal, F = Vertical"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "Ilova B.",
          "ru": "Приложение В.",
          "en": "Annex B."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "8. 'R' harfi (masalan, 1FR, 2FR) nimani bildiradi?",
          "ru": "Что означает буква 'R' в обозначениях 1FR и 2FR?",
          "en": "What does the letter 'R' indicate in 1FR and 2FR?"
        },
        "options": [
          {
            "uz": "Rotated pipe (aylantirib payvandlanadigan quvur)",
            "ru": "Поворотная труба (Rotated)",
            "en": "Rotated pipe"
          },
          {
            "uz": "Root pass (ildiz choki)",
            "ru": "Корневой шов",
            "en": "Root pass"
          },
          {
            "uz": "Repair (ta'mirlash)",
            "ru": "Ремонт",
            "en": "Repair"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "Ilova B (15-bet).",
          "ru": "Приложение В (стр. 15).",
          "en": "Annex B (p. 15)."
        },
        "svg": null
      },
      {
        "question": {
          "uz": "9. 45° qiya oʻrnatilgan lekin AYLANTIRIB payvandlanadigan quvur burchakli choki (1FR) ISO 6947 da qaysi holat?",
          "ru": "Какому положению ИСО 6947 соответствует поворотная труба под 45° (1FR)?",
          "en": "Which ISO 6947 position corresponds to a 45° rotated pipe fillet weld (1FR)?"
        },
        "options": [
          {
            "uz": "PA (Pastki holat)",
            "ru": "PA (Нижнее положение)",
            "en": "PA (Flat position)"
          },
          {
            "uz": "H-L045",
            "ru": "H-L045",
            "en": "H-L045"
          },
          {
            "uz": "PB",
            "ru": "PB",
            "en": "PB"
          }
        ],
        "optionSvgs": null,
        "correct": 0,
        "explanation": {
          "uz": "B.1-jadval (15-bet): 1FR = PA, chunki quvur aylantirilganda payvandchi har doim PA holatida payvandlaydi.",
          "ru": "Таблица В.1 (стр. 15): 1FR = PA.",
          "en": "Table B.1 (p. 15): 1FR = PA."
        },
        "svg": null
      }
    ]
  }
];
