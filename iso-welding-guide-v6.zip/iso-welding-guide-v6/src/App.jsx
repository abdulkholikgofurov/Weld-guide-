import React, { useEffect, useRef, useState } from 'react';
import { App as CapApp } from '@capacitor/app';
import { iso2553Topics } from './data/iso2553Data';
import { iso6947Topics } from './data/iso6947Data';
import { getDiscoveredPdfs, generateQuizFromPdfUrl } from './utils/autoPdfQuiz';
import SymbolBuilder2553 from './components/SymbolBuilder2553';
import AngleSimulator6947 from './components/AngleSimulator6947';
import PdfViewerModal from './components/PdfViewerModal';

export default function App() {
  const [lang, setLang] = useState('uz');
  const [navStack, setNavStack] = useState([{ type: 'home' }]);
  const [activeTopic, setActiveTopic] = useState(null);
  const [pdfModal, setPdfModal] = useState(null);
  const [quizAnswers, setQuizAnswers] = useState({});
  const [toastMsg, setToastMsg] = useState('');

  const [autoPdfQuizzes, setAutoPdfQuizzes] = useState({});
  const [customPdfs, setCustomPdfs] = useState([]);
  const [generatingPdfId, setGeneratingPdfId] = useState(null);

  const lastBackPressRef = useRef(0);
  const touchStartRef = useRef({ x: 0, y: 0, tracking: false });

  const currentView = navStack[navStack.length - 1];
  const allPdfs = [...getDiscoveredPdfs(), ...customPdfs];

  const showToast = (msg) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg(prev => (prev === msg ? '' : prev));
    }, 2200);
  };

  useEffect(() => {
    let active = true;
    async function runAutoScan() {
      for (const pdfItem of allPdfs) {
        if (autoPdfQuizzes[pdfItem.id]) continue;
        if (active) setGeneratingPdfId(pdfItem.id);
        try {
          const result = await generateQuizFromPdfUrl(pdfItem.url, 24);
          if (active) {
            setAutoPdfQuizzes(prev => ({ ...prev, [pdfItem.id]: result }));
          }
        } catch (e) {
          if (active) {
            setAutoPdfQuizzes(prev => ({
              ...prev,
              [pdfItem.id]: { pageCount: 1, extractedCount: 0, questions: [], error: e.message }
            }));
          }
        } finally {
          if (active) setGeneratingPdfId(null);
        }
      }
    }
    runAutoScan();
    return () => { active = false; };
  }, [allPdfs.length]);

  const pushView = (view) => {
    setActiveTopic(null);
    setQuizAnswers({});
    setNavStack(prev => [...prev, view]);
    window.scrollTo(0, 0);
  };

  const handleBackAction = () => {
    if (pdfModal) {
      setPdfModal(null);
      return true;
    }
    if (activeTopic) {
      setActiveTopic(null);
      setQuizAnswers({});
      window.scrollTo(0, 0);
      return true;
    }
    if (navStack.length > 1) {
      setNavStack(prev => prev.slice(0, -1));
      setQuizAnswers({});
      window.scrollTo(0, 0);
      return true;
    }
    return false;
  };

  const triggerRootExitOrToast = () => {
    const now = Date.now();
    if (now - lastBackPressRef.current < 2200) {
      CapApp.exitApp().catch(() => {});
    } else {
      lastBackPressRef.current = now;
      showToast(
        lang === 'uz'
          ? 'Chiqish uchun yana bir marta orqaga suring/bosing'
          : lang === 'ru'
          ? 'Нажмите/проведите назад еще раз для выхода'
          : 'Swipe or press back again to exit'
      );
    }
  };

  useEffect(() => {
    const sub = CapApp.addListener('backButton', () => {
      const handled = handleBackAction();
      if (!handled) {
        triggerRootExitOrToast();
      }
    });
    return () => { sub.remove(); };
  });

  const onTouchStart = (e) => {
    if (e.touches.length !== 1) return;
    const t = e.touches[0];
    if (t.clientX <= 32) {
      touchStartRef.current = { x: t.clientX, y: t.clientY, tracking: true };
    } else {
      touchStartRef.current.tracking = false;
    }
  };

  const onTouchEnd = (e) => {
    if (!touchStartRef.current.tracking || e.changedTouches.length === 0) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - touchStartRef.current.x;
    const dy = Math.abs(t.clientY - touchStartRef.current.y);
    touchStartRef.current.tracking = false;
    if (dx > 70 && dy < 65) {
      const handled = handleBackAction();
      if (!handled) {
        triggerRootExitOrToast();
      }
    }
  };

  const handleUploadPdfFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const blobUrl = URL.createObjectURL(file);
    const newItem = {
      id: `${file.name}-${Date.now()}`,
      title: file.name.replace(/\.pdf$/i, '').replace(/[_-]+/g, ' '),
      url: blobUrl,
      builtinStandard: null,
      isCustom: true
    };
    setCustomPdfs(prev => [newItem, ...prev]);
    pushView({ type: 'standard', code: 'pdf', pdfObj: newItem });
  };

  const standard = currentView.type === 'standard' ? currentView.code : null;
  const activePdfObj = currentView.type === 'standard' ? currentView.pdfObj : null;

  const topics = standard === '2553' ? iso2553Topics : standard === '6947' ? iso6947Topics : [];
  const pdfFile = activePdfObj?.url
    ? activePdfObj.url
    : standard === '2553'
    ? './pdf/ISO-2553_RU.pdf'
    : './pdf/ISO-6947_RU.pdf';

  const total2553Tests = iso2553Topics.reduce((s, t) => s + t.quiz.length, 0);
  const total6947Tests = iso6947Topics.reduce((s, t) => s + t.quiz.length, 0);

  const activeQuizList = activeTopic?.quiz || [];
  const correctCount = activeQuizList.reduce((acc, q, idx) => (quizAnswers[idx] === q.correct ? acc + 1 : acc), 0);

  const canGoBack = navStack.length > 1 || Boolean(activeTopic) || Boolean(pdfModal);

  return (
    <div
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
      className="min-h-screen bg-slate-900 text-slate-100 font-sans pb-14"
    >
      <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur border-b border-slate-800 px-3 py-2.5 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          {canGoBack && (
            <button
              onClick={() => {
                if (!handleBackAction()) triggerRootExitOrToast();
              }}
              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-xl text-sky-400 font-bold text-xs shrink-0"
            >
              ← {lang === 'uz' ? 'Orqaga' : lang === 'ru' ? 'Назад' : 'Back'}
            </button>
          )}
          <span className="font-extrabold text-xs sm:text-sm tracking-tight text-white truncate">
            {standard === 'pdf' && activePdfObj
              ? activePdfObj.title
              : standard
              ? `ISO ${standard}`
              : 'WELDING ISO PRO'}
          </span>
        </div>

        <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl border border-slate-700 shrink-0">
          <button onClick={() => setLang('uz')} className={`px-2 py-1 rounded-lg text-[11px] font-bold transition ${lang === 'uz' ? 'bg-sky-600 text-white shadow' : 'opacity-60'}`}>
            🇺🇿 UZ
          </button>
          <button onClick={() => setLang('ru')} className={`px-2 py-1 rounded-lg text-[11px] font-bold transition ${lang === 'ru' ? 'bg-sky-600 text-white shadow' : 'opacity-60'}`}>
            🇷🇺 RU
          </button>
          <button onClick={() => setLang('en')} className={`px-2 py-1 rounded-lg text-[11px] font-bold transition ${lang === 'en' ? 'bg-amber-600 text-white shadow' : 'opacity-60'}`}>
            🇬🇧 EN
          </button>
        </div>
      </header>

      {toastMsg && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 bg-slate-800 border border-amber-400/60 text-amber-300 text-xs font-bold px-4 py-2 rounded-full shadow-2xl">
          {toastMsg}
        </div>
      )}

      <main className="max-w-xl mx-auto p-4">
        {currentView.type === 'home' && (
          <div className="space-y-4 mt-2">
            <div className="text-center mb-4">
              <div className="inline-block px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-amber-400 text-[11px] font-bold mb-2">
                ISO 9606-1 / ISO 2553:2019 / ISO 6947:2011
              </div>
              <h1 className="text-xl font-black text-white">
                {lang === 'uz' ? 'Payvandlash xalqaro standartlari' : lang === 'ru' ? 'Международные стандарты сварки' : 'International Welding Standards'}
              </h1>
            </div>

            <button
              onClick={() => pushView({ type: 'standard', code: '2553' })}
              className="w-full text-left bg-slate-800/90 hover:bg-slate-800 border-2 border-sky-500/40 hover:border-sky-400 p-5 rounded-2xl shadow-xl transition"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-extrabold text-sky-400">ISO 2553:2019 / ГОСТ Р ИСО 2553-2022</span>
                <span className="text-[11px] bg-sky-500/20 text-sky-300 px-2 py-0.5 rounded-full font-bold">{total2553Tests} tests</span>
              </div>
              <div className="text-lg font-black text-white mb-1.5">
                {lang === 'uz' ? 'Chizmalardagi shartli belgilar' : lang === 'ru' ? 'Условные обозначения на чертежах' : 'Symbolic Representation on Drawings'}
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {lang === 'uz'
                  ? 'Barcha atamalar, 22 boshlangʻich va 13 qoʻshimcha belgi + Jonli konstruktor'
                  : lang === 'ru'
                  ? 'Все термины, 22 начальных и 13 вспомогательных символа + Живой конструктор'
                  : 'All terms, 22 elementary & 13 supplementary symbols + Live Builder'}
              </p>
            </button>

            <button
              onClick={() => pushView({ type: 'standard', code: '6947' })}
              className="w-full text-left bg-slate-800/90 hover:bg-slate-800 border-2 border-amber-500/40 hover:border-amber-400 p-5 rounded-2xl shadow-xl transition"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-extrabold text-amber-400">ISO 6947:2011 / ГОСТ Р ИСО 6947-2017</span>
                <span className="text-[11px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-bold">{total6947Tests} tests</span>
              </div>
              <div className="text-lg font-black text-white mb-1.5">
                {lang === 'uz' ? 'Payvandlash fazoviy holatlari' : lang === 'ru' ? 'Положения при сварке' : 'Welding Positions'}
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {lang === 'uz'
                  ? 'PA–PK holatlari, S/R/L burchaklari, ruxsatlar, AWS/ASME + Simulyator'
                  : lang === 'ru'
                  ? 'Положения PA–PK, углы S, R, L, допуски, AWS/ASME + Симулятор'
                  : 'PA–PK positions, S/R/L angles, tolerances, AWS/ASME + Simulator'}
              </p>
            </button>

            <div className="bg-slate-800/80 border border-emerald-500/30 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="text-xs font-extrabold text-emerald-400">
                    {lang === 'uz' ? '⚡ Avto-PDF Test Generatori' : lang === 'ru' ? '⚡ Авто-генератор тестов из PDF' : '⚡ Auto-PDF Quiz Generator'}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {lang === 'uz'
                      ? 'public/pdf/ papkasiga qoʻshilgan har qanday PDF dan avtomatik test tuzadi'
                      : lang === 'ru'
                      ? 'Автоматически создает тесты из любого PDF в public/pdf/'
                      : 'Automatically builds quizzes from any PDF placed in public/pdf/'}
                  </div>
                </div>
                <label className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[11px] font-bold cursor-pointer shrink-0">
                  + PDF
                  <input type="file" accept="application/pdf,.pdf" onChange={handleUploadPdfFile} className="hidden" />
                </label>
              </div>

              {allPdfs.map((pdfItem) => {
                const autoData = autoPdfQuizzes[pdfItem.id];
                const isBusy = generatingPdfId === pdfItem.id;
                const qCount = autoData?.questions?.length || 0;
                return (
                  <button
                    key={pdfItem.id}
                    onClick={() => pushView({ type: 'standard', code: 'pdf', pdfObj: pdfItem })}
                    className="w-full text-left bg-slate-900 hover:bg-slate-950 border border-slate-700 p-3 rounded-xl flex items-center justify-between transition"
                  >
                    <div className="min-w-0 pr-2">
                      <div className="font-bold text-xs text-white truncate">📄 {pdfItem.title}</div>
                      <div className="text-[11px] text-emerald-300 mt-0.5">
                        {isBusy
                          ? (lang === 'uz' ? 'PDF tahlil qilinmoqda...' : lang === 'ru' ? 'Анализ PDF...' : 'Scanning PDF...')
                          : (lang === 'uz'
                            ? `Avto-test: ${qCount} savol (${autoData?.pageCount || '?'} bet)`
                            : lang === 'ru'
                            ? `Авто-тест: ${qCount} вопр. (${autoData?.pageCount || '?'} стр.)`
                            : `Auto-quiz: ${qCount} Qs (${autoData?.pageCount || '?'} pp.)`)}
                      </div>
                    </div>
                    <span className="text-emerald-400 font-black text-sm">→</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {standard && standard !== 'pdf' && !activeTopic && (
          <div className="space-y-3">
            {standard === '2553' ? <SymbolBuilder2553 lang={lang} /> : <AngleSimulator6947 lang={lang} />}

            <h2 className="text-xs font-extrabold text-slate-400 uppercase tracking-wider mt-5 mb-2">
              {lang === 'uz' ? 'Mavzulashtirilgan boʻlimlar va testlar' : lang === 'ru' ? 'Тематические разделы и тесты' : 'Modules & Practice Tests'}
            </h2>

            {topics.map((t) => (
              <button
                key={t.id}
                onClick={() => { setActiveTopic(t); setQuizAnswers({}); window.scrollTo(0, 0); }}
                className="w-full text-left bg-slate-800 hover:bg-slate-750 border border-slate-700 p-4 rounded-xl flex items-center justify-between transition"
              >
                <div className="pr-2">
                  <div className="font-bold text-white text-sm">{t.title[lang]}</div>
                  <div className="text-xs text-slate-400 mt-1">
                    {lang === 'uz'
                      ? `📝 Test: ${t.quiz.length} savol  |  📖 Kitob: ${t.pdfPage}-bet`
                      : lang === 'ru'
                      ? `📝 Тест: ${t.quiz.length} вопр.  |  📖 Книга: стр. ${t.pdfPage}`
                      : `📝 Quiz: ${t.quiz.length} questions  |  📖 Standard: p. ${t.pdfPage}`}
                  </div>
                </div>
                <span className="text-sky-400 font-black text-lg">→</span>
              </button>
            ))}
          </div>
        )}

        {standard === 'pdf' && activePdfObj && !activeTopic && (
          <div className="space-y-3 mt-2">
            {(() => {
              const autoData = autoPdfQuizzes[activePdfObj.id];
              const qList = autoData?.questions || [];
              return (
                <>
                  <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 flex items-center justify-between">
                    <div>
                      <div className="text-sm font-extrabold text-white">{activePdfObj.title}</div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        {lang === 'uz'
                          ? `${autoData?.pageCount || '?'} sahifa • ${qList.length} ta avtomatik test`
                          : lang === 'ru'
                          ? `${autoData?.pageCount || '?'} стр. • ${qList.length} авто-тестов`
                          : `${autoData?.pageCount || '?'} pages • ${qList.length} auto-generated questions`}
                      </div>
                    </div>
                    <button
                      onClick={() => setPdfModal({ url: activePdfObj.url, page: 1 })}
                      className="px-3 py-2 bg-amber-500 text-slate-950 font-black rounded-xl text-xs"
                    >
                      📖 PDF
                    </button>
                  </div>

                  <button
                    disabled={qList.length === 0}
                    onClick={() => {
                      setActiveTopic({
                        id: `auto-${activePdfObj.id}`,
                        pdfPage: 1,
                        title: {
                          uz: `${activePdfObj.title} — Avto-test (${qList.length} savol)`,
                          ru: `${activePdfObj.title} — Авто-тест (${qList.length} вопр.)`,
                          en: `${activePdfObj.title} — Auto Quiz (${qList.length} Qs)`
                        },
                        theory: {
                          uz: `Ushbu test ${activePdfObj.title} PDF hujjati matnidan avtomatik yaratildi (${autoData?.extractedCount || 0} ta qoida boʻlagi tahlil qilindi).`,
                          ru: `Тест автоматически сгенерирован из текста PDF «${activePdfObj.title}».`,
                          en: `Generated automatically from "${activePdfObj.title}" PDF content.`
                        },
                        items: [],
                        quiz: qList
                      });
                      setQuizAnswers({});
                      window.scrollTo(0, 0);
                    }}
                    className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-black rounded-2xl shadow-lg text-sm"
                  >
                    {qList.length > 0
                      ? (lang === 'uz' ? `⚡ Avto-testni boshlash (${qList.length} savol)` : lang === 'ru' ? `⚡ Начать авто-тест (${qList.length} вопр.)` : `⚡ Start Auto-Quiz (${qList.length} Qs)`)
                      : (lang === 'uz' ? 'PDF matni oʻqilmoqda...' : lang === 'ru' ? 'Чтение PDF...' : 'Reading PDF...')}
                  </button>
                </>
              );
            })()}
          </div>
        )}

        {activeTopic && (
          <div className="space-y-4">
            <h2 className="text-base font-extrabold text-amber-400">{activeTopic.title[lang]}</h2>

            <div className="bg-slate-800/90 border border-slate-700 p-4 rounded-2xl text-xs sm:text-sm leading-relaxed whitespace-pre-line text-slate-200">
              {activeTopic.theory[lang]}
            </div>

            {activeTopic.items?.map((item, idx) => (
              <div key={idx} className="bg-slate-800 border border-slate-700 rounded-2xl p-3.5">
                <div className="font-bold text-sky-400 text-xs sm:text-sm mb-0.5">{item.name[lang]}</div>
                <div className="text-[11px] text-slate-400 mb-3">{item.desc[lang]}</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div className="bg-slate-950 p-2 rounded-xl border border-slate-700">
                    <div dangerouslySetInnerHTML={{ __html: item.symbolSvg }} />
                  </div>
                  <div className="bg-slate-950 p-2 rounded-xl border border-slate-700">
                    <div dangerouslySetInnerHTML={{ __html: item.crossSectionSvg }} />
                  </div>
                </div>
              </div>
            ))}

            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-green-400 text-sm">
                  {lang === 'uz' ? '📝 Mavzu boʻyicha test' : lang === 'ru' ? '📝 Тест по разделу' : '📝 Section Quiz'}
                </h3>
                <span className="text-xs font-bold bg-slate-900 px-2.5 py-1 rounded-lg text-amber-400">
                  {correctCount} / {activeQuizList.length}
                </span>
              </div>

              {activeQuizList.map((q, qIdx) => {
                const chosen = quizAnswers[qIdx];
                return (
                  <div key={qIdx} className="border-t border-slate-700 pt-3">
                    <div className="font-semibold text-xs sm:text-sm text-white mb-2">
                      {qIdx + 1}. {q.question[lang]}
                    </div>
                    {q.svg && (
                      <div className="bg-slate-950 p-2 rounded-xl mb-3 max-w-xs mx-auto border border-slate-800" dangerouslySetInnerHTML={{ __html: q.svg }} />
                    )}
                    {q.optionSvgs && (
                      <div className="grid grid-cols-3 gap-1.5 mb-2">
                        {q.optionSvgs.map((osvg, sIdx) => (
                          <div key={sIdx} className="bg-slate-950 p-1.5 rounded-lg border border-slate-700 text-center">
                            <div className="text-[10px] font-bold text-amber-400 mb-0.5">{['A', 'B', 'C'][sIdx]}</div>
                            <div dangerouslySetInnerHTML={{ __html: osvg }} />
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="space-y-2">
                      {q.options.map((opt, oIdx) => {
                        let btnStyle = 'bg-slate-900 border-slate-700 text-slate-200';
                        if (chosen !== undefined) {
                          if (oIdx === q.correct) btnStyle = 'bg-green-900/60 border-green-500 text-green-200 font-bold';
                          else if (oIdx === chosen) btnStyle = 'bg-red-900/60 border-red-500 text-red-200';
                        }
                        return (
                          <button
                            key={oIdx}
                            onClick={() => setQuizAnswers({ ...quizAnswers, [qIdx]: oIdx })}
                            className={`w-full text-left p-3 rounded-xl border text-xs transition ${btnStyle}`}
                          >
                            {opt[lang]}
                          </button>
                        );
                      })}
                    </div>
                    {chosen !== undefined && (
                      <div className="mt-2 p-2.5 bg-sky-950/70 border border-sky-700 rounded-xl text-xs text-sky-200">
                        💡 {q.explanation[lang]}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => setPdfModal({ url: pdfFile, page: activeTopic.pdfPage || 1 })}
              className="w-full py-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-2xl shadow-lg text-xs sm:text-sm flex items-center justify-center gap-2"
            >
              📖 {lang === 'uz'
                ? `Kitobdan tekshirish (${activeTopic.pdfPage || 1}-sahifa)`
                : lang === 'ru'
                ? `Проверить по книге (стр. ${activeTopic.pdfPage || 1})`
                : `Verify in Standard PDF (Page ${activeTopic.pdfPage || 1})`}
            </button>
          </div>
        )}
      </main>

      {pdfModal && (
        <PdfViewerModal
          pdfUrl={pdfModal.url}
          pageNumber={pdfModal.page}
          onClose={() => setPdfModal(null)}
          lang={lang}
        />
      )}
    </div>
  );
}
