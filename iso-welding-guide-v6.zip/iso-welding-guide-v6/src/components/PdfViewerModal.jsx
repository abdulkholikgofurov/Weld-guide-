import React, { useEffect, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';

pdfjsLib.GlobalWorkerOptions.workerSrc = './pdfjs/pdf.worker.min.mjs';

export default function PdfViewerModal({ pdfUrl, pageNumber, onClose, lang }) {
  const canvasRef = useRef(null);
  const scrollContainerRef = useRef(null);
  const [page, setPage] = useState(pageNumber || 1);
  const [totalPages, setTotalPages] = useState(1);
  const [scale, setScale] = useState(1.25);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);

  useEffect(() => {
    if (pageNumber) setPage(pageNumber);
  }, [pageNumber]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setErr(null);
    async function render() {
      try {
        const pdf = await pdfjsLib.getDocument(pdfUrl).promise;
        if (cancelled) return;
        setTotalPages(pdf.numPages);
        const safePage = Math.min(Math.max(1, page), pdf.numPages);
        const pdfPage = await pdf.getPage(safePage);
        const viewport = pdfPage.getViewport({ scale });
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const dpr = window.devicePixelRatio || 1;
        canvas.width = Math.floor(viewport.width * dpr);
        canvas.height = Math.floor(viewport.height * dpr);
        canvas.style.width = `${Math.floor(viewport.width)}px`;
        canvas.style.height = `${Math.floor(viewport.height)}px`;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        await pdfPage.render({ canvasContext: ctx, viewport }).promise;
        if (!cancelled) {
          setLoading(false);
          if (scrollContainerRef.current) {
            scrollContainerRef.current.scrollLeft = 0;
            scrollContainerRef.current.scrollTop = 0;
          }
        }
      } catch (e) {
        if (!cancelled) {
          setErr(e.message || 'PDF error');
          setLoading(false);
        }
      }
    }
    render();
    return () => { cancelled = true; };
  }, [pdfUrl, page, scale]);

  const label = lang === 'uz'
    ? `📖 Sahifa: ${page} / ${totalPages} (${Math.round(scale * 100)}%)`
    : lang === 'ru'
    ? `📖 Стр.: ${page} / ${totalPages} (${Math.round(scale * 100)}%)`
    : `📖 Page: ${page} / ${totalPages} (${Math.round(scale * 100)}%)`;

  return (
    <div className="fixed inset-0 bg-black/95 z-50 flex flex-col">
      <div className="flex items-center justify-between p-2.5 bg-slate-900 border-b border-slate-700 gap-1.5 shrink-0">
        <span className="text-[11px] font-bold text-amber-400 truncate">{label}</span>
        <div className="flex items-center gap-1 shrink-0">
          <button onClick={() => setScale(s => Math.max(0.75, +(s - 0.25).toFixed(2)))} className="px-2 py-1 bg-slate-800 rounded text-xs font-bold">−</button>
          <button onClick={() => setScale(s => Math.min(2.5, +(s + 0.25).toFixed(2)))} className="px-2 py-1 bg-slate-800 rounded text-xs font-bold">+</button>
          <button onClick={() => setPage(p => Math.max(1, p - 1))} className="px-2.5 py-1 bg-slate-700 rounded text-white text-xs font-bold">◀</button>
          <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} className="px-2.5 py-1 bg-slate-700 rounded text-white text-xs font-bold">▶</button>
          <button onClick={onClose} className="px-2.5 py-1 bg-red-600 rounded text-white text-xs font-bold">✕</button>
        </div>
      </div>

      <div
        ref={scrollContainerRef}
        className="flex-1 w-full overflow-auto p-3 bg-slate-950"
      >
        {loading && (
          <div className="text-sky-400 text-sm mt-10 text-center animate-pulse">
            {lang === 'uz' ? 'Sahifa yuklanmoqda...' : lang === 'ru' ? 'Загрузка страницы...' : 'Loading page...'}
          </div>
        )}
        {err && <div className="text-red-400 text-xs mt-10 text-center">{err}</div>}
        <div className="inline-block min-w-full">
          <canvas ref={canvasRef} className={`rounded shadow-2xl bg-white block ${loading ? 'hidden' : 'block'}`} />
        </div>
      </div>
    </div>
  );
}
