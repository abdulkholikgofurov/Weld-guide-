import * as pdfjsLib from 'pdfjs-dist';

pdfjsLib.GlobalWorkerOptions.workerSrc = './pdfjs/pdf.worker.min.mjs';

export const BUILTIN_PDFS = [
  { file: 'ISO-2553_RU.pdf', url: './pdf/ISO-2553_RU.pdf', standardCode: '2553' },
  { file: 'ISO-6947_RU.pdf', url: './pdf/ISO-6947_RU.pdf', standardCode: '6947' }
];

const extraGlobModules = import.meta.glob('../../public/pdf/*.pdf', { eager: true, as: 'url' });

export function getDiscoveredPdfs() {
  const map = new Map();
  for (const item of BUILTIN_PDFS) {
    map.set(item.file.toLowerCase(), {
      id: item.file,
      title: item.file.replace(/\.pdf$/i, '').replace(/[_-]+/g, ' '),
      url: item.url,
      builtinStandard: item.standardCode,
      isCustom: false
    });
  }
  for (const [fullPath, url] of Object.entries(extraGlobModules)) {
    const fileName = fullPath.split('/').pop() || 'custom.pdf';
    const key = fileName.toLowerCase();
    if (!map.has(key)) {
      map.set(key, {
        id: fileName,
        title: fileName.replace(/\.pdf$/i, '').replace(/[_-]+/g, ' '),
        url,
        builtinStandard: null,
        isCustom: false
      });
    }
  }
  return Array.from(map.values());
}

function cleanSentence(s) {
  return s.replace(/\s+/g, ' ').replace(/^[•\-–—*\d.\)\s]+/, '').trim();
}

export async function generateQuizFromPdfUrl(pdfUrl, maxQuestions = 24) {
  const pdf = await pdfjsLib.getDocument(pdfUrl).promise;
  const numPages = pdf.numPages;
  const candidateChunks = [];

  for (let p = 1; p <= numPages; p++) {
    const page = await pdf.getPage(p);
    const content = await page.getTextContent();
    const rawText = content.items.map(it => ('str' in it ? it.str : '')).join(' ');
    const normalized = rawText.replace(/\s+/g, ' ').trim();
    if (normalized.length < 40) continue;

    const parts = normalized.split(/(?<=[.!?।])\s+|\s+(?=\d+\.\d+)/);
    for (const part of parts) {
      const c = cleanSentence(part);
      if (c.length >= 45 && c.length <= 260 && /[A-Za-zА-Яа-яЁёЎўҚқҒғҲҳ]/.test(c)) {
        candidateChunks.push({ page: p, text: c });
      }
    }
  }

  const unique = [];
  const seen = new Set();
  for (const item of candidateChunks) {
    const key = item.text.slice(0, 60).toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(item);
    }
  }

  const pool = unique.length >= 4 ? unique : candidateChunks;
  if (pool.length < 2) {
    return {
      pageCount: numPages,
      extractedCount: 0,
      questions: []
    };
  }

  const step = Math.max(1, Math.floor(pool.length / maxQuestions));
  const selected = [];
  for (let i = 0; i < pool.length && selected.length < maxQuestions; i += step) {
    selected.push(pool[i]);
  }

  const questions = selected.map((entry, idx) => {
    const words = entry.text.split(' ').filter(w => w.length > 3);
    const keyTerm = words[0] || `Band #${idx + 1}`;
    const snippet = entry.text.length > 135 ? entry.text.slice(0, 132) + '...' : entry.text;

    const distractors = [];
    for (let offset = 1; distractors.length < 2; offset++) {
      const alt = pool[(idx * step + offset * 7) % pool.length];
      if (alt && alt.text !== entry.text) {
        const altShort = alt.text.length > 135 ? alt.text.slice(0, 132) + '...' : alt.text;
        if (!distractors.includes(altShort)) distractors.push(altShort);
      }
    }
    while (distractors.length < 2) {
      distractors.push(`Boshqa sahifadagi ma'lumot (${entry.page + distractors.length + 1}-bet)`);
    }

    const correctIdx = idx % 3;
    const rawOpts = [...distractors];
    rawOpts.splice(correctIdx, 0, snippet);

    const makeLocalized = (txt) => ({ uz: txt, ru: txt, en: txt });

    return {
      question: {
        uz: `[${entry.page}-bet] "${keyTerm}" ga oid toʻgʻri qoidani toping:`,
        ru: `[Стр. ${entry.page}] Найдите верное положение, относящееся к "${keyTerm}":`,
        en: `[Page ${entry.page}] Identify the rule matching "${keyTerm}":`
      },
      options: rawOpts.map(makeLocalized),
      optionSvgs: null,
      correct: correctIdx,
      explanation: {
        uz: `Hujjatning ${entry.page}-sahifasidan avtomatik olindi.`,
        ru: `Извлечено автоматически со стр. ${entry.page} документа.`,
        en: `Automatically extracted from page ${entry.page} of the PDF.`
      },
      svg: null
    };
  });

  return {
    pageCount: numPages,
    extractedCount: pool.length,
    questions
  };
}
